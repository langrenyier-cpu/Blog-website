/**
 * 个人博客 - Cloudflare Workers 版
 * 技术栈：Hono（路由）+ KV（文章/站点/认证）+ R2（图片存储）+ Workers Static Assets（静态前端）
 * 免费额度：Workers 10 万请求/天 · KV 10 万读/天 + 1000 写/天 · R2 10GB 存储
 */
import { Hono } from 'hono';
import { HTML_ASSETS } from './html-assets.js';

const app = new Hono();

/* ================= 工具函数 ================= */
function str(v) {
  return typeof v === 'string' ? v.trim() : '';
}
function stripTags(html) {
  return String(html || '').replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim();
}
/** 去掉 script 标签与内联事件，防止 XSS */
function sanitize(html) {
  return String(html || '')
    .replace(/<script[\s\S]*?<\/script>/gi, '')
    .replace(/\son\w+\s*=\s*("[^"]*"|'[^']*'|[^\s>]+)/gi, '')
    .replace(/javascript:/gi, '');
}
/** Web Crypto SHA-256（Workers 环境无 Node crypto） */
async function sha256(text) {
  const buf = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(text));
  return [...new Uint8Array(buf)].map(b => b.toString(16).padStart(2, '0')).join('');
}
function randomHex(n) {
  const bytes = new Uint8Array(n);
  crypto.getRandomValues(bytes);
  return [...bytes].map(b => b.toString(16).padStart(2, '0')).join('');
}

/* ================= KV 键名 ================= */
const KEY = { posts: 'posts', site: 'site', auth: 'auth', seeded: 'seeded', subscribers: 'subscribers' };

/* ================= 默认数据 ================= */
const DEFAULT_SITE = {
  siteName: '云间小站',
  ownerName: '阿云',
  avatar: '/uploads/avatar.jpg',
  bio: '在这里记录生活、技术与思考。',
  contacts: [
    { type: 'email', label: '邮箱', value: 'hello@example.com', link: 'mailto:hello@example.com' },
    { type: 'github', label: 'GitHub', value: '@mygithub', link: 'https://github.com/' },
    { type: 'wechat', label: '微信', value: 'my-wechat-id', link: '' },
    { type: 'website', label: '个人主页', value: 'example.com', link: 'https://example.com' }
  ],
  links: [
    { name: 'MDN Web Docs', url: 'https://developer.mozilla.org/zh-CN/', desc: 'Web 开发权威文档' },
    { name: '阮一峰的网络日志', url: 'https://www.ruanyifeng.com/blog/', desc: '知名技术博客' },
    { name: 'GitHub', url: 'https://github.com', desc: '全球最大代码托管平台' }
  ],
  sponsorLinks: [
    { name: '赞赏支持', url: 'https://example.com/sponsor', desc: '如果博客对你有帮助，可以请我喝杯咖啡 ☕', image: '' }
  ]
};

function seedPosts() {
  const now = Date.now();
  const day = 24 * 3600 * 1000;
  return [
    {
      id: crypto.randomUUID(),
      title: '欢迎使用我的个人博客 🎉',
      summary: '这是一篇功能演示文章，展示了编辑器的全部排版能力：字号调节、粗细、标记划线、链接与图片。',
      cover: '/uploads/demo-1.jpg',
      tags: ['公告', '使用指南'],
      status: 'published',
      views: 168,
      createdAt: now - day,
      updatedAt: now - day,
      content: `<h2>🎉 欢迎来到我的博客</h2>
<p>这是一篇<strong>功能演示文章</strong>，集中展示后台编辑器支持的<em>所有排版能力</em>。你可以登录后台，随意修改或删除它。</p>
<h3>字号调节</h3>
<p><span style="font-size: 28px;">这是 28px 的大号文字</span></p>
<p>正文默认 16px，<span style="font-size: 20px;">这是 20px</span>，<span style="font-size: 14px;">这是 14px</span>，<span style="font-size: 12px;">这是 12px 的小字</span>。</p>
<h3>粗细与标记划线</h3>
<p><strong>粗体文字</strong> · <em>斜体文字</em> · <u>下划线文字</u> · <s>删除线文字（划掉的内容）</s> · <mark style="background-color:#fde047;">荧光笔高亮标记</mark> · <span style="color:#e11d48;">彩色文字</span></p>
<h3>插入链接</h3>
<p>编辑器里可以插入可点击的链接，例如跳转到 <a href="https://developer.mozilla.org/zh-CN/" target="_blank" rel="noopener">MDN Web 文档</a> 或 <a href="https://github.com/" target="_blank" rel="noopener">GitHub</a>，点击后会在新窗口打开。</p>
<h3>插入图片</h3>
<p>支持本地上传、外链 URL、直接粘贴三种方式：</p>
<p><img src="/uploads/demo-1.jpg" alt="示例风景图"></p>
<blockquote><p>提示：选中文字后点击工具栏按钮即可应用样式，「清除格式」可以一键还原。</p></blockquote>
<hr>
<p>现在，去后台写一篇属于你的文章吧！✍️</p>`
    },
    {
      id: crypto.randomUUID(),
      title: '浏览器富文本编辑是怎么实现的？',
      summary: '从 contenteditable 与 execCommand 讲起，聊聊像素级字号调节的实现思路。',
      cover: '/uploads/demo-2.jpg',
      tags: ['技术', 'JavaScript', '教程'],
      status: 'published',
      views: 96,
      createdAt: now - 3 * day,
      updatedAt: now - 3 * day,
      content: `<h2>从 contenteditable 说起</h2>
<p>浏览器原生富文本编辑的核心是 <code>contenteditable</code> 属性——它可以把任意元素变成可编辑区域：</p>
<pre><code>const editor = document.querySelector('.editor');
editor.contentEditable = true;

// 对选中的文字执行加粗
document.execCommand('bold');</code></pre>
<p>虽然 <code>execCommand</code> 已被标记为<strong>废弃 API</strong>，但主流浏览器仍然完整支持它；配合 <code>styleWithCSS</code> 参数，还能输出干净的 span 样式而不是 &lt;font&gt; 标签。</p>
<h3>字号怎么办？</h3>
<p>原生字号命令只有 1-7 七档，想要<strong>精确到像素</strong>，可以对选区内容包裹一个 span：</p>
<pre><code>function setFontSize(px) {
  const sel = window.getSelection();
  const range = sel.getRangeAt(0);
  const span = document.createElement('span');
  span.style.fontSize = px + 'px';
  span.appendChild(range.extractContents());
  range.insertNode(span);
}</code></pre>
<blockquote><p>本博客后台的编辑器就是用这个思路实现了像素级的字号调节。</p></blockquote>
<h3>小结</h3>
<ul>
<li><s>引入重型编辑器库</s> —— 三百行原生代码即可覆盖核心需求</li>
<li><mark style="background-color:#bbf7d0;">保存时存 innerHTML，渲染时直接输出</mark></li>
<li>链接渲染统一补上 <code>target="_blank"</code></li>
</ul>
<p>扩展阅读：<a href="https://developer.mozilla.org/zh-CN/docs/Web/API/Document/execCommand" target="_blank" rel="noopener">MDN：execCommand</a></p>`
    },
    {
      id: crypto.randomUUID(),
      title: '周末徒步记录：把风景装进相册',
      summary: '分享一组周末郊外徒步时拍下的照片，山间晨雾与山顶远眺。',
      cover: '/uploads/demo-3.jpg',
      tags: ['生活', '摄影', '徒步'],
      status: 'published',
      views: 54,
      createdAt: now - 7 * day,
      updatedAt: now - 7 * day,
      content: `<p>这个周末背上相机去了一趟郊外，分享几张路上的风景 📷</p>
<p><span style="font-size: 20px;"><strong>出发 · 清晨 6:30</strong></span></p>
<p>天刚蒙蒙亮，山间的雾气还没散：</p>
<p><img src="/uploads/demo-2.jpg" alt="清晨山景"></p>
<p><span style="font-size: 20px;"><strong>登顶 · 上午 10:00</strong></span></p>
<p><mark style="background-color:#bbf7d0;">运气很好，山顶视野极佳</mark>，远处的群山层层叠叠：</p>
<p><img src="/uploads/demo-3.jpg" alt="山顶远眺"></p>
<h3>装备清单</h3>
<ul>
<li>登山鞋、冲锋衣</li>
<li>相机 + 35mm 定焦镜头</li>
<li>1.5L 水、能量棒若干</li>
</ul>
<p>下次把详细路线攻略整理成一篇笔记，敬请期待～</p>`
    }
  ];
}

/* ================= 惰性初始化（首次访问自动写入种子数据） ================= */
let seededLocal = false; // isolate 级缓存标记，避免每次请求都读 KV
async function ensureSeed(env) {
  if (seededLocal) return;
  const seeded = await env.BLOG_KV.get(KEY.seeded);
  if (seeded) { seededLocal = true; return; }
  // 默认账号 admin / admin123（也可在部署时用 secret ADMIN_PASSWORD 指定初始密码）
  const initialPassword = str(env.ADMIN_PASSWORD) || 'admin123';
  const salt = randomHex(16);
  const auth = { username: 'admin', salt, hash: await sha256(salt + initialPassword), version: 1 };
  await Promise.all([
    env.BLOG_KV.put(KEY.auth, JSON.stringify(auth)),
    env.BLOG_KV.put(KEY.site, JSON.stringify(DEFAULT_SITE)),
    env.BLOG_KV.put(KEY.posts, JSON.stringify(seedPosts())),
    env.BLOG_KV.put(KEY.seeded, '1')
  ]);
  seededLocal = true;
}

/* ================= 数据读写 ================= */
async function getPosts(env) {
  await ensureSeed(env);
  const raw = await env.BLOG_KV.get(KEY.posts);
  return raw ? JSON.parse(raw) : [];
}
async function putPosts(env, posts) {
  await env.BLOG_KV.put(KEY.posts, JSON.stringify(posts));
}
async function getSite(env) {
  await ensureSeed(env);
  const raw = await env.BLOG_KV.get(KEY.site);
  return raw ? JSON.parse(raw) : DEFAULT_SITE;
}
async function getAuth(env) {
  await ensureSeed(env);
  const raw = await env.BLOG_KV.get(KEY.auth);
  return raw ? JSON.parse(raw) : null;
}

/* ================= 认证 ================= */
const TOKEN_TTL = 7 * 24 * 3600; // 7 天（秒）
function getToken(c) {
  const h = c.req.header('Authorization') || '';
  return h.startsWith('Bearer ') ? h.slice(7).trim() : '';
}
/** 校验 token：存在且 version 与当前 auth 一致（改密码后旧 token 自动全部失效） */
async function authState(c) {
  const token = getToken(c);
  if (!token) return null;
  const raw = await c.env.BLOG_KV.get('token:' + token);
  if (!raw) return null;
  const t = JSON.parse(raw);
  const auth = await getAuth(c.env);
  if (!auth || t.version !== auth.version) return null;
  return t;
}
const requireAuth = async (c, next) => {
  const t = await authState(c);
  if (!t) return c.json({ error: '未登录或登录已过期' }, 401);
  await next();
};

app.post('/api/login', async c => {
  const { username, password } = await c.req.json().catch(() => ({}));
  const auth = await getAuth(c.env);
  if (!auth || username !== auth.username || await sha256(auth.salt + String(password || '')) !== auth.hash) {
    return c.json({ error: '用户名或密码错误' }, 400);
  }
  const token = crypto.randomUUID();
  await c.env.BLOG_KV.put('token:' + token, JSON.stringify({ username: auth.username, version: auth.version }), { expirationTtl: TOKEN_TTL });
  return c.json({ ok: true, token, username: auth.username });
});

app.post('/api/logout', requireAuth, async c => {
  await c.env.BLOG_KV.delete('token:' + getToken(c));
  return c.json({ ok: true });
});

app.post('/api/change-password', requireAuth, async c => {
  const { oldPassword, newPassword } = await c.req.json().catch(() => ({}));
  const auth = await getAuth(c.env);
  if (!oldPassword || await sha256(auth.salt + String(oldPassword)) !== auth.hash) {
    return c.json({ error: '原密码错误' }, 400);
  }
  if (!newPassword || String(newPassword).length < 6) {
    return c.json({ error: '新密码至少需要 6 位' }, 400);
  }
  const salt = randomHex(16);
  const next = { username: auth.username, salt, hash: await sha256(salt + String(newPassword)), version: (auth.version || 1) + 1 };
  await c.env.BLOG_KV.put(KEY.auth, JSON.stringify(next));
  // version+1 后，所有旧 token 校验失败，强制各端重新登录
  return c.json({ ok: true });
});

/* ================= 站点配置 ================= */
app.get('/api/site', async c => c.json(await getSite(c.env)));

app.put('/api/site', requireAuth, async c => {
  const body = await c.req.json().catch(() => ({}));
  const site = {
    siteName: str(body.siteName) || '个人博客',
    ownerName: str(body.ownerName) || '博主',
    avatar: str(body.avatar),
    bio: str(body.bio),
    contacts: Array.isArray(body.contacts)
      ? body.contacts.filter(x => x && (str(x.value) || str(x.link)))
          .map(x => ({ type: str(x.type), label: str(x.label), value: str(x.value), link: str(x.link) }))
      : [],
    links: Array.isArray(body.links)
      ? body.links.filter(x => x && str(x.name) && str(x.url))
          .map(x => ({ name: str(x.name), url: str(x.url), desc: str(x.desc) }))
      : [],
    // 关键修复：赞助支持「收款账号 / 赞赏码」场景通常没有 URL，
    // 因此只要「有名称」或「有图片」就保留该条目，url 允许为空。
    sponsorLinks: Array.isArray(body.sponsorLinks)
      ? body.sponsorLinks
          .filter(x => x && (str(x.name) || str(x.image)))
          .map(x => ({ name: str(x.name), url: str(x.url), desc: str(x.desc), image: str(x.image) }))
      : []
  };
  await c.env.BLOG_KV.put(KEY.site, JSON.stringify(site));
  return c.json(site);
});

/* ================= 动漫壁纸代理（绕过浏览器 CORS） ================= */
app.get('/api/wallpaper', async c => {
  const headers = new Headers();
  headers.set('Cache-Control', 'no-store, no-cache, must-revalidate');
  try {
    // dmoe.cc 返回随机动漫图，国内/移动端访问更稳定
    const r = await fetch('https://www.dmoe.cc/random.php', { redirect: 'follow' });
    if (!r.ok) throw new Error('dmoe failed');
    headers.set('Content-Type', r.headers.get('content-type') || 'image/jpeg');
    return new Response(r.body, { status: 200, headers });
  } catch {
    try {
      // 备选：pic.re 随机动漫壁纸
      const r = await fetch('https://pic.re/image?category=anime', { redirect: 'follow' });
      if (!r.ok) throw new Error('pic.re failed');
      headers.set('Content-Type', r.headers.get('content-type') || 'image/webp');
      return new Response(r.body, { status: 200, headers });
    } catch (err) {
      return c.json({ error: err.message }, 500);
    }
  }
});

/* ================= 文章 ================= */
/** 校验并整理文章数据，非法时返回 null（并已响应错误） */
function validPost(body) {
  const title = str(body.title);
  if (!title) return { error: '标题不能为空' };
  const content = sanitize(body.content || '');
  if (!stripTags(content) && !/<img\s/i.test(content)) {
    return { error: '内容不能为空' };
  }
  return {
    value: {
      title,
      summary: str(body.summary) || stripTags(content).slice(0, 120),
      cover: str(body.cover),
      tags: (Array.isArray(body.tags) ? body.tags : String(body.tags || '').split(/[,，]/))
        .map(t => str(t)).filter(Boolean),
      status: body.status === 'draft' ? 'draft' : 'published',
      pinned: !!body.pinned,
      content
    }
  };
}

/** 置顶优先，再按时间倒序 */
function sortPosts(list) {
  return list.slice().sort((a, b) => {
    const pa = a.pinned ? 1 : 0;
    const pb = b.pinned ? 1 : 0;
    if (pa !== pb) return pb - pa;
    return (b.createdAt || 0) - (a.createdAt || 0);
  });
}

app.get('/api/posts', async c => {
  const posts = await getPosts(c.env);
  const list = sortPosts(posts);

  // 管理员获取全部（兼容后台管理面板）
  if (c.req.query('all') === '1') {
    const t = await authState(c);
    if (t) return c.json(list);
  }

  const published = list.filter(p => p.status === 'published');

  // 关键词搜索：标题 / 摘要 / 标签 / 正文
  const q = str(c.req.query('q')).toLowerCase();
  const filtered = q
    ? published.filter(p => {
        const hay = [
          p.title, p.summary,
          (p.tags || []).join(' '), stripTags(p.content)
        ].join(' ').toLowerCase();
        return hay.includes(q);
      })
    : published;

  // 分页参数（不传则默认每页 5 条，返回全部）
  const page = Math.max(1, parseInt(c.req.query('page'), 10) || 1);
  const limit = Math.max(1, Math.min(50, parseInt(c.req.query('limit'), 10) || 5));
  const start = (page - 1) * limit;
  const pageItems = filtered.slice(start, start + limit);

  return c.json({
    posts: pageItems,
    total: filtered.length,
    page,
    limit,
    hasMore: start + pageItems.length < filtered.length
  });
});

app.get('/api/posts/:id', async c => {
  const posts = await getPosts(c.env);
  const p = posts.find(x => x.id === c.req.param('id'));
  if (!p) return c.json({ error: '文章不存在' }, 404);
  if (p.status !== 'published') {
    const t = await authState(c);
    if (!t) return c.json({ error: '文章不存在' }, 404);
  } else {
    // 浏览量 +1：异步写入，不阻塞响应
    p.views = (p.views || 0) + 1;
    c.executionCtx.waitUntil(putPosts(c.env, posts));
  }
  return c.json(p);
});

app.post('/api/posts', requireAuth, async c => {
  const body = await c.req.json().catch(() => ({}));
  const r = validPost(body);
  if (r.error) return c.json({ error: r.error }, 400);
  const now = Date.now();
  const post = { id: crypto.randomUUID(), ...r.value, views: 0, createdAt: now, updatedAt: now };
  // 兼容历史数据：确保 pinned 字段存在
  if (typeof post.pinned !== 'boolean') post.pinned = false;
  const posts = await getPosts(c.env);
  posts.push(post);
  await putPosts(c.env, posts);
  return c.json(post);
});

app.put('/api/posts/:id', requireAuth, async c => {
  const posts = await getPosts(c.env);
  const p = posts.find(x => x.id === c.req.param('id'));
  if (!p) return c.json({ error: '文章不存在' }, 404);
  const body = await c.req.json().catch(() => ({}));
  const r = validPost(body);
  if (r.error) return c.json({ error: r.error }, 400);
  Object.assign(p, r.value, { updatedAt: Date.now() });
  await putPosts(c.env, posts);
  return c.json(p);
});

app.delete('/api/posts/:id', requireAuth, async c => {
  const posts = await getPosts(c.env);
  const idx = posts.findIndex(x => x.id === c.req.param('id'));
  if (idx < 0) return c.json({ error: '文章不存在' }, 404);
  posts.splice(idx, 1);
  await putPosts(c.env, posts);
  return c.json({ ok: true });
});

/* ================= 图片上传（R2） ================= */
app.post('/api/upload', requireAuth, async c => {
  const body = await c.req.parseBody();
  const file = body['image'];
  if (!(file instanceof File)) return c.json({ error: '未收到文件' }, 400);
  if (!/^image\//.test(file.type)) return c.json({ error: '只能上传图片文件' }, 400);
  if (file.size > 10 * 1024 * 1024) return c.json({ error: '图片不能超过 10MB' }, 400);
  const m = /\.([a-z0-9]+)\s*$/i.exec(file.name || '');
  const ext = m ? '.' + m[1].toLowerCase().slice(0, 8) : '.jpg';
  const key = Date.now() + '-' + randomHex(4) + ext;
  await c.env.BLOG_R2.put(key, await file.arrayBuffer(), { httpMetadata: { contentType: file.type } });
  return c.json({ ok: true, url: '/uploads/' + key });
});

/* ================= 短链接 ================= */
const SHORT_KEY = 'short:';
const SHORT_CHARS = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
function shortCode(n = 6) {
  let s = '';
  const bytes = new Uint8Array(n);
  crypto.getRandomValues(bytes);
  for (let i = 0; i < n; i++) s += SHORT_CHARS[bytes[i] % SHORT_CHARS.length];
  return s;
}
async function getShortUrl(env, code) {
  return env.BLOG_KV.get(SHORT_KEY + code);
}

app.post('/api/shorten', async c => {
  const body = await c.req.json().catch(() => ({}));
  const longUrl = str(body.url);
  if (!longUrl) return c.json({ error: '缺少 url' }, 400);
  // 只允许缩短本站 /post.html?id= 链接，防止滥用（不严格校验 host，兼容自定义域名与本地 dev）
  let ok = false;
  try {
    const u = new URL(longUrl, c.req.url);
    ok = u.pathname === '/post.html' && u.searchParams.get('id');
  } catch {}
  if (!ok) return c.json({ error: '只能缩短本站文章链接' }, 400);

  // 复用：同一个长链接 24h 内生成同一短码，减少 KV 写入
  const cacheKey = SHORT_KEY + 'hash:' + (await sha256(longUrl)).slice(0, 24);
  const cached = await c.env.BLOG_KV.get(cacheKey);
  if (cached) {
    const shortUrl = new URL('/s/' + cached, c.req.url).href;
    return c.json({ ok: true, code: cached, url: shortUrl });
  }

  let code = shortCode();
  for (let i = 0; i < 8; i++) {
    const existing = await getShortUrl(c.env, code);
    if (!existing) break;
    code = shortCode();
  }
  await c.env.BLOG_KV.put(SHORT_KEY + code, longUrl, { expirationTtl: 90 * 24 * 60 * 60 });
  await c.env.BLOG_KV.put(cacheKey, code, { expirationTtl: 24 * 60 * 60 });
  const shortUrl = new URL('/s/' + code, c.req.url).href;
  return c.json({ ok: true, code, url: shortUrl });
});

app.get('/s/:code', async c => {
  const code = str(c.req.param('code'));
  if (!code || code.length < 4) return c.text('Not Found', 404);
  const longUrl = await getShortUrl(c.env, code);
  if (!longUrl) return c.text('短链接不存在或已过期', 404);
  return c.redirect(longUrl, 302);
});

/* ================= 邮件订阅 ================= */
// 订阅者存为 KV 数组 [{email, createdAt}]；不对外暴露订阅量，仅供后台查看
function isValidEmail(v) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v);
}
async function getSubscribers(env) {
  const raw = await env.BLOG_KV.get(KEY.subscribers);
  return raw ? JSON.parse(raw) : [];
}
app.post('/api/subscribe', async c => {
  const body = await c.req.json().catch(() => ({}));
  const email = str(body.email).toLowerCase();
  if (!isValidEmail(email)) return c.json({ error: '请输入有效的邮箱地址' }, 400);
  const list = await getSubscribers(c.env);
  if (list.some(s => s.email === email)) {
    return c.json({ ok: true, count: list.length, subscribed: false, message: '你已订阅过啦' });
  }
  list.push({ email, createdAt: Date.now() });
  await c.env.BLOG_KV.put(KEY.subscribers, JSON.stringify(list));
  return c.json({ ok: true, count: list.length, subscribed: true });
});

// 以下订阅管理接口仅博主可见，需登录
app.get('/api/subscribers', requireAuth, async c => {
  const list = await getSubscribers(c.env);
  list.sort((a, b) => b.createdAt - a.createdAt);
  return c.json({ count: list.length, list });
});
app.delete('/api/subscribers', requireAuth, async c => {
  const body = await c.req.json().catch(() => ({}));
  const email = str(body.email).toLowerCase();
  const list = await getSubscribers(c.env);
  const next = list.filter(s => s.email !== email);
  await c.env.BLOG_KV.put(KEY.subscribers, JSON.stringify(next));
  return c.json({ ok: true, count: next.length });
});

/* ================= 图片访问：R2 优先，未命中回落内置示例图 ================= */
app.get('/uploads/:key', async c => {
  const key = c.req.param('key');
  if (!key || /[/\\]|\.\./.test(key)) return c.text('Bad Request', 400);
  const obj = await c.env.BLOG_R2.get(key);
  if (obj) {
    return new Response(obj.body, {
      headers: {
        'Content-Type': obj.httpMetadata?.contentType || 'application/octet-stream',
        'Cache-Control': 'public, max-age=86400',
        ...(obj.size != null ? { 'Content-Length': String(obj.size) } : {})
      }
    });
  }
  // R2 未命中：回落到静态资产（public/uploads/ 内置的示例图）
  return c.env.ASSETS.fetch(c.req.raw);
});

/* ================= 健康检查 ================= */
app.get('/health', async c => c.json({ ok: true, version: '2024-avatar-sponsor-theme' }));

/* ================= 兜底：静态资产，HTML 直接内联返回以绕过 CDN 缓存 ================= */
app.all('*', async c => {
  const url = new URL(c.req.url);
  const p = url.pathname;
  const htmlPaths = ['/', '/index.html', '/admin', '/admin.html', '/post', '/post.html', '/diag', '/diag.html'];
  if (htmlPaths.includes(p) || p.endsWith('.html')) {
    const html = HTML_ASSETS[p];
    if (html) {
      return new Response(html, {
        headers: {
          'Content-Type': 'text/html',
          'Cache-Control': 'no-store, no-cache, must-revalidate, max-age=0',
          'CDN-Cache-Control': 'no-store',
          'Pragma': 'no-cache',
          'Expires': '0'
        }
      });
    }
  }
  return c.env.ASSETS.fetch(c.req.raw);
});

export default app;
