export const HTML_ASSETS = {
  "/": `<!DOCTYPE html>
<html lang="zh-CN">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>个人博客</title>
  <link rel="icon" href="data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'><text y='0.9em' font-size='90'>✦</text></svg>">
  <link rel="stylesheet" href="/css/style.css?v=11">
</head>
<body>
  <!-- 动漫壁纸背景层 -->
  <div class="anime-bg" id="animeBg"></div>

  <!-- 顶部导航 -->
  <header class="topbar">
    <div class="topbar-inner container">
      <a href="/" class="logo"><span class="logo-mark">✦</span><span id="navSiteName">个人博客</span></a>
      <nav class="nav">
        <a href="/">首页</a>
        <a href="/admin" class="admin-link">后台管理</a>
      </nav>
      <div class="theme-picker" id="themePicker" title="切换主题">
        <span id="themeIcon">🌙</span>
        <span id="themeLabel">深色</span>
      </div>
    </div>
  </header>

  <!-- Hero：头像 + 问候 + 实时时钟 + 天气地点 -->
  <section class="hero">
    <div class="container hero-inner">
      <div class="hero-text">
        <div class="hero-avatar" id="heroAvatarWrap">
          <img src="/uploads/avatar.jpg" alt="头像" id="heroAvatar" onerror="this.style.display='none'">
        </div>
        <p class="greeting" id="greeting">你好</p>
        <h1 class="hero-title">欢迎来到 <span id="heroSiteName">个人博客</span></h1>
        <p class="hero-bio" id="heroBio">正在加载站点信息…</p>
        <div class="clock">
          <span class="clock-time" id="clockTime">--:--:--</span>
          <span class="clock-date" id="clockDate">----</span>
        </div>
      </div>
      <div class="weather-card" id="weatherCard">
        <div class="weather-main">
          <span class="weather-icon" id="weatherIcon">🌍</span>
          <span class="weather-temp" id="weatherTemp">--°C</span>
        </div>
        <div class="weather-desc" id="weatherDesc">正在获取天气…</div>
        <div class="weather-loc">📍 <span id="weatherLoc">定位中…</span></div>
      </div>
    </div>
  </section>

  <!-- 主体：文章列表 + 侧栏 -->
  <main class="container layout">
    <div class="posts-col">
      <div class="posts-header">
        <h2 class="section-title">最新文章</h2>
        <div class="search-box">
          <input type="text" id="searchInput" placeholder="搜索文章…" autocomplete="off">
          <button id="searchBtn" title="搜索">🔍</button>
        </div>
      </div>
      <div id="postList" class="post-list">
        <p class="empty">正在加载文章…</p>
      </div>
      <div class="load-more" id="loadMoreWrap" hidden>
        <button id="loadMoreBtn" class="btn-ghost">加载更多</button>
        <p class="load-more-tip" id="loadMoreTip" hidden>已经到底啦</p>
      </div>
    </div>
    <aside class="side-col">
      <div class="card" id="contacts">
        <h3>📇 联系方式</h3>
        <div class="contact-list" id="contactList"><p class="empty">加载中…</p></div>
      </div>
      <div class="card" id="sponsors">
        <h3>☕ 赞助支持</h3>
        <ul class="sponsor-list" id="sponsorList"><p class="empty">加载中…</p></ul>
      </div>
      <div class="card" id="links">
        <h3>🔗 友情链接</h3>
        <ul class="link-list" id="linkList"><p class="empty">加载中…</p></ul>
      </div>
      <div class="card" id="subscribeCard">
        <h3>📬 订阅更新</h3>
        <p class="subscribe-tip">有新文章时，第一时间发到你的邮箱 💌</p>
        <form id="subscribeForm" class="subscribe-form" novalidate>
          <input type="email" id="subscribeEmail" placeholder="输入你的邮箱" autocomplete="email" required>
          <button type="submit" id="subscribeBtn">订阅</button>
        </form>
        <p class="subscribe-hint" id="subscribeHint"></p>
      </div>
    </aside>
  </main>

  <footer class="footer">
    <p>© <span id="footerYear">2026</span> <span id="footerSiteName">个人博客</span> · 每一次记录都算数 ✦</p>
  </footer>

  <div id="toast"></div>
  <div class="modal-overlay" id="imgPreviewModal" hidden>
    <div class="img-preview-modal">
      <img id="imgPreviewSrc" src="" alt="">
      <button class="img-preview-close" id="imgPreviewClose" title="关闭">✕</button>
    </div>
  </div>
  <script src="/js/main.js?v=11"></script>
</body>
</html>
`,
  "/index.html": `<!DOCTYPE html>
<html lang="zh-CN">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>个人博客</title>
  <link rel="icon" href="data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'><text y='0.9em' font-size='90'>✦</text></svg>">
  <link rel="stylesheet" href="/css/style.css?v=11">
</head>
<body>
  <!-- 动漫壁纸背景层 -->
  <div class="anime-bg" id="animeBg"></div>

  <!-- 顶部导航 -->
  <header class="topbar">
    <div class="topbar-inner container">
      <a href="/" class="logo"><span class="logo-mark">✦</span><span id="navSiteName">个人博客</span></a>
      <nav class="nav">
        <a href="/">首页</a>
        <a href="/admin" class="admin-link">后台管理</a>
      </nav>
      <div class="theme-picker" id="themePicker" title="切换主题">
        <span id="themeIcon">🌙</span>
        <span id="themeLabel">深色</span>
      </div>
    </div>
  </header>

  <!-- Hero：头像 + 问候 + 实时时钟 + 天气地点 -->
  <section class="hero">
    <div class="container hero-inner">
      <div class="hero-text">
        <div class="hero-avatar" id="heroAvatarWrap">
          <img src="/uploads/avatar.jpg" alt="头像" id="heroAvatar" onerror="this.style.display='none'">
        </div>
        <p class="greeting" id="greeting">你好</p>
        <h1 class="hero-title">欢迎来到 <span id="heroSiteName">个人博客</span></h1>
        <p class="hero-bio" id="heroBio">正在加载站点信息…</p>
        <div class="clock">
          <span class="clock-time" id="clockTime">--:--:--</span>
          <span class="clock-date" id="clockDate">----</span>
        </div>
      </div>
      <div class="weather-card" id="weatherCard">
        <div class="weather-main">
          <span class="weather-icon" id="weatherIcon">🌍</span>
          <span class="weather-temp" id="weatherTemp">--°C</span>
        </div>
        <div class="weather-desc" id="weatherDesc">正在获取天气…</div>
        <div class="weather-loc">📍 <span id="weatherLoc">定位中…</span></div>
      </div>
    </div>
  </section>

  <!-- 主体：文章列表 + 侧栏 -->
  <main class="container layout">
    <div class="posts-col">
      <div class="posts-header">
        <h2 class="section-title">最新文章</h2>
        <div class="search-box">
          <input type="text" id="searchInput" placeholder="搜索文章…" autocomplete="off">
          <button id="searchBtn" title="搜索">🔍</button>
        </div>
      </div>
      <div id="postList" class="post-list">
        <p class="empty">正在加载文章…</p>
      </div>
      <div class="load-more" id="loadMoreWrap" hidden>
        <button id="loadMoreBtn" class="btn-ghost">加载更多</button>
        <p class="load-more-tip" id="loadMoreTip" hidden>已经到底啦</p>
      </div>
    </div>
    <aside class="side-col">
      <div class="card" id="contacts">
        <h3>📇 联系方式</h3>
        <div class="contact-list" id="contactList"><p class="empty">加载中…</p></div>
      </div>
      <div class="card" id="sponsors">
        <h3>☕ 赞助支持</h3>
        <ul class="sponsor-list" id="sponsorList"><p class="empty">加载中…</p></ul>
      </div>
      <div class="card" id="links">
        <h3>🔗 友情链接</h3>
        <ul class="link-list" id="linkList"><p class="empty">加载中…</p></ul>
      </div>
      <div class="card" id="subscribeCard">
        <h3>📬 订阅更新</h3>
        <p class="subscribe-tip">有新文章时，第一时间发到你的邮箱 💌</p>
        <form id="subscribeForm" class="subscribe-form" novalidate>
          <input type="email" id="subscribeEmail" placeholder="输入你的邮箱" autocomplete="email" required>
          <button type="submit" id="subscribeBtn">订阅</button>
        </form>
        <p class="subscribe-hint" id="subscribeHint"></p>
      </div>
    </aside>
  </main>

  <footer class="footer">
    <p>© <span id="footerYear">2026</span> <span id="footerSiteName">个人博客</span> · 每一次记录都算数 ✦</p>
  </footer>

  <div id="toast"></div>
  <div class="modal-overlay" id="imgPreviewModal" hidden>
    <div class="img-preview-modal">
      <img id="imgPreviewSrc" src="" alt="">
      <button class="img-preview-close" id="imgPreviewClose" title="关闭">✕</button>
    </div>
  </div>
  <script src="/js/main.js?v=11"></script>
</body>
</html>
`,
  "/admin": `<!DOCTYPE html>
<html lang="zh-CN">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>后台管理 - 个人博客</title>
  <link rel="icon" href="data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'><text y='0.9em' font-size='90'>✦</text></svg>">
  <link rel="stylesheet" href="/css/style.css?v=11">
  <meta http-equiv="Cache-Control" content="no-store, no-cache, must-revalidate">
  <meta http-equiv="Pragma" content="no-cache">
  <meta http-equiv="Expires" content="0">
  <style>/* 内置 CSS 变量，确保即使外部样式未加载主题也不崩 */
/* 某些浏览器/UA 对 hidden 属性默认 display:none 优先级不够，显式补强 */
[hidden], .hidden { display: none !important; }
html, body { -webkit-tap-highlight-color: transparent; }
body.admin-body { visibility: visible; }
#loginView, #adminView { transition: opacity .15s ease; }
#loginView[hidden], #adminView[hidden] { opacity: 0; pointer-events: none; }
#loginView:not([hidden]), #adminView:not([hidden]) { opacity: 1; pointer-events: auto; }
:root {
  --bg: #f4f5fb;
  --bg-soft: #eceef8;
  --card: #ffffff;
  --text: #1f2430;
  --text-light: #6b7280;
  --primary: #5b5bd6;
  --primary-2: #8b5cf6;
  --primary-soft: rgba(91, 91, 214, 0.09);
  --border: #e6e8f0;
  --shadow: 0 1px 2px rgba(23, 25, 60, 0.05), 0 10px 30px rgba(23, 25, 60, 0.07);
  --shadow-hover: 0 4px 10px rgba(23, 25, 60, 0.08), 0 16px 40px rgba(91, 91, 214, 0.16);
  --radius: 16px;
}
[data-theme="dark"] {
  --bg: #0e1017;
  --bg-soft: #161927;
  --card: #171a26;
  --text: #e6e8f0;
  --text-light: #9aa1b5;
  --primary: #8789f5;
  --primary-2: #a78bfa;
  --primary-soft: rgba(135, 137, 245, 0.14);
  --border: #252a3a;
  --shadow: 0 1px 2px rgba(0, 0, 0, 0.3), 0 10px 30px rgba(0, 0, 0, 0.35);
  --shadow-hover: 0 4px 10px rgba(0, 0, 0, 0.35), 0 16px 40px rgba(135, 137, 245, 0.2);
}
[data-theme="glass"] {
  --bg: #eef1ff;
  --bg-soft: rgba(255, 255, 255, 0.55);
  --card: rgba(255, 255, 255, 0.72);
  --text: #1f2430;
  --text-light: #5b6280;
  --primary: #5b5bd6;
  --primary-2: #8b5cf6;
  --primary-soft: rgba(91, 91, 214, 0.12);
  --border: rgba(255, 255, 255, 0.55);
  --shadow: 0 8px 32px rgba(31, 36, 80, 0.12);
  --shadow-hover: 0 12px 44px rgba(91, 91, 214, 0.22);
}
[data-theme="tech"] {
  --bg: #05070a;
  --bg-soft: #0c0f17;
  --card: #0a0d14;
  --text: #e8f2ff;
  --text-light: #7a8aa8;
  --primary: #00f0ff;
  --primary-2: #7c3aed;
  --primary-soft: rgba(0, 240, 255, 0.12);
  --border: #1b2440;
  --shadow: 0 0 14px rgba(0, 240, 255, 0.12), 0 10px 30px rgba(0, 0, 0, 0.45);
  --shadow-hover: 0 0 22px rgba(0, 240, 255, 0.22), 0 12px 40px rgba(0, 0, 0, 0.5);
}
[data-theme="neumorph"] {
  --bg: #e0e5ec;
  --bg-soft: #e0e5ec;
  --card: rgba(224, 229, 236, 0.78);
  --text: #3a3f4b;
  --text-light: #6b7285;
  --primary: #5b5bd6;
  --primary-2: #8b5cf6;
  --primary-soft: rgba(91, 91, 214, 0.12);
  --border: rgba(255, 255, 255, 0.45);
  --shadow: 9px 9px 18px #b8b9be, -9px -9px 18px #ffffff;
  --shadow-hover: 12px 12px 24px #b0b1b6, -12px -12px 24px #ffffff;
}
</style>
<style data-admin-inline>
/* ================= 后台整体布局 ================= */
.admin-body { background: var(--bg); min-height: 100vh; }

.admin-shell { display: flex; min-height: 100vh; }

.sidebar {
  width: 232px;
  flex-shrink: 0;
  background: var(--card);
  border-right: 1px solid var(--border);
  padding: 20px 14px;
  position: sticky;
  top: 0;
  height: 100vh;
  display: flex;
  flex-direction: column;
}
.side-brand {
  display: flex; align-items: center; gap: 10px;
  font-weight: 700; font-size: 17px;
  padding: 4px 10px 10px;
}
.side-theme {
  display: inline-flex; align-items: center; gap: 6px;
  margin: 0 10px 14px;
  padding: 6px 12px;
  border-radius: 999px;
  border: 1px solid var(--border);
  background: var(--bg);
  color: var(--text-light);
  font-size: 13px;
  cursor: pointer;
  user-select: none;
  transition: 0.2s;
}
.side-theme:hover { border-color: var(--primary); color: var(--primary); }
.side-nav { display: flex; flex-direction: column; gap: 4px; }
.side-nav a {
  padding: 10px 14px;
  border-radius: 11px;
  color: var(--text-light);
  font-size: 14.5px;
  cursor: pointer;
  transition: 0.18s;
}
.side-nav a:hover { background: var(--primary-soft); color: var(--text); }
.side-nav a.active {
  background: linear-gradient(135deg, var(--primary), var(--primary-2));
  color: #fff;
  font-weight: 600;
}
.side-nav a.danger:hover { color: #e11d48; background: rgba(225, 29, 72, 0.09); }
.side-nav hr { border: none; border-top: 1px solid var(--border); margin: 12px 0; }

.admin-main { flex: 1; padding: 28px 34px 60px; min-width: 0; }
.view { max-width: 980px; }

.page-head { display: flex; align-items: center; gap: 14px; margin-bottom: 8px; flex-wrap: wrap; }
.page-title { font-size: 22px; font-weight: 800; margin: 0 0 22px; }
.sub-title { font-size: 16px; font-weight: 700; margin: 0 0 14px; }
.draft-flag {
  font-size: 12.5px;
  color: #d97706;
  background: rgba(217, 119, 6, 0.12);
  padding: 3px 12px;
  border-radius: 999px;
}

/* ================= 登录页 ================= */
.login-wrap {
  min-height: 100vh;
  display: grid;
  place-items: center;
  background:
    radial-gradient(700px 350px at 80% -10%, var(--primary-soft), transparent 70%),
    var(--bg);
  padding: 20px;
}
.login-card {
  width: 100%;
  max-width: 400px;
  background: var(--card);
  border: 1px solid var(--border);
  border-radius: 20px;
  box-shadow: var(--shadow);
  padding: 38px 36px 30px;
  display: flex;
  flex-direction: column;
  gap: 14px;
}
.login-card h2 { margin: 0; text-align: center; font-size: 22px; }
.login-logo {
  width: 54px; height: 54px;
  margin: 0 auto 6px;
  border-radius: 16px;
  display: grid; place-items: center;
  background: linear-gradient(135deg, var(--primary), var(--primary-2));
  color: #fff; font-size: 26px;
}
.login-tip { margin: 0; text-align: center; color: var(--text-light); font-size: 12.5px; }
.login-card label { display: flex; flex-direction: column; gap: 6px; font-size: 13.5px; color: var(--text-light); }
.login-card input, .form-item input, .form-item select, .tb-select {
  border: 1px solid var(--border);
  background: var(--bg);
  color: var(--text);
  border-radius: 10px;
  padding: 10px 14px;
  font-size: 14.5px;
  outline: none;
  transition: 0.18s;
  width: 100%;
}
.login-card input:focus, .form-item input:focus, .form-item select:focus, .tb-select:focus {
  border-color: var(--primary);
  box-shadow: 0 0 0 3px var(--primary-soft);
}
.login-err { color: #e11d48; font-size: 13px; margin: 0; min-height: 18px; text-align: center; }
.login-back { text-align: center; color: var(--text-light); font-size: 13px; }
.login-back:hover { color: var(--primary); }

/* ================= 按钮 ================= */
.btn {
  border: none;
  border-radius: 11px;
  padding: 10px 20px;
  font-size: 14.5px;
  font-weight: 600;
  cursor: pointer;
  transition: 0.18s;
  font-family: inherit;
}
.btn-primary {
  background: linear-gradient(135deg, var(--primary), var(--primary-2));
  color: #fff;
  box-shadow: 0 4px 14px rgba(91, 91, 214, 0.35);
}
.btn-primary:hover { filter: brightness(1.08); transform: translateY(-1px); }
.btn-primary:disabled { opacity: 0.6; cursor: not-allowed; transform: none; }
.btn-ghost {
  background: var(--card);
  border: 1px solid var(--border);
  color: var(--text);
}
.btn-ghost:hover { border-color: var(--primary); color: var(--primary); }
.btn-sm { padding: 8px 14px; font-size: 13px; }
.btn-block { width: 100%; }
.btn-lg { padding: 12px 32px; font-size: 15px; }
.btn-danger-link { background: none; border: none; color: #e11d48; cursor: pointer; font-size: 13.5px; padding: 4px 8px; border-radius: 8px; }
.btn-danger-link:hover { background: rgba(225, 29, 72, 0.09); }

/* ================= 统计卡片 ================= */
.stats { display: grid; grid-template-columns: repeat(4, 1fr); gap: 16px; margin-bottom: 28px; }
.stat-card { padding: 22px 24px; display: flex; flex-direction: column; gap: 4px; }
.stat-num { font-size: 30px; font-weight: 800; background: linear-gradient(120deg, var(--primary), var(--primary-2)); -webkit-background-clip: text; background-clip: text; color: transparent; }
.stat-label { font-size: 13px; color: var(--text-light); }

/* ================= 数据表格 ================= */
.table-wrap { padding: 8px 14px; overflow-x: auto; }
.data-table { width: 100%; border-collapse: collapse; font-size: 14px; }
.data-table th {
  text-align: left;
  color: var(--text-light);
  font-weight: 600;
  font-size: 13px;
  padding: 12px 10px;
  border-bottom: 1px solid var(--border);
  white-space: nowrap;
}
.data-table td { padding: 13px 10px; border-bottom: 1px solid var(--border); vertical-align: middle; }
.data-table tr:last-child td { border-bottom: none; }
.data-table tr:hover td { background: var(--primary-soft); }
.td-title { font-weight: 600; max-width: 320px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.td-title a:hover { color: var(--primary); }
.status-pill {
  font-size: 12px;
  padding: 3px 10px;
  border-radius: 999px;
  font-weight: 600;
  white-space: nowrap;
}
.status-pill.published { color: #16a34a; background: rgba(22, 163, 74, 0.12); }
.status-pill.draft { color: #d97706; background: rgba(217, 119, 6, 0.14); }
.pin-toggle {
  border: 1px solid var(--border);
  background: var(--card);
  color: var(--text-light);
  border-radius: 7px;
  padding: 4px 9px;
  font-size: 12.5px;
  cursor: pointer;
  transition: 0.18s;
}
.pin-toggle:hover { border-color: var(--primary); color: var(--primary); }
.pin-toggle.on {
  background: linear-gradient(120deg, rgba(99,102,241,0.16), rgba(14,165,233,0.16));
  border-color: var(--primary);
  color: var(--primary);
  font-weight: 600;
}
.row-pinned { background: rgba(99,102,241,0.05); }
.td-actions { white-space: nowrap; }
.td-actions button { margin-right: 4px; }

/* ================= 表单 ================= */
.form-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 16px 20px; margin-bottom: 22px; }
.form-item { display: flex; flex-direction: column; gap: 7px; }
.form-item label { font-size: 13.5px; color: var(--text-light); font-weight: 600; }
.span-2 { grid-column: span 2; }
.inline-row { display: flex; gap: 10px; }
.inline-row input { flex: 1; }
.inline-row .btn { white-space: nowrap; }
textarea.form-control { resize: vertical; min-height: 90px; }

/* ================= 富文本编辑器 ================= */
.editor-wrap { padding: 0; overflow: hidden; }
.editor-toolbar {
  display: flex;
  align-items: center;
  flex-wrap: wrap;
  gap: 5px;
  padding: 10px 12px;
  border-bottom: 1px solid var(--border);
  background: var(--bg-soft);
}
.tb-select { width: auto; padding: 7px 10px; font-size: 13px; border-radius: 8px; }
.tb-btn {
  min-width: 34px;
  height: 34px;
  padding: 0 9px;
  border: 1px solid transparent;
  border-radius: 9px;
  background: var(--card);
  color: var(--text);
  cursor: pointer;
  font-size: 14px;
  font-family: inherit;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  transition: 0.15s;
}
.tb-btn:hover { border-color: var(--primary); color: var(--primary); background: var(--primary-soft); }
.tb-btn:active { transform: scale(0.94); }
.tb-sep { width: 1px; height: 22px; background: var(--border); margin: 0 5px; }
.tb-color { position: relative; overflow: hidden; gap: 5px; }
.tb-color input[type="color"] {
  position: absolute;
  inset: 0;
  opacity: 0;
  cursor: pointer;
  border: none;
  padding: 0;
}
.color-preview { font-weight: 800; font-size: 15px; }
#forePreview { color: #e11d48; }
.mark-preview { font-size: 14px; }
.color-dots {
  display: inline-flex;
  align-items: center;
  gap: 5px;
  margin: 0 2px;
}
.color-dot {
  width: 18px; height: 18px;
  border-radius: 50%;
  border: 1px solid rgba(128,128,128,0.25);
  cursor: pointer;
  padding: 0;
  flex-shrink: 0;
  transition: transform 0.15s;
}
.color-dot:active { transform: scale(0.85); }

.rich-editor {
  min-height: 380px;
  max-height: 60vh;
  overflow-y: auto;
  padding: 24px 28px;
  font-size: 16px;
  line-height: 1.8;
  outline: none;
  background: var(--card);
}
.rich-editor:focus { background: var(--card); }
.rich-editor:empty::before {
  content: attr(data-placeholder);
  color: var(--text-light);
  pointer-events: none;
}
/* 编辑器内部内容样式（与前台正文一致） */
.rich-editor h1, .rich-editor h2, .rich-editor h3 { line-height: 1.4; margin: 1.2em 0 0.5em; }
.rich-editor h1 { font-size: 26px; }
.rich-editor h2 { font-size: 22px; }
.rich-editor h3 { font-size: 18px; }
.rich-editor p { margin: 0.6em 0; }
.rich-editor img { max-width: 100%; border-radius: 10px; margin: 8px 0; }
.rich-editor a { color: var(--primary); text-decoration: underline; text-underline-offset: 3px; }
.rich-editor blockquote {
  margin: 1em 0; padding: 10px 16px;
  border-left: 4px solid var(--primary);
  background: var(--primary-soft);
  border-radius: 0 10px 10px 0;
}
.rich-editor pre {
  background: #191b29; color: #e6e8f0;
  padding: 14px 16px; border-radius: 10px;
  overflow-x: auto; font-size: 13.5px; line-height: 1.6;
}
.rich-editor code { font-family: Consolas, Monaco, monospace; background: var(--bg-soft); padding: 2px 6px; border-radius: 5px; font-size: 0.9em; }
.rich-editor pre code { background: none; padding: 0; }
.rich-editor ul, .rich-editor ol { padding-left: 1.5em; }
.rich-editor hr { border: none; border-top: 1px solid var(--border); }
.rich-editor mark { padding: 0 3px; border-radius: 4px; }

.editor-hint {
  padding: 10px 16px;
  font-size: 12.5px;
  color: var(--text-light);
  border-top: 1px solid var(--border);
  background: var(--bg-soft);
}
.editor-actions { display: flex; align-items: center; gap: 14px; margin-top: 20px; }
.save-msg { font-size: 13.5px; color: var(--text-light); }

/* ================= 弹窗 ================= */
.modal-overlay {
  position: fixed;
  inset: 0;
  background: rgba(15, 17, 25, 0.55);
  backdrop-filter: blur(4px);
  display: none;
  place-items: center;
  z-index: 100;
  padding: 20px;
}
.modal-overlay:not([hidden]) { display: grid; }
.modal { width: 100%; max-width: 430px; padding: 26px 26px 22px; border-radius: 18px; }
.modal h3 { margin: 0 0 18px; font-size: 18px; }
.modal .form-item { margin-bottom: 14px; }
.modal-actions { display: flex; justify-content: flex-end; gap: 10px; margin-top: 18px; }
.checkbox-row { display: flex; align-items: center; gap: 8px; font-size: 14px; color: var(--text-light); margin-top: 4px; }

.tabs { display: flex; gap: 6px; margin-bottom: 16px; }
.tab {
  border: none;
  background: var(--bg-soft);
  color: var(--text-light);
  padding: 8px 18px;
  border-radius: 999px;
  font-size: 13.5px;
  cursor: pointer;
  font-family: inherit;
}
.tab.active { background: linear-gradient(135deg, var(--primary), var(--primary-2)); color: #fff; font-weight: 600; }
.tab-pane { display: flex; flex-direction: column; gap: 10px; }

.upload-area {
  display: flex;
  align-items: center;
  justify-content: center;
  text-align: center;
  padding: 30px 18px;
  border: 2px dashed var(--border);
  border-radius: 12px;
  color: var(--text-light);
  font-size: 13.5px;
  cursor: pointer;
  transition: 0.2s;
}
.upload-area:hover { border-color: var(--primary); color: var(--primary); background: var(--primary-soft); }
.upload-status { font-size: 13px; color: var(--primary); min-height: 18px; }

/* ================= 站点设置 ================= */
.settings-block { padding: 24px 26px; margin-bottom: 22px; }
.block-head { display: flex; justify-content: space-between; align-items: center; margin-bottom: 6px; }
.block-tip { color: var(--text-light); font-size: 12.5px; margin: 0 0 14px; }

.row-grid {
  display: grid;
  gap: 10px;
  padding: 12px 14px;
  border: 1px solid var(--border);
  border-radius: 12px;
  margin-bottom: 10px;
  background: var(--bg);
}
.contact-row { grid-template-columns: 130px 110px 1fr 1.2fr 40px; align-items: center; }
.link-row { grid-template-columns: 160px 1.6fr 1fr 40px; align-items: center; }
.sponsor-row { grid-template-columns: 160px 110px 1fr 1fr 40px; align-items: center; }
.sponsor-img-wrap { display: flex; flex-direction: column; align-items: center; gap: 6px; }
.sponsor-preview {
  width: 70px; height: 70px; object-fit: cover; border-radius: 10px;
  border: 1px solid var(--border); background: var(--bg-soft);
}
.sponsor-placeholder {
  width: 70px; height: 70px; border-radius: 10px; background: var(--bg-soft);
  display: grid; place-items: center; font-size: 28px; border: 1px dashed var(--border);
}
.sponsor-upload { white-space: nowrap; }
.row-grid input, .row-grid select {
  border: 1px solid var(--border);
  background: var(--card);
  color: var(--text);
  border-radius: 8px;
  padding: 8px 10px;
  font-size: 13.5px;
  outline: none;
  width: 100%;
}
.row-grid input:focus { border-color: var(--primary); }
.row-del {
  border: none;
  background: none;
  color: #e11d48;
  font-size: 16px;
  cursor: pointer;
  height: 34px;
  border-radius: 8px;
}
.row-del:hover { background: rgba(225, 29, 72, 0.09); }

/* ================= Toast ================= */
#toast {
  position: fixed;
  left: 50%; bottom: 34px;
  transform: translateX(-50%) translateY(20px);
  background: var(--text);
  color: var(--bg);
  padding: 10px 22px;
  border-radius: 999px;
  font-size: 14px;
  opacity: 0;
  pointer-events: none;
  transition: 0.25s;
  z-index: 999;
}
#toast.show { opacity: 1; transform: translateX(-50%) translateY(0); }

/* ================= 响应式 ================= */
@media (max-width: 980px) {
  .stats { grid-template-columns: repeat(2, 1fr); }
  .contact-row { grid-template-columns: 120px 1fr 1fr 40px; }
  .contact-row .c-link { grid-column: span 3; }
}
@media (max-width: 860px) {
  .admin-shell { flex-direction: column; }
  .sidebar { width: 100%; height: auto; position: static; padding: 12px; }
  .side-brand { padding: 6px 10px 10px; }
  .side-nav { flex-direction: row; flex-wrap: wrap; }
  .side-nav hr { display: none; }
  .side-nav a { padding: 8px 12px; font-size: 13.5px; }
  .admin-main { padding: 20px 16px 40px; }
  .form-grid { grid-template-columns: 1fr; }
  .span-2 { grid-column: span 1; }
  .contact-row, .link-row, .sponsor-row { grid-template-columns: 1fr 1fr 40px; }
  .contact-row .c-value, .contact-row .c-link, .link-row .l-url, .link-row .l-desc,
  .sponsor-row .l-url, .sponsor-row .l-desc { grid-column: span 2; }
  .sponsor-img-wrap { grid-column: span 2; flex-direction: row; justify-content: flex-start; }
}

/* 玻璃/拟态主题下后台元素也应用毛玻璃与拟态阴影 */
[data-theme="glass"] .sidebar,
[data-theme="glass"] .login-card,
[data-theme="glass"] .card,
[data-theme="glass"] .modal,
[data-theme="glass"] .tb-btn,
[data-theme="glass"] .tb-select,
[data-theme="glass"] input,
[data-theme="glass"] select,
[data-theme="glass"] textarea {
  backdrop-filter: blur(16px);
  -webkit-backdrop-filter: blur(16px);
  background: var(--card);
  border: 1px solid rgba(255, 255, 255, 0.6);
}
[data-theme="glass"] .rich-editor { background: var(--card); }

[data-theme="neumorph"] .sidebar,
[data-theme="neumorph"] .login-card,
[data-theme="neumorph"] .card,
[data-theme="neumorph"] .modal,
[data-theme="neumorph"] .settings-block,
[data-theme="neumorph"] .editor-wrap {
  box-shadow: var(--shadow);
  border: 1px solid rgba(255, 255, 255, 0.55);
  background: var(--card);
  backdrop-filter: blur(12px);
}
[data-theme="neumorph"] .tb-btn,
[data-theme="neumorph"] .tb-select,
[data-theme="neumorph"] input,
[data-theme="neumorph"] select,
[data-theme="neumorph"] textarea {
  box-shadow: inset 3px 3px 6px #b8b9be, inset -3px -3px 6px #ffffff;
  border: none;
  background: var(--bg);
}
[data-theme="neumorph"] .btn-primary {
  box-shadow: 6px 6px 12px #b8b9be, -6px -6px 12px #ffffff;
}
[data-theme="neumorph"] .btn-ghost:hover,
[data-theme="neumorph"] .tb-btn:hover {
  box-shadow: 4px 4px 8px #b8b9be, -4px -4px 8px #ffffff;
}

[data-theme="tech"] .sidebar,
[data-theme="tech"] .login-card,
[data-theme="tech"] .card,
[data-theme="tech"] .modal,
[data-theme="tech"] .editor-wrap {
  border: 1px solid rgba(0, 240, 255, 0.18);
  box-shadow: 0 0 18px rgba(0, 240, 255, 0.08);
  background: var(--card);
}
[data-theme="tech"] .tb-btn,
[data-theme="tech"] .tb-select,
[data-theme="tech"] input,
[data-theme="tech"] select,
[data-theme="tech"] textarea {
  border: 1px solid rgba(0, 240, 255, 0.22);
  background: var(--bg);
}
[data-theme="tech"] .rich-editor { background: var(--card); }

</style>
</head>
<body class="admin-body">

  <!-- ============ 登录视图 ============ -->
  <div id="loginView" class="login-wrap">
    <form class="login-card" id="loginForm">
      <div class="login-logo"><span>✦</span></div>
      <h2>博客后台登录</h2>
      <p class="login-tip">默认账号 admin，密码 admin123（登录后可修改）</p>
      <label>用户名
        <input id="loginUser" autocomplete="username" placeholder="请输入用户名" required>
      </label>
      <label>密码
        <input id="loginPass" type="password" autocomplete="current-password" placeholder="请输入密码" required>
      </label>
      <button class="btn btn-primary btn-block" id="loginBtn" type="submit">登 录</button>
      <p class="login-err" id="loginErr"></p>
      <a class="login-back" href="/">← 返回博客首页</a>
    </form>
  </div>

  <!-- ============ 管理视图 ============ -->
  <div id="adminView" class="admin-shell" hidden>
    <aside class="sidebar">
      <div class="side-brand"><span class="logo-mark">✦</span><span id="brandName">博客后台</span></div>
      <div class="side-theme" id="adminThemePicker" title="切换主题">
        <span id="adminThemeIcon">🌙</span><span id="adminThemeLabel">深色</span>
      </div>
      <nav class="side-nav">
        <a data-view="dashboard" class="active">📊 仪表盘</a>
        <a data-view="posts">📚 文章管理</a>
        <a data-view="editor" id="navNewPost">✍️ 写文章</a>
        <a data-view="settings">⚙️ 站点设置</a>
        <a data-view="subs">📧 订阅管理</a>
        <hr>
        <a href="/" target="_blank">🏠 查看博客</a>
        <a id="logoutBtn" class="danger">🚪 退出登录</a>
      </nav>
    </aside>

    <div class="admin-main">
      <!-- 仪表盘 -->
      <section id="view-dashboard" class="view">
        <h2 class="page-title">仪表盘</h2>
        <div class="stats">
          <div class="stat-card card"><span class="stat-num" id="statTotal">0</span><span class="stat-label">文章总数</span></div>
          <div class="stat-card card"><span class="stat-num" id="statPublished">0</span><span class="stat-label">已发布</span></div>
          <div class="stat-card card"><span class="stat-num" id="statDraft">0</span><span class="stat-label">草稿箱</span></div>
          <div class="stat-card card"><span class="stat-num" id="statViews">0</span><span class="stat-label">累计阅读</span></div>
        </div>
        <h3 class="sub-title">最近文章</h3>
        <div class="table-wrap card"><table class="data-table" id="recentTable"></table></div>
      </section>

      <!-- 文章管理 -->
      <section id="view-posts" class="view" hidden>
        <div class="page-head">
          <h2 class="page-title">文章管理</h2>
          <button class="btn btn-primary" id="btnNewPost">＋ 新建文章</button>
        </div>
        <div class="table-wrap card"><table class="data-table" id="postsTable"></table></div>
      </section>

      <!-- 编辑器 -->
      <section id="view-editor" class="view" hidden>
        <div class="page-head">
          <h2 class="page-title" id="editorMode">写文章</h2>
          <span class="draft-flag" id="editingFlag" hidden>正在编辑已有文章</span>
        </div>

        <div class="form-grid">
          <div class="form-item span-2">
            <label>标题 *</label>
            <input id="fTitle" placeholder="请输入文章标题">
          </div>
          <div class="form-item span-2">
            <label>摘要</label>
            <input id="fSummary" placeholder="留空将自动截取正文前 120 字">
          </div>
          <div class="form-item">
            <label>封面图</label>
            <div class="inline-row">
              <input id="fCover" placeholder="封面图 URL，可留空">
              <button type="button" class="btn btn-ghost btn-sm" id="btnCoverUpload">上传</button>
              <input type="file" id="fCoverFile" accept="image/*" hidden>
            </div>
          </div>
          <div class="form-item">
            <label>标签</label>
            <input id="fTags" placeholder="多个标签用逗号分隔，如：生活, 摄影">
          </div>
          <div class="form-item">
            <label>发布状态</label>
            <select id="fStatus">
              <option value="published">✅ 立即发布</option>
              <option value="draft">📝 存为草稿</option>
            </select>
          </div>
        </div>

        <!-- 富文本编辑器 -->
        <div class="editor-wrap card">
          <div class="editor-toolbar" id="toolbar">
            <select id="blockType" class="tb-select" title="段落格式">
              <option value="p">正文</option>
              <option value="h1">标题一</option>
              <option value="h2">标题二</option>
              <option value="h3">标题三</option>
              <option value="blockquote">引用</option>
              <option value="pre">代码块</option>
            </select>
            <select id="fontSizeSel" class="tb-select" title="字号大小（先选大小可直接开始打字，或先选中文字再改）">
              <option value="">字号…</option>
              <option value="12">12px 很小</option>
              <option value="14">14px 小</option>
              <option value="16">16px 标准</option>
              <option value="18">18px 中大</option>
              <option value="20">20px 大</option>
              <option value="24">24px 较大</option>
              <option value="28">28px 大号</option>
              <option value="32">32px 特大</option>
              <option value="36">36px 超大</option>
              <option value="clear">清除字号</option>
            </select>
            <span class="tb-sep"></span>
            <button type="button" class="tb-btn" data-cmd="bold" title="加粗"><b>B</b></button>
            <button type="button" class="tb-btn" data-cmd="italic" title="斜体"><i>I</i></button>
            <button type="button" class="tb-btn" data-cmd="underline" title="下划线"><u>U</u></button>
            <button type="button" class="tb-btn" data-cmd="strikeThrough" title="删除线（划线）"><s>S</s></button>
            <span class="tb-sep"></span>
            <label class="tb-btn tb-color" title="文字颜色">
              <span class="color-preview" id="forePreview">A</span>
              <input type="color" id="foreColorInput" value="#e11d48">
            </label>
            <span class="color-dots" id="forePalette">
              <button type="button" class="color-dot" style="background:#e11d48" data-color="#e11d48" title="红"></button>
              <button type="button" class="color-dot" style="background:#2563eb" data-color="#2563eb" title="蓝"></button>
              <button type="button" class="color-dot" style="background:#16a34a" data-color="#16a34a" title="绿"></button>
              <button type="button" class="color-dot" style="background:#9333ea" data-color="#9333ea" title="紫"></button>
              <button type="button" class="color-dot" style="background:#ea580c" data-color="#ea580c" title="橙"></button>
              <button type="button" class="color-dot" style="background:#0f172a" data-color="#0f172a" title="黑"></button>
            </span>
            <label class="tb-btn tb-color" title="荧光笔标记（高亮背景）">
              <span class="color-preview mark-preview" id="hilitePreview">🖍</span>
              <input type="color" id="hiliteColorInput" value="#fde047">
            </label>
            <span class="color-dots" id="hilitePalette">
              <button type="button" class="color-dot" style="background:#fde047" data-color="#fde047" title="黄"></button>
              <button type="button" class="color-dot" style="background:#86efac" data-color="#86efac" title="绿"></button>
              <button type="button" class="color-dot" style="background:#93c5fd" data-color="#93c5fd" title="蓝"></button>
              <button type="button" class="color-dot" style="background:#fca5a5" data-color="#fca5a5" title="红"></button>
              <button type="button" class="color-dot" style="background:#d8b4fe" data-color="#d8b4fe" title="紫"></button>
              <button type="button" class="color-dot" style="background:#fdba74" data-color="#fdba74" title="橙"></button>
            </span>
            <span class="tb-sep"></span>
            <button type="button" class="tb-btn" data-cmd="insertUnorderedList" title="无序列表">• ≡</button>
            <button type="button" class="tb-btn" data-cmd="insertOrderedList" title="有序列表">1. ≡</button>
            <button type="button" class="tb-btn" data-cmd="justifyLeft" title="左对齐">⬅</button>
            <button type="button" class="tb-btn" data-cmd="justifyCenter" title="居中">≡</button>
            <button type="button" class="tb-btn" data-cmd="justifyRight" title="右对齐">➡</button>
            <span class="tb-sep"></span>
            <button type="button" class="tb-btn" id="btnInsertLink" title="插入可点击链接">🔗 链接</button>
            <button type="button" class="tb-btn" id="btnInsertImage" title="插入图片（上传/外链/粘贴）">🖼️ 图片</button>
            <button type="button" class="tb-btn" data-cmd="insertHorizontalRule" title="插入分割线">—</button>
            <button type="button" class="tb-btn" data-cmd="removeFormat" title="清除格式">🧹</button>
            <span class="tb-sep"></span>
            <button type="button" class="tb-btn" data-cmd="undo" title="撤销">↶</button>
            <button type="button" class="tb-btn" data-cmd="redo" title="重做">↷</button>
          </div>
          <div id="editor" class="rich-editor" contenteditable="true"
               data-placeholder="开始写作吧… 选中文字可调整字号 / 加粗 / 高亮标记 / 划线，可插入链接与图片，支持直接粘贴图片"></div>
          <div class="editor-hint">💡 选中文字后点工具栏应用样式；粘贴图片会自动上传；链接在新窗口打开</div>
        </div>

        <div class="editor-actions">
          <button class="btn btn-primary" id="btnSave">💾 保存文章</button>
          <button class="btn btn-ghost" id="btnPreview">👁 保存并预览</button>
          <span class="save-msg" id="saveMsg"></span>
        </div>
      </section>

      <!-- 站点设置 -->
      <section id="view-settings" class="view" hidden>
        <h2 class="page-title">站点设置</h2>

        <div class="settings-block card">
          <h3 class="sub-title">基本信息</h3>
          <div class="form-grid">
            <div class="form-item"><label>站点名称</label><input id="sSiteName"></div>
            <div class="form-item"><label>博主昵称</label><input id="sOwnerName"></div>
            <div class="form-item span-2">
              <label>头像图片</label>
              <div class="inline-row">
                <input id="sAvatar" placeholder="头像图片 URL（留空显示首字母）">
                <button type="button" class="btn btn-ghost btn-sm" id="btnAvatarUpload">上传</button>
                <input type="file" id="sAvatarFile" accept="image/*" hidden>
              </div>
            </div>
            <div class="form-item span-2"><label>个人简介（显示在主页）</label><input id="sBio" placeholder="一句话介绍自己"></div>
          </div>
        </div>

        <div class="settings-block card">
          <div class="block-head">
            <h3 class="sub-title">联系方式（主页侧栏展示）</h3>
            <button class="btn btn-ghost btn-sm" id="btnAddContact">＋ 添加</button>
          </div>
          <p class="block-tip">「跳转链接」填写后点击可跳转（支持 https:// 和 mailto:）；留空则点击复制内容。</p>
          <div id="contactRows"></div>
        </div>

        <div class="settings-block card">
          <div class="block-head">
            <h3 class="sub-title">友情链接（点击跳转到对方网站）</h3>
            <button class="btn btn-ghost btn-sm" id="btnAddLink">＋ 添加</button>
          </div>
          <div id="linkRows"></div>
        </div>

        <div class="settings-block card">
          <div class="block-head">
            <h3 class="sub-title">☕ 赞助支持（点击跳转到赞助页面）</h3>
            <button class="btn btn-ghost btn-sm" id="btnAddSponsor">＋ 添加</button>
          </div>
          <div id="sponsorRows"></div>
        </div>

        <button class="btn btn-primary btn-lg" id="btnSaveSite">💾 保存全部设置</button>

        <div class="settings-block card">
          <h3 class="sub-title">修改后台密码</h3>
          <div class="form-grid">
            <div class="form-item"><label>原密码</label><input type="password" id="pwOld"></div>
            <div class="form-item"><label>新密码（至少 6 位）</label><input type="password" id="pwNew"></div>
            <div class="form-item"><label>确认新密码</label><input type="password" id="pwNew2"></div>
          </div>
          <button class="btn btn-primary" id="btnChangePw">🔒 修改密码</button>
        </div>
      </section>

      <!-- 订阅管理（订阅量仅博主可见，不在前台展示） -->
      <section id="view-subs" class="view" hidden>
        <div class="page-head">
          <h2 class="page-title">📧 订阅管理</h2>
          <button class="btn btn-ghost" id="btnExportSubs">⬇️ 导出 CSV</button>
        </div>
        <div class="subs-summary card">
          <div class="subs-count" id="subsCount">0</div>
          <p class="subs-count-label">当前订阅人数（仅你可见）</p>
        </div>
        <div class="table-wrap card">
          <table class="data-table" id="subsTable">
            <thead><tr><th>邮箱</th><th>订阅时间</th><th>操作</th></tr></thead>
            <tbody><tr><td colspan="3" class="empty">加载中…</td></tr></tbody>
          </table>
        </div>
      </section>
    </div>
  </div>

  <!-- ============ 插入链接弹窗 ============ -->
  <div class="modal-overlay" id="linkModal" hidden>
    <div class="modal card">
      <h3>插入链接</h3>
      <div class="form-item"><label>链接地址 *</label>
        <input id="linkUrl" placeholder="https://example.com 或 mailto:xx@xx.com"></div>
      <div class="form-item"><label>显示文字</label>
        <input id="linkText" placeholder="留空则使用选中文字或链接地址"></div>
      <label class="checkbox-row"><input type="checkbox" id="linkBlank" checked> 在新窗口打开链接</label>
      <div class="modal-actions">
        <button class="btn btn-ghost" data-close>取消</button>
        <button class="btn btn-primary" id="linkConfirm">插入链接</button>
      </div>
    </div>
  </div>

  <!-- ============ 插入图片弹窗 ============ -->
  <div class="modal-overlay" id="imageModal" hidden>
    <div class="modal card">
      <h3>插入图片</h3>
      <div class="tabs">
        <button class="tab active" data-tab="upload">本地上传</button>
        <button class="tab" data-tab="url">图片 URL</button>
      </div>
      <div class="tab-pane" id="tab-upload">
        <label class="upload-area" id="uploadArea">
          📁 点击选择图片（jpg / png / gif / webp，最大 10MB）
          <input type="file" id="imageFile" accept="image/*" hidden>
        </label>
        <div class="upload-status" id="uploadStatus"></div>
      </div>
      <div class="tab-pane" id="tab-url" hidden>
        <div class="form-item"><label>图片地址 *</label>
          <input id="imageUrl" placeholder="https://example.com/photo.jpg"></div>
      </div>
      <div class="modal-actions">
        <button class="btn btn-ghost" data-close>取消</button>
        <button class="btn btn-primary" id="imageConfirm">插入图片</button>
      </div>
    </div>
  </div>

  <div id="toast"></div>
  <script data-admin-inline>
/* ================= 工具与全局状态 ================= */
const $ = s => document.querySelector(s);
const $$ = s => Array.from(document.querySelectorAll(s));

let TOKEN = localStorage.getItem('blogToken') || '';
let editingId = null;      // 当前编辑的文章 id（null = 新建）
let savedRange = null;     // 编辑器最近选区
let adminInited = false;

function authHeader() {
  return TOKEN ? { Authorization: 'Bearer ' + TOKEN } : {};
}
/* 带超时的 fetch，避免某些网络环境下请求永远 pending */
async function fetchWithTimeout(url, opts = {}, ms = 10000) {
  const ctrl = new AbortController();
  const id = setTimeout(() => ctrl.abort(), ms);
  try {
    return await fetch(url, { ...opts, signal: ctrl.signal });
  } catch (err) {
    if (err.name === 'AbortError') throw new Error('请求超时，请检查网络后重试');
    throw new Error('网络请求失败：' + (err.message || '无法连接到服务器'));
  } finally {
    clearTimeout(id);
  }
}

async function api(path, opts = {}) {
  const isForm = opts.body && (typeof FormData !== 'undefined' && opts.body instanceof FormData);
  const headers = { ...(opts.headers || {}), ...authHeader() };
  if (!isForm && opts.body) headers['Content-Type'] = 'application/json';
  const res = await fetchWithTimeout(path, { ...opts, headers });
  const data = await res.json().catch(() => ({}));
  if (res.status === 401) { showLogin(); throw new Error(data.error || '请先登录'); }
  if (!res.ok) throw new Error(data.error || '请求失败');
  return data;
}
/* 安全提示：MIUI/部分内置浏览器可能不显示 err 文本，用 alert 兜底 */
function hardAlert(msg) {
  try { if (window.alert) window.alert(msg); } catch {}
}
function stripHtml(html) {
  const div = document.createElement('div');
  div.innerHTML = html || '';
  return div.textContent.trim();
}

let toastTimer = null;
function toast(msg, ok = true) {
  const t = $('#toast');
  t.textContent = msg;
  t.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => t.classList.remove('show'), 2400);
}
function fmtDate(ts) {
  const d = new Date(ts);
  const p = n => String(n).padStart(2, '0');
  return \`\${d.getFullYear()}-\${p(d.getMonth() + 1)}-\${p(d.getDate())} \${p(d.getHours())}:\${p(d.getMinutes())}\`;
}

/* 主题（与前台一致，支持 light/dark/glass/tech/neumorph） */
const ADMIN_THEMES = [
  { id: 'light', icon: '☀️', label: '浅色' },
  { id: 'dark', icon: '🌙', label: '深色' },
  { id: 'glass', icon: '💎', label: '玻璃' },
  { id: 'tech', icon: '⚡', label: '科技' },
  { id: 'neumorph', icon: '🧊', label: '拟态玻璃' }
];
function applyAdminTheme(id) {
  const t = ADMIN_THEMES.find(x => x.id === id) || ADMIN_THEMES[1];
  document.documentElement.dataset.theme = id;
  try { localStorage.setItem('theme', id); } catch {}
  const icon = $('#adminThemeIcon');
  const label = $('#adminThemeLabel');
  if (icon) icon.textContent = t.icon;
  if (label) label.textContent = t.label;
}
function nextAdminTheme() {
  const cur = document.documentElement.dataset.theme || 'dark';
  const idx = ADMIN_THEMES.findIndex(t => t.id === cur);
  applyAdminTheme(ADMIN_THEMES[(idx + 1) % ADMIN_THEMES.length].id);
}
(function initTheme() {
  applyAdminTheme(
    localStorage.getItem('theme') ||
    (matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light')
  );
  const picker = $('#adminThemePicker');
  if (picker) picker.addEventListener('click', nextAdminTheme);
})();

/* ================= 登录 / 登出 ================= */
function showLogin() {
  TOKEN = '';
  localStorage.removeItem('blogToken');
  $('#adminView').hidden = true;
  $('#loginView').hidden = false;
  $('#linkModal').hidden = true;
  $('#imageModal').hidden = true;
}
function showAdmin() {
  try {
    if (!adminInited) { initAdmin(); adminInited = true; }
    switchView('dashboard');
    $('#loginView').hidden = true;
    $('#adminView').hidden = false;
    window.scrollTo(0, 0);
  } catch (err) {
    console.error('进入后台失败:', err);
    const msg = '进入后台失败: ' + (err && err.message ? err.message : '请刷新页面重试');
    $('#loginErr').textContent = msg;
    hardAlert(msg);
    showLogin();
  }
}

async function doLogin() {
  const btn = $('#loginBtn');
  const err = $('#loginErr');
  err.textContent = '';
  btn.disabled = true;
  btn.textContent = '登录中…';
  try {
    const data = await api('/api/login', {
      method: 'POST',
      body: JSON.stringify({
        username: $('#loginUser').value.trim(),
        password: $('#loginPass').value
      })
    });
    TOKEN = data.token || '';
    if (!TOKEN) throw new Error('登录未返回 token，请重试');
    let saved = false;
    try { localStorage.setItem('blogToken', TOKEN); saved = true; } catch {}
    if (!saved) hardAlert('当前浏览器可能禁用了本地存储，登录状态刷新后可能失效。');
    showAdmin();
  } catch (ex) {
    const msg = ex && ex.message ? ex.message : '登录失败，请检查网络或刷新页面重试';
    err.textContent = msg;
    hardAlert('登录失败：' + msg);
  } finally {
    btn.disabled = false;
    btn.textContent = '登 录';
  }
}
$('#loginForm').addEventListener('submit', e => { e.preventDefault(); doLogin(); });
/* 双保险：某些浏览器/自动填充场景下 submit 事件不触发，click 也能登录 */
$('#loginBtn').addEventListener('click', e => {
  e.preventDefault();
  e.stopPropagation();
  doLogin();
});

$('#logoutBtn').addEventListener('click', async () => {
  try { await api('/api/logout', { method: 'POST' }); } catch {}
  showLogin();
});

/* ================= 视图切换 ================= */
$$('.side-nav a[data-view]').forEach(a => {
  a.addEventListener('click', e => {
    e.preventDefault();
    const view = a.dataset.view;
    if (view === 'editor' && a.id === 'navNewPost') resetEditor(); // 点侧栏「写文章」= 新建
    switchView(view);
  });
});
function switchView(name) {
  $$('.view').forEach(v => { v.hidden = v.id !== 'view-' + name; });
  $$('.side-nav a[data-view]').forEach(a => a.classList.toggle('active', a.dataset.view === name));
  if (name === 'dashboard') renderDashboard();
  if (name === 'posts') loadPostsTable();
  if (name === 'settings') loadSettings();
  if (name === 'subs') loadSubscribers();
}

/* ================= 订阅管理 ================= */
async function loadSubscribers() {
  try {
    const data = await api('/api/subscribers');
    $('#subsCount').textContent = data.count || 0;
    const tbody = $('#subsTable tbody');
    if (!data.list || !data.list.length) {
      tbody.innerHTML = '<tr><td colspan="3" class="empty">还没有人订阅，分享你的博客让更多人订阅吧 ✉️</td></tr>';
      return;
    }
    tbody.innerHTML = data.list.map(s => \`
      <tr>
        <td>\${escapeHtml(s.email)}</td>
        <td>\${fmtDate(s.createdAt)}</td>
        <td class="td-actions"><button class="btn-danger-link js-del-sub" data-email="\${escapeHtml(s.email)}">删除</button></td>
      </tr>\`).join('');
    $$('#subsTable .js-del-sub').forEach(b => b.addEventListener('click', () => deleteSubscriber(b.dataset.email)));
  } catch (e) { toast(e.message); }
}
async function deleteSubscriber(email) {
  if (!confirm('确定删除订阅 ' + email + ' 吗？')) return;
  try {
    await api('/api/subscribers', { method: 'DELETE', body: JSON.stringify({ email }) });
    toast('已删除');
    loadSubscribers();
  } catch (e) { toast(e.message); }
}
$('#btnExportSubs').addEventListener('click', async () => {
  try {
    const data = await api('/api/subscribers');
    if (!data.list || !data.list.length) { toast('还没有订阅数据'); return; }
    const rows = [['邮箱', '订阅时间']].concat(data.list.map(s => [s.email, new Date(s.createdAt).toLocaleString()]));
    const csv = rows.map(r => r.map(c => '"' + String(c).replace(/"/g, '""') + '"').join(',')).join('\\n');
    const blob = new Blob(['﻿' + csv], { type: 'text/csv;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = 'subscribers.csv';
    document.body.appendChild(a); a.click(); a.remove();
    URL.revokeObjectURL(url);
  } catch (e) { toast(e.message); }
});

/* ================= 仪表盘 ================= */
async function renderDashboard() {
  try {
    const list = await api('/api/posts?all=1');
    const published = list.filter(p => p.status === 'published');
    $('#statTotal').textContent = list.length;
    $('#statPublished').textContent = published.length;
    $('#statDraft').textContent = list.length - published.length;
    $('#statViews').textContent = list.reduce((s, p) => s + (p.views || 0), 0);
    const recent = list.slice(0, 5);
    $('#recentTable').innerHTML = recent.length ? \`
      <thead><tr><th>标题</th><th>状态</th><th>阅读</th><th>更新时间</th></tr></thead>
      <tbody>\${recent.map(p => \`
        <tr>
          <td class="td-title"><a href="#" class="js-edit" data-id="\${p.id}">\${escapeHtml(p.title)}</a></td>
          <td><span class="status-pill \${p.status}">\${p.status === 'published' ? '已发布' : '草稿'}</span></td>
          <td>\${p.views || 0}</td>
          <td>\${fmtDate(p.updatedAt)}</td>
        </tr>\`).join('')}
      </tbody>\` : '<tbody><tr><td class="empty">暂无文章</td></tr></tbody>';
    $$('#recentTable .js-edit').forEach(a =>
      a.addEventListener('click', e => { e.preventDefault(); startEdit(a.dataset.id); }));
  } catch (e) { toast(e.message); }
}
function escapeHtml(s) {
  return String(s == null ? '' : s)
    .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
}

/* ================= 文章列表 ================= */
async function loadPostsTable() {
  try {
    const list = await api('/api/posts?all=1');
    $('#postsTable').innerHTML = list.length ? \`
      <thead><tr><th>标题</th><th>置顶</th><th>状态</th><th>标签</th><th>阅读</th><th>更新时间</th><th>操作</th></tr></thead>
      <tbody>\${list.map(p => \`
        <tr class="\${p.pinned ? 'row-pinned' : ''}">
          <td class="td-title"><a href="#" class="js-edit" data-id="\${p.id}">\${p.pinned ? '📌 ' : ''}\${escapeHtml(p.title)}</a></td>
          <td><button class="pin-toggle \${p.pinned ? 'on' : ''}" data-id="\${p.id}" title="切换置顶">\${p.pinned ? '已置顶' : '置顶'}</button></td>
          <td><span class="status-pill \${p.status}">\${p.status === 'published' ? '已发布' : '草稿'}</span></td>
          <td>\${(p.tags || []).map(t => \`<span class="tag">\${escapeHtml(t)}</span>\`).join(' ') || '—'}</td>
          <td>\${p.views || 0}</td>
          <td>\${fmtDate(p.updatedAt)}</td>
          <td class="td-actions">
            <button class="btn-danger-link js-toggle" data-id="\${p.id}" data-next="\${p.status === 'published' ? 'draft' : 'published'}">
              \${p.status === 'published' ? '下架' : '发布'}
            </button>
            <button class="btn-danger-link js-edit" data-id="\${p.id}" style="color:var(--primary)">编辑</button>
            <button class="btn-danger-link js-del" data-id="\${p.id}">删除</button>
          </td>
        </tr>\`).join('')}
      </tbody>\` : '<tbody><tr><td class="empty">还没有文章，点击右上角「新建文章」开始创作 ✍️</td></tr></tbody>';

    $$('#postsTable .js-edit').forEach(b => b.addEventListener('click', () => startEdit(b.dataset.id)));
    $$('#postsTable .js-toggle').forEach(b => b.addEventListener('click', () => togglePost(b.dataset.id, b.dataset.next)));
    $$('#postsTable .js-del').forEach(b => b.addEventListener('click', () => deletePost(b.dataset.id)));
    $$('#postsTable .pin-toggle').forEach(b => b.addEventListener('click', () => togglePin(b.dataset.id)));
  } catch (e) { toast(e.message); }
}

async function togglePost(id, next) {
  try {
    const list = await api('/api/posts?all=1');
    const p = list.find(x => x.id === id);
    if (!p) return;
    await api('/api/posts/' + id, {
      method: 'PUT',
      body: JSON.stringify({ ...p, status: next })
    });
    toast(next === 'published' ? '已发布 🎉' : '已转为草稿');
    loadPostsTable();
  } catch (e) { toast(e.message); }
}

async function togglePin(id) {
  try {
    const list = await api('/api/posts?all=1');
    const p = list.find(x => x.id === id);
    if (!p) return;
    await api('/api/posts/' + id, {
      method: 'PUT',
      body: JSON.stringify({ ...p, pinned: !p.pinned })
    });
    toast(p.pinned ? '已取消置顶' : '已置顶 📌，将排在所有文章最前');
    loadPostsTable();
  } catch (e) { toast(e.message); }
}

async function deletePost(id) {
  const list = await api('/api/posts?all=1').catch(() => []);
  const p = list.find(x => x.id === id);
  if (!confirm(\`确定删除文章《\${p ? p.title : id}》？此操作不可恢复。\`)) return;
  try {
    await api('/api/posts/' + id, { method: 'DELETE' });
    toast('已删除');
    loadPostsTable();
  } catch (e) { toast(e.message); }
}

/* ================= 编辑器：载入 / 重置 / 保存 ================= */
const editor = $('#editor');

function resetEditor() {
  editingId = null;
  $('#fTitle').value = '';
  $('#fSummary').value = '';
  $('#fCover').value = '';
  $('#fTags').value = '';
  $('#fStatus').value = 'published';
  editor.innerHTML = '';
  $('#editorMode').textContent = '写文章';
  $('#editingFlag').hidden = true;
  $('#saveMsg').textContent = '';
}

async function startEdit(id) {
  try {
    const list = await api('/api/posts?all=1');
    const p = list.find(x => x.id === id);
    if (!p) return toast('文章不存在');
    editingId = p.id;
    $('#fTitle').value = p.title;
    $('#fSummary').value = p.summary || '';
    $('#fCover').value = p.cover || '';
    $('#fTags').value = (p.tags || []).join(', ');
    $('#fStatus').value = p.status;
    editor.innerHTML = p.content;
    $('#editorMode').textContent = '编辑文章';
    $('#editingFlag').hidden = false;
    switchView('editor');
  } catch (e) { toast(e.message); }
}

$('#btnNewPost').addEventListener('click', () => { resetEditor(); switchView('editor'); });

function collectPost() {
  const title = $('#fTitle').value.trim();
  const content = editor.innerHTML;
  if (!title) { toast('请填写文章标题'); return null; }
  if (!stripHtml(content) && !/<img\\s/i.test(content)) { toast('正文内容不能为空'); return null; }
  return {
    title,
    summary: $('#fSummary').value.trim(),
    cover: $('#fCover').value.trim(),
    tags: $('#fTags').value,
    status: $('#fStatus').value,
    content
  };
}

async function savePost(openPreview = false) {
  const body = collectPost();
  if (!body) return null;
  const btn = $('#btnSave');
  btn.disabled = true;
  btn.textContent = '保存中…';
  try {
    const p = editingId
      ? await api('/api/posts/' + editingId, { method: 'PUT', body: JSON.stringify(body) })
      : await api('/api/posts', { method: 'POST', body: JSON.stringify(body) });
    editingId = p.id;
    $('#editorMode').textContent = '编辑文章';
    $('#editingFlag').hidden = false;
    $('#saveMsg').textContent = \`已保存 · \${fmtDate(p.updatedAt)}\`;
    toast(openPreview ? '保存成功，正在打开预览…' : '保存成功 ✅');
    if (openPreview) window.open('/post.html?id=' + encodeURIComponent(p.id), '_blank');
    return p;
  } catch (e) {
    toast(e.message);
    return null;
  } finally {
    btn.disabled = false;
    btn.textContent = '💾 保存文章';
  }
}
$('#btnSave').addEventListener('click', () => savePost(false));
$('#btnPreview').addEventListener('click', () => savePost(true));

/* 封面上传 */
$('#btnCoverUpload').addEventListener('click', () => $('#fCoverFile').click());
$('#fCoverFile').addEventListener('change', async e => {
  const file = e.target.files[0];
  if (!file) return;
  try {
    const url = await uploadImage(file, st => toast(st));
    $('#fCover').value = url;
    toast('封面上传成功');
  } catch (err) { toast('上传失败：' + err.message); }
  e.target.value = '';
});

/* ================= 富文本编辑器核心 ================= */
/* 记录选区：工具栏按钮 mousedown 已 preventDefault，双保险再存一份 */
function saveSelection() {
  const sel = window.getSelection();
  if (sel.rangeCount && editor.contains(sel.anchorNode)) {
    savedRange = sel.getRangeAt(0).cloneRange();
  }
}
editor.addEventListener('keyup', saveSelection);
editor.addEventListener('mouseup', saveSelection);
editor.addEventListener('focus', saveSelection);

function restoreSelection() {
  if (savedRange) {
    const sel = window.getSelection();
    sel.removeAllRanges();
    sel.addRange(savedRange);
  }
}

/* 工具栏按钮：mousedown 阻止抢焦点，避免点击后编辑器失焦导致选区/光标丢失。
   覆盖普通命令按钮、自定义按钮（插入链接/图片等），以及取色器；不影响 select 下拉。 */
$$('#toolbar button.tb-btn, #toolbar .color-dot, #toolbar label.tb-btn').forEach(el => {
  el.addEventListener('mousedown', e => e.preventDefault());
});

function exec(cmd, val) {
  editor.focus();
  restoreSelection();
  try { document.execCommand('styleWithCSS', false, true); } catch {}
  document.execCommand(cmd, false, val);
  saveSelection();
  editor.focus();
}

$$('#toolbar .tb-btn[data-cmd]').forEach(btn => {
  btn.addEventListener('click', () => exec(btn.dataset.cmd));
});

/* 段落格式 */
$('#blockType').addEventListener('change', e => {
  const v = e.target.value;
  if (v) exec('formatBlock', '<' + v + '>');
  e.target.selectedIndex = 0;
});

/* 像素级字号：把选中内容包裹进 <span style="font-size: px">，稳定支持各浏览器与移动端。
   支持两种用法：
   1) 先选中文字再选字号 → 直接套用（传统模式）
   2) 光标在空处先选字号 → 进入「预置模式」，之后打字自动套用该字号（无需先全选） */
let pendingFontSize = null;   // 预置字号（光标处打字时自动套用）
let fontSizeBadge = null;     // 工具栏上的「已预置 Npx」提示

function setFontSize(px) {
  editor.focus();
  restoreSelection();
  const sel = window.getSelection();
  if (!sel.rangeCount) { startPendingFontSize(px); return; }
  const range = sel.getRangeAt(0);
  if (!editor.contains(range.commonAncestorContainer)) { startPendingFontSize(px); return; }
  if (range.collapsed) {
    // 光标（无选区）：进入预置模式，而不是报错
    startPendingFontSize(px);
    return;
  }
  try {
    const span = document.createElement('span');
    span.style.fontSize = px + 'px';
    span.appendChild(range.extractContents());
    range.insertNode(span);
    const r = document.createRange();
    r.selectNodeContents(span);
    sel.removeAllRanges();
    sel.addRange(r);
    savedRange = r.cloneRange();
    clearPendingFontSize();
  } catch (e) {
    console.error(e);
    toast('设置字号失败，请重新选择文字');
  }
}

function startPendingFontSize(px) {
  pendingFontSize = px;
  if (!fontSizeBadge) {
    fontSizeBadge = document.createElement('span');
    fontSizeBadge.className = 'font-size-badge';
    $('#toolbar').appendChild(fontSizeBadge);
  }
  fontSizeBadge.textContent = \`✎ 即将输入 \${px}px 字号（直接打字即可）\`;
  fontSizeBadge.hidden = false;
  toast(\`已预置 \${px}px 字号，现在开始打字就会套用\`);
}

function clearPendingFontSize() {
  pendingFontSize = null;
  if (fontSizeBadge) fontSizeBadge.hidden = true;
}

// 预置模式下：捕获下一次可见文字输入，把该文本节点整体包成对应字号的 span
editor.addEventListener('input', e => {
  if (pendingFontSize == null) return;
  const sel = window.getSelection();
  if (!sel.rangeCount) return;
  const range = sel.getRangeAt(0);
  if (!editor.contains(range.commonAncestorContainer)) return;
  // 找到光标所在的文本节点（已输入可见内容）
  let node = range.startContainer;
  if (node.nodeType !== 3) return;
  if (!node.textContent.trim()) return; // 还没真正输入可见内容
  // 如果该文本节点已经在一个 fontSize span 内，跳过（避免重复包裹）
  if (node.parentElement && node.parentElement.style &&
      node.parentElement.style.fontSize) return;
  try {
    const span = document.createElement('span');
    span.style.fontSize = pendingFontSize + 'px';
    node.parentNode.insertBefore(span, node);
    span.appendChild(node);
    // 光标移到 span 内文本末尾
    const r = document.createRange();
    r.setStart(node, node.textContent.length);
    r.collapse(true);
    sel.removeAllRanges();
    sel.addRange(r);
    savedRange = r.cloneRange();
    clearPendingFontSize();
  } catch (err) {
    console.error('预置字号包裹失败', err);
  }
});

$('#fontSizeSel').addEventListener('change', e => {
  const v = e.target.value;
  if (!v) return;
  if (v === 'clear') {
    clearPendingFontSize();
    exec('removeFormat');
  } else {
    setFontSize(Number(v));
  }
  e.target.selectedIndex = 0;
});

/* 文字颜色 / 荧光高亮：execCommand + 后处理，兼容移动端 */
function setForeColor(color) {
  editor.focus();
  restoreSelection();
  const sel = window.getSelection();
  if (!sel.rangeCount) return;
  const range = sel.getRangeAt(0);
  if (range.collapsed) { toast('请先选中要设置颜色的文字'); return; }
  try {
    document.execCommand('styleWithCSS', false, false);
    document.execCommand('foreColor', false, color);
    editor.querySelectorAll('font[color]').forEach(f => {
      const span = document.createElement('span');
      span.style.color = f.getAttribute('color');
      while (f.firstChild) span.appendChild(f.firstChild);
      f.parentNode.replaceChild(span, f);
    });
    $('#forePreview').style.color = color;
    saveSelection();
  } catch (e) { toast('设置颜色失败'); }
}
function setHiliteColor(color) {
  editor.focus();
  restoreSelection();
  const sel = window.getSelection();
  if (!sel.rangeCount) return;
  const range = sel.getRangeAt(0);
  if (range.collapsed) { toast('请先选中要高亮的文字'); return; }
  try {
    document.execCommand('styleWithCSS', false, true);
    document.execCommand('hiliteColor', false, color);
    saveSelection();
  } catch (e) { toast('设置高亮失败'); }
}
$('#foreColorInput').addEventListener('input', e => setForeColor(e.target.value));
$('#hiliteColorInput').addEventListener('input', e => setHiliteColor(e.target.value));
$$('#forePalette .color-dot').forEach(btn => btn.addEventListener('click', () => setForeColor(btn.dataset.color)));
$$('#hilitePalette .color-dot').forEach(btn => btn.addEventListener('click', () => setHiliteColor(btn.dataset.color)));

/* ================= 插入链接 ================= */
const linkModal = $('#linkModal');
$('#btnInsertLink').addEventListener('click', () => {
  saveSelection();
  const sel = window.getSelection();
  const selected = sel.toString();
  $('#linkText').value = selected;
  $('#linkUrl').value = 'https://';
  linkModal.hidden = false;
  $('#linkUrl').focus();
  $('#linkUrl').select();
});
$('#linkConfirm').addEventListener('click', () => {
  let url = $('#linkUrl').value.trim();
  const text = $('#linkText').value.trim();
  if (!url) { toast('请填写链接地址'); return; }
  if (!/^(https?:|mailto:|tel:|\\/|#)/i.test(url)) url = 'https://' + url;

  // 关键：先捕获已保存的选区再聚焦。打开弹窗时编辑器已失焦，
  // editor.focus() 会触发 focus 事件并覆盖 savedRange；若先 focus 再读取选区，
  // 光标会被重置到编辑器开头，链接就插到错误位置（所谓「自动置顶」）。
  let range = null;
  if (savedRange && editor.contains(savedRange.startContainer)) {
    range = savedRange.cloneRange();
  }
  const sel = window.getSelection();
  editor.focus();

  if (!range) {
    toast('请先在编辑器中定位光标');
    linkModal.hidden = true;
    return;
  }

  const blank = $('#linkBlank').checked;
  const a = document.createElement('a');
  a.setAttribute('href', escapeAttr(url));
  if (blank) { a.target = '_blank'; a.rel = 'noopener noreferrer'; }

  if (!range.collapsed) {
    // 有选中文字：优先使用弹窗里的链接文本；没填就用原文
    a.textContent = text || range.toString();
    range.deleteContents();
  } else {
    // 只有光标：在光标处插入链接
    a.textContent = text || url.replace(/^https?:\\/\\//, '');
  }

  // 用 Range.insertNode 精确插入到光标/选区位置
  range.insertNode(a);

  // 把光标移到链接之后，避免后续输入被包进链接
  const after = document.createRange();
  after.setStartAfter(a);
  after.setEndAfter(a);
  sel.removeAllRanges();
  sel.addRange(after);
  savedRange = after.cloneRange();

  linkModal.hidden = true;
});

/* ================= 插入图片 ================= */
const imageModal = $('#imageModal');
let imgTab = 'upload';
$$('.tab').forEach(t => t.addEventListener('click', () => {
  imgTab = t.dataset.tab;
  $$('.tab').forEach(x => x.classList.toggle('active', x === t));
  $('#tab-upload').hidden = imgTab !== 'upload';
  $('#tab-url').hidden = imgTab !== 'url';
}));

$('#btnInsertImage').addEventListener('click', () => {
  saveSelection();
  $('#uploadStatus').textContent = '';
  $('#imageUrl').value = '';
  imageModal.hidden = false;
});

/* 上传图片（后台 API），fn 用于展示进度提示 */
async function uploadImage(file, notify) {
  if (!/^image\\//.test(file.type)) throw new Error('只能上传图片文件');
  if (file.size > 10 * 1024 * 1024) throw new Error('图片不能超过 10MB');
  notify && notify('上传中…');
  const fd = new FormData();
  fd.append('image', file);
  const res = await fetchWithTimeout('/api/upload', { method: 'POST', headers: authHeader(), body: fd }, 60000);
  const data = await res.json().catch(() => ({}));
  if (res.status === 401) { showLogin(); throw new Error('请先登录'); }
  if (!res.ok) throw new Error(data.error || '上传失败');
  return data.url;
}

$('#uploadArea').addEventListener('click', () => $('#imageFile').click());
$('#imageFile').addEventListener('change', async e => {
  const file = e.target.files[0];
  e.target.value = '';
  if (!file) return;
  const st = $('#uploadStatus');
  try {
    st.textContent = '⏳ 上传中…';
    const url = await uploadImage(file);
    st.textContent = '✅ 上传成功';
    insertImageAtSelection(url);
    imageModal.hidden = true;
  } catch (err) {
    st.textContent = '❌ ' + err.message;
  }
});

$('#imageConfirm').addEventListener('click', () => {
  if (imgTab === 'url') {
    let url = $('#imageUrl').value.trim();
    if (!url) { toast('请填写图片地址'); return; }
    if (!/^(https?:|data:image|\\/)/i.test(url)) url = 'https://' + url;
    insertImageAtSelection(url);
    imageModal.hidden = true;
  } else {
    $('#imageFile').click();
  }
});

function insertImageAtSelection(url) {
  // 先捕获选区，避免 editor.focus() 触发 focus 事件覆盖 savedRange，导致图片插错位置
  let range = null;
  if (savedRange && editor.contains(savedRange.startContainer)) {
    range = savedRange.cloneRange();
  }
  const sel = window.getSelection();
  editor.focus();
  if (!range) { toast('请先在编辑器中定位光标'); return; }

  const img = document.createElement('img');
  img.src = url;
  img.alt = '';
  if (!range.collapsed) range.deleteContents();
  range.insertNode(img);

  const after = document.createRange();
  after.setStartAfter(img);
  after.setEndAfter(img);
  sel.removeAllRanges();
  sel.addRange(after);
  savedRange = after.cloneRange();
}

/* 直接粘贴图片 → 自动上传并插入 */
editor.addEventListener('paste', async e => {
  const items = e.clipboardData && e.clipboardData.items;
  if (!items) return;
  for (const item of items) {
    if (item.type && item.type.startsWith('image/')) {
      e.preventDefault();
      const file = item.getAsFile();
      if (!file) return;
      saveSelection();
      try {
        const url = await uploadImage(file);
        insertImageAtSelection(url);
        toast('图片已上传并插入 ✅');
      } catch (err) {
        toast('粘贴上传失败：' + err.message);
      }
      return;
    }
  }
});

/* 弹窗通用关闭 */
$$('.modal [data-close]').forEach(b => b.addEventListener('click', () => {
  linkModal.hidden = true;
  imageModal.hidden = true;
}));
$$('.modal-overlay').forEach(ov => ov.addEventListener('mousedown', e => {
  if (e.target === ov) { ov.hidden = true; }
}));
document.addEventListener('keydown', e => {
  if (e.key === 'Escape') { linkModal.hidden = true; imageModal.hidden = true; }
});

function escapeAttr(s) { return escapeHtml(s); }

/* ================= 站点设置 ================= */
const CONTACT_TYPES = [
  ['email', '✉️ 邮箱'],
  ['phone', '📱 手机/电话'],
  ['wechat', '💬 微信'],
  ['qq', '🐧 QQ'],
  ['weibo', '🔴 微博'],
  ['bilibili', '📺 哔哩哔哩'],
  ['douyin', '🎵 抖音'],
  ['xiaohongshu', '📕 小红书'],
  ['zhihu', '📖 知乎'],
  ['jike', '🌐 即刻'],
  ['github', '🐙 GitHub'],
  ['twitter', '🐦 X/Twitter'],
  ['telegram', '✈️ Telegram'],
  ['youtube', '▶️ YouTube'],
  ['instagram', '📷 Instagram'],
  ['facebook', '📘 Facebook'],
  ['discord', '🟣 Discord'],
  ['tiktok', '🎶 TikTok'],
  ['netease', '☁️ 网易云音乐'],
  ['steam', '🎮 Steam'],
  ['website', '🌐 个人网站'],
  ['link', '🔗 其他链接']
];

function contactRowHtml(c = {}) {
  return \`<div class="row-grid contact-row">
    <select class="c-type">\${CONTACT_TYPES.map(([v, l]) =>
      \`<option value="\${v}" \${c.type === v ? 'selected' : ''}>\${l}</option>\`).join('')}</select>
    <input class="c-label" placeholder="显示名称" value="\${escapeHtml(c.label || '')}">
    <input class="c-value" placeholder="内容（邮箱/账号/号码）" value="\${escapeHtml(c.value || '')}">
    <input class="c-link" placeholder="跳转链接，可空（https://… 或 mailto:…）" value="\${escapeHtml(c.link || '')}">
    <button class="row-del" title="删除此行">✕</button>
  </div>\`;
}
function linkRowHtml(l = {}) {
  return \`<div class="row-grid link-row">
    <input class="l-name" placeholder="网站名称" value="\${escapeHtml(l.name || '')}">
    <input class="l-url" placeholder="https://example.com" value="\${escapeHtml(l.url || '')}">
    <input class="l-desc" placeholder="一句话描述" value="\${escapeHtml(l.desc || '')}">
    <button class="row-del" title="删除此行">✕</button>
  </div>\`;
}
function sponsorRowHtml(l = {}) {
  return \`<div class="row-grid sponsor-row">
    <input class="l-name" placeholder="赞助方式/平台名称" value="\${escapeHtml(l.name || '')}">
    <div class="sponsor-img-wrap">
      <img class="sponsor-preview" src="\${escapeHtml(l.image || '')}" alt="" \${l.image ? '' : 'hidden'}>
      <span class="sponsor-placeholder" \${l.image ? 'hidden' : ''}>🖼️</span>
      <input type="file" accept="image/*" hidden class="sponsor-file">
      <button type="button" class="btn btn-ghost btn-sm sponsor-upload">上传图片</button>
      <input type="hidden" class="l-image" value="\${escapeHtml(l.image || '')}">
    </div>
    <input class="l-url" placeholder="跳转链接（可空，留空则点击复制账号）" value="\${escapeHtml(l.url || '')}">
    <input class="l-desc" placeholder="一句话描述" value="\${escapeHtml(l.desc || '')}">
    <button class="row-del" title="删除此行">✕</button>
  </div>\`;
}

async function loadSettings() {
  try {
    const site = await api('/api/site');
    $('#sSiteName').value = site.siteName || '';
    $('#sOwnerName').value = site.ownerName || '';
    $('#sAvatar').value = site.avatar || '';
    $('#sBio').value = site.bio || '';
    $('#contactRows').innerHTML = (site.contacts || []).map(contactRowHtml).join('') || contactRowHtml();
    $('#linkRows').innerHTML = (site.links || []).map(linkRowHtml).join('') || linkRowHtml();
    $('#sponsorRows').innerHTML = (site.sponsorLinks || []).map(sponsorRowHtml).join('') || sponsorRowHtml();
  } catch (e) { toast(e.message); }
}

$('#btnAddContact').addEventListener('click', () =>
  $('#contactRows').insertAdjacentHTML('beforeend', contactRowHtml()));
$('#btnAddLink').addEventListener('click', () =>
  $('#linkRows').insertAdjacentHTML('beforeend', linkRowHtml()));
$('#btnAddSponsor').addEventListener('click', () =>
  $('#sponsorRows').insertAdjacentHTML('beforeend', sponsorRowHtml()));
document.addEventListener('click', e => {
  if (e.target.classList && e.target.classList.contains('row-del')) {
    e.target.closest('.row-grid').remove();
  }
});

$('#btnSaveSite').addEventListener('click', async () => {
  const contacts = $$('#contactRows .contact-row').map(row => ({
    type: row.querySelector('.c-type').value,
    label: row.querySelector('.c-label').value.trim(),
    value: row.querySelector('.c-value').value.trim(),
    link: row.querySelector('.c-link').value.trim()
  })).filter(c => c.value || c.link);
  const links = $$('#linkRows .link-row').map(row => ({
    name: row.querySelector('.l-name').value.trim(),
    url: row.querySelector('.l-url').value.trim(),
    desc: row.querySelector('.l-desc').value.trim()
  })).filter(l => l.name && l.url);
  const sponsorLinks = $$('#sponsorRows .sponsor-row').map(row => ({
    name: row.querySelector('.l-name').value.trim(),
    url: row.querySelector('.l-url').value.trim(),
    desc: row.querySelector('.l-desc').value.trim(),
    image: row.querySelector('.l-image').value.trim()
  })).filter(l => l.name || l.image); // 修复：赞助可只填名称/只传图片，url 允许为空
  try {
    await api('/api/site', {
      method: 'PUT',
      body: JSON.stringify({
        siteName: $('#sSiteName').value.trim(),
        ownerName: $('#sOwnerName').value.trim(),
        avatar: $('#sAvatar').value.trim(),
        bio: $('#sBio').value.trim(),
        contacts, links, sponsorLinks
      })
    });
    toast('站点设置已保存 ✅（刷新前台首页生效）');
  } catch (e) { toast(e.message); }
});

/* 头像上传 */
$('#btnAvatarUpload').addEventListener('click', () => $('#sAvatarFile').click());
$('#sAvatarFile').addEventListener('change', async e => {
  const file = e.target.files[0];
  if (!file) return;
  try {
    const url = await uploadImage(file, st => toast(st));
    $('#sAvatar').value = url;
    toast('头像上传成功，记得保存设置');
  } catch (err) { toast('上传失败：' + err.message); }
  e.target.value = '';
});

/* 赞助图片上传（事件委托） */
document.addEventListener('click', e => {
  if (e.target.classList.contains('sponsor-upload')) {
    e.preventDefault();
    e.target.closest('.sponsor-row').querySelector('.sponsor-file').click();
  }
});
document.addEventListener('change', e => {
  if (!e.target.classList.contains('sponsor-file')) return;
  const file = e.target.files[0];
  if (!file) return;
  const row = e.target.closest('.sponsor-row');
  const preview = row.querySelector('.sponsor-preview');
  const placeholder = row.querySelector('.sponsor-placeholder');
  const input = row.querySelector('.l-image');
  uploadImage(file, st => toast(st)).then(url => {
    input.value = url;
    preview.src = url;
    preview.hidden = false;
    placeholder.hidden = true;
    toast('赞助图片上传成功');
  }).catch(err => toast('上传失败：' + err.message));
  e.target.value = '';
});

/* 修改密码 */
$('#btnChangePw').addEventListener('click', async () => {
  const pwOld = $('#pwOld').value;
  const pwNew = $('#pwNew').value;
  const pwNew2 = $('#pwNew2').value;
  if (!pwOld || !pwNew) { toast('请填写完整'); return; }
  if (pwNew !== pwNew2) { toast('两次输入的新密码不一致'); return; }
  if (pwNew.length < 6) { toast('新密码至少 6 位'); return; }
  try {
    await api('/api/change-password', {
      method: 'POST',
      body: JSON.stringify({ oldPassword: pwOld, newPassword: pwNew })
    });
    $('#pwOld').value = $('#pwNew').value = $('#pwNew2').value = '';
    toast('密码修改成功 ✅ 下次登录请使用新密码');
  } catch (e) { toast(e.message); }
});

/* ================= 管理初始化 & 启动 ================= */
function initAdmin() {
  // 编辑器初始内容提示
  if (!editor.innerHTML.trim()) {
    editor.innerHTML = '<p><br></p>';
  }
}

/* 启动：有 token 则校验并直接进入后台 */
(async function boot() {
  try {
    if (TOKEN) {
      await api('/api/posts?all=1');
      showAdmin();
    } else {
      showLogin();
    }
  } catch (err) {
    console.error('boot failed:', err);
    showLogin();
    $('#loginErr').textContent = '自动登录失败，请手动登录：' + (err && err.message ? err.message : '会话已过期');
  }
})();

</script>
</body>
</html>
`,
  "/admin.html": `<!DOCTYPE html>
<html lang="zh-CN">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>后台管理 - 个人博客</title>
  <link rel="icon" href="data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'><text y='0.9em' font-size='90'>✦</text></svg>">
  <link rel="stylesheet" href="/css/style.css?v=11">
  <meta http-equiv="Cache-Control" content="no-store, no-cache, must-revalidate">
  <meta http-equiv="Pragma" content="no-cache">
  <meta http-equiv="Expires" content="0">
  <style>/* 内置 CSS 变量，确保即使外部样式未加载主题也不崩 */
/* 某些浏览器/UA 对 hidden 属性默认 display:none 优先级不够，显式补强 */
[hidden], .hidden { display: none !important; }
html, body { -webkit-tap-highlight-color: transparent; }
body.admin-body { visibility: visible; }
#loginView, #adminView { transition: opacity .15s ease; }
#loginView[hidden], #adminView[hidden] { opacity: 0; pointer-events: none; }
#loginView:not([hidden]), #adminView:not([hidden]) { opacity: 1; pointer-events: auto; }
:root {
  --bg: #f4f5fb;
  --bg-soft: #eceef8;
  --card: #ffffff;
  --text: #1f2430;
  --text-light: #6b7280;
  --primary: #5b5bd6;
  --primary-2: #8b5cf6;
  --primary-soft: rgba(91, 91, 214, 0.09);
  --border: #e6e8f0;
  --shadow: 0 1px 2px rgba(23, 25, 60, 0.05), 0 10px 30px rgba(23, 25, 60, 0.07);
  --shadow-hover: 0 4px 10px rgba(23, 25, 60, 0.08), 0 16px 40px rgba(91, 91, 214, 0.16);
  --radius: 16px;
}
[data-theme="dark"] {
  --bg: #0e1017;
  --bg-soft: #161927;
  --card: #171a26;
  --text: #e6e8f0;
  --text-light: #9aa1b5;
  --primary: #8789f5;
  --primary-2: #a78bfa;
  --primary-soft: rgba(135, 137, 245, 0.14);
  --border: #252a3a;
  --shadow: 0 1px 2px rgba(0, 0, 0, 0.3), 0 10px 30px rgba(0, 0, 0, 0.35);
  --shadow-hover: 0 4px 10px rgba(0, 0, 0, 0.35), 0 16px 40px rgba(135, 137, 245, 0.2);
}
[data-theme="glass"] {
  --bg: #eef1ff;
  --bg-soft: rgba(255, 255, 255, 0.55);
  --card: rgba(255, 255, 255, 0.72);
  --text: #1f2430;
  --text-light: #5b6280;
  --primary: #5b5bd6;
  --primary-2: #8b5cf6;
  --primary-soft: rgba(91, 91, 214, 0.12);
  --border: rgba(255, 255, 255, 0.55);
  --shadow: 0 8px 32px rgba(31, 36, 80, 0.12);
  --shadow-hover: 0 12px 44px rgba(91, 91, 214, 0.22);
}
[data-theme="tech"] {
  --bg: #05070a;
  --bg-soft: #0c0f17;
  --card: #0a0d14;
  --text: #e8f2ff;
  --text-light: #7a8aa8;
  --primary: #00f0ff;
  --primary-2: #7c3aed;
  --primary-soft: rgba(0, 240, 255, 0.12);
  --border: #1b2440;
  --shadow: 0 0 14px rgba(0, 240, 255, 0.12), 0 10px 30px rgba(0, 0, 0, 0.45);
  --shadow-hover: 0 0 22px rgba(0, 240, 255, 0.22), 0 12px 40px rgba(0, 0, 0, 0.5);
}
[data-theme="neumorph"] {
  --bg: #e0e5ec;
  --bg-soft: #e0e5ec;
  --card: rgba(224, 229, 236, 0.78);
  --text: #3a3f4b;
  --text-light: #6b7285;
  --primary: #5b5bd6;
  --primary-2: #8b5cf6;
  --primary-soft: rgba(91, 91, 214, 0.12);
  --border: rgba(255, 255, 255, 0.45);
  --shadow: 9px 9px 18px #b8b9be, -9px -9px 18px #ffffff;
  --shadow-hover: 12px 12px 24px #b0b1b6, -12px -12px 24px #ffffff;
}
</style>
<style data-admin-inline>
/* ================= 后台整体布局 ================= */
.admin-body { background: var(--bg); min-height: 100vh; }

.admin-shell { display: flex; min-height: 100vh; }

.sidebar {
  width: 232px;
  flex-shrink: 0;
  background: var(--card);
  border-right: 1px solid var(--border);
  padding: 20px 14px;
  position: sticky;
  top: 0;
  height: 100vh;
  display: flex;
  flex-direction: column;
}
.side-brand {
  display: flex; align-items: center; gap: 10px;
  font-weight: 700; font-size: 17px;
  padding: 4px 10px 10px;
}
.side-theme {
  display: inline-flex; align-items: center; gap: 6px;
  margin: 0 10px 14px;
  padding: 6px 12px;
  border-radius: 999px;
  border: 1px solid var(--border);
  background: var(--bg);
  color: var(--text-light);
  font-size: 13px;
  cursor: pointer;
  user-select: none;
  transition: 0.2s;
}
.side-theme:hover { border-color: var(--primary); color: var(--primary); }
.side-nav { display: flex; flex-direction: column; gap: 4px; }
.side-nav a {
  padding: 10px 14px;
  border-radius: 11px;
  color: var(--text-light);
  font-size: 14.5px;
  cursor: pointer;
  transition: 0.18s;
}
.side-nav a:hover { background: var(--primary-soft); color: var(--text); }
.side-nav a.active {
  background: linear-gradient(135deg, var(--primary), var(--primary-2));
  color: #fff;
  font-weight: 600;
}
.side-nav a.danger:hover { color: #e11d48; background: rgba(225, 29, 72, 0.09); }
.side-nav hr { border: none; border-top: 1px solid var(--border); margin: 12px 0; }

.admin-main { flex: 1; padding: 28px 34px 60px; min-width: 0; }
.view { max-width: 980px; }

.page-head { display: flex; align-items: center; gap: 14px; margin-bottom: 8px; flex-wrap: wrap; }
.page-title { font-size: 22px; font-weight: 800; margin: 0 0 22px; }
.sub-title { font-size: 16px; font-weight: 700; margin: 0 0 14px; }
.draft-flag {
  font-size: 12.5px;
  color: #d97706;
  background: rgba(217, 119, 6, 0.12);
  padding: 3px 12px;
  border-radius: 999px;
}

/* ================= 登录页 ================= */
.login-wrap {
  min-height: 100vh;
  display: grid;
  place-items: center;
  background:
    radial-gradient(700px 350px at 80% -10%, var(--primary-soft), transparent 70%),
    var(--bg);
  padding: 20px;
}
.login-card {
  width: 100%;
  max-width: 400px;
  background: var(--card);
  border: 1px solid var(--border);
  border-radius: 20px;
  box-shadow: var(--shadow);
  padding: 38px 36px 30px;
  display: flex;
  flex-direction: column;
  gap: 14px;
}
.login-card h2 { margin: 0; text-align: center; font-size: 22px; }
.login-logo {
  width: 54px; height: 54px;
  margin: 0 auto 6px;
  border-radius: 16px;
  display: grid; place-items: center;
  background: linear-gradient(135deg, var(--primary), var(--primary-2));
  color: #fff; font-size: 26px;
}
.login-tip { margin: 0; text-align: center; color: var(--text-light); font-size: 12.5px; }
.login-card label { display: flex; flex-direction: column; gap: 6px; font-size: 13.5px; color: var(--text-light); }
.login-card input, .form-item input, .form-item select, .tb-select {
  border: 1px solid var(--border);
  background: var(--bg);
  color: var(--text);
  border-radius: 10px;
  padding: 10px 14px;
  font-size: 14.5px;
  outline: none;
  transition: 0.18s;
  width: 100%;
}
.login-card input:focus, .form-item input:focus, .form-item select:focus, .tb-select:focus {
  border-color: var(--primary);
  box-shadow: 0 0 0 3px var(--primary-soft);
}
.login-err { color: #e11d48; font-size: 13px; margin: 0; min-height: 18px; text-align: center; }
.login-back { text-align: center; color: var(--text-light); font-size: 13px; }
.login-back:hover { color: var(--primary); }

/* ================= 按钮 ================= */
.btn {
  border: none;
  border-radius: 11px;
  padding: 10px 20px;
  font-size: 14.5px;
  font-weight: 600;
  cursor: pointer;
  transition: 0.18s;
  font-family: inherit;
}
.btn-primary {
  background: linear-gradient(135deg, var(--primary), var(--primary-2));
  color: #fff;
  box-shadow: 0 4px 14px rgba(91, 91, 214, 0.35);
}
.btn-primary:hover { filter: brightness(1.08); transform: translateY(-1px); }
.btn-primary:disabled { opacity: 0.6; cursor: not-allowed; transform: none; }
.btn-ghost {
  background: var(--card);
  border: 1px solid var(--border);
  color: var(--text);
}
.btn-ghost:hover { border-color: var(--primary); color: var(--primary); }
.btn-sm { padding: 8px 14px; font-size: 13px; }
.btn-block { width: 100%; }
.btn-lg { padding: 12px 32px; font-size: 15px; }
.btn-danger-link { background: none; border: none; color: #e11d48; cursor: pointer; font-size: 13.5px; padding: 4px 8px; border-radius: 8px; }
.btn-danger-link:hover { background: rgba(225, 29, 72, 0.09); }

/* ================= 统计卡片 ================= */
.stats { display: grid; grid-template-columns: repeat(4, 1fr); gap: 16px; margin-bottom: 28px; }
.stat-card { padding: 22px 24px; display: flex; flex-direction: column; gap: 4px; }
.stat-num { font-size: 30px; font-weight: 800; background: linear-gradient(120deg, var(--primary), var(--primary-2)); -webkit-background-clip: text; background-clip: text; color: transparent; }
.stat-label { font-size: 13px; color: var(--text-light); }

/* ================= 数据表格 ================= */
.table-wrap { padding: 8px 14px; overflow-x: auto; }
.data-table { width: 100%; border-collapse: collapse; font-size: 14px; }
.data-table th {
  text-align: left;
  color: var(--text-light);
  font-weight: 600;
  font-size: 13px;
  padding: 12px 10px;
  border-bottom: 1px solid var(--border);
  white-space: nowrap;
}
.data-table td { padding: 13px 10px; border-bottom: 1px solid var(--border); vertical-align: middle; }
.data-table tr:last-child td { border-bottom: none; }
.data-table tr:hover td { background: var(--primary-soft); }
.td-title { font-weight: 600; max-width: 320px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.td-title a:hover { color: var(--primary); }
.status-pill {
  font-size: 12px;
  padding: 3px 10px;
  border-radius: 999px;
  font-weight: 600;
  white-space: nowrap;
}
.status-pill.published { color: #16a34a; background: rgba(22, 163, 74, 0.12); }
.status-pill.draft { color: #d97706; background: rgba(217, 119, 6, 0.14); }
.pin-toggle {
  border: 1px solid var(--border);
  background: var(--card);
  color: var(--text-light);
  border-radius: 7px;
  padding: 4px 9px;
  font-size: 12.5px;
  cursor: pointer;
  transition: 0.18s;
}
.pin-toggle:hover { border-color: var(--primary); color: var(--primary); }
.pin-toggle.on {
  background: linear-gradient(120deg, rgba(99,102,241,0.16), rgba(14,165,233,0.16));
  border-color: var(--primary);
  color: var(--primary);
  font-weight: 600;
}
.row-pinned { background: rgba(99,102,241,0.05); }
.td-actions { white-space: nowrap; }
.td-actions button { margin-right: 4px; }

/* ================= 表单 ================= */
.form-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 16px 20px; margin-bottom: 22px; }
.form-item { display: flex; flex-direction: column; gap: 7px; }
.form-item label { font-size: 13.5px; color: var(--text-light); font-weight: 600; }
.span-2 { grid-column: span 2; }
.inline-row { display: flex; gap: 10px; }
.inline-row input { flex: 1; }
.inline-row .btn { white-space: nowrap; }
textarea.form-control { resize: vertical; min-height: 90px; }

/* ================= 富文本编辑器 ================= */
.editor-wrap { padding: 0; overflow: hidden; }
.editor-toolbar {
  display: flex;
  align-items: center;
  flex-wrap: wrap;
  gap: 5px;
  padding: 10px 12px;
  border-bottom: 1px solid var(--border);
  background: var(--bg-soft);
}
.tb-select { width: auto; padding: 7px 10px; font-size: 13px; border-radius: 8px; }
.tb-btn {
  min-width: 34px;
  height: 34px;
  padding: 0 9px;
  border: 1px solid transparent;
  border-radius: 9px;
  background: var(--card);
  color: var(--text);
  cursor: pointer;
  font-size: 14px;
  font-family: inherit;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  transition: 0.15s;
}
.tb-btn:hover { border-color: var(--primary); color: var(--primary); background: var(--primary-soft); }
.tb-btn:active { transform: scale(0.94); }
.tb-sep { width: 1px; height: 22px; background: var(--border); margin: 0 5px; }
.tb-color { position: relative; overflow: hidden; gap: 5px; }
.tb-color input[type="color"] {
  position: absolute;
  inset: 0;
  opacity: 0;
  cursor: pointer;
  border: none;
  padding: 0;
}
.color-preview { font-weight: 800; font-size: 15px; }
#forePreview { color: #e11d48; }
.mark-preview { font-size: 14px; }
.color-dots {
  display: inline-flex;
  align-items: center;
  gap: 5px;
  margin: 0 2px;
}
.color-dot {
  width: 18px; height: 18px;
  border-radius: 50%;
  border: 1px solid rgba(128,128,128,0.25);
  cursor: pointer;
  padding: 0;
  flex-shrink: 0;
  transition: transform 0.15s;
}
.color-dot:active { transform: scale(0.85); }

.rich-editor {
  min-height: 380px;
  max-height: 60vh;
  overflow-y: auto;
  padding: 24px 28px;
  font-size: 16px;
  line-height: 1.8;
  outline: none;
  background: var(--card);
}
.rich-editor:focus { background: var(--card); }
.rich-editor:empty::before {
  content: attr(data-placeholder);
  color: var(--text-light);
  pointer-events: none;
}
/* 编辑器内部内容样式（与前台正文一致） */
.rich-editor h1, .rich-editor h2, .rich-editor h3 { line-height: 1.4; margin: 1.2em 0 0.5em; }
.rich-editor h1 { font-size: 26px; }
.rich-editor h2 { font-size: 22px; }
.rich-editor h3 { font-size: 18px; }
.rich-editor p { margin: 0.6em 0; }
.rich-editor img { max-width: 100%; border-radius: 10px; margin: 8px 0; }
.rich-editor a { color: var(--primary); text-decoration: underline; text-underline-offset: 3px; }
.rich-editor blockquote {
  margin: 1em 0; padding: 10px 16px;
  border-left: 4px solid var(--primary);
  background: var(--primary-soft);
  border-radius: 0 10px 10px 0;
}
.rich-editor pre {
  background: #191b29; color: #e6e8f0;
  padding: 14px 16px; border-radius: 10px;
  overflow-x: auto; font-size: 13.5px; line-height: 1.6;
}
.rich-editor code { font-family: Consolas, Monaco, monospace; background: var(--bg-soft); padding: 2px 6px; border-radius: 5px; font-size: 0.9em; }
.rich-editor pre code { background: none; padding: 0; }
.rich-editor ul, .rich-editor ol { padding-left: 1.5em; }
.rich-editor hr { border: none; border-top: 1px solid var(--border); }
.rich-editor mark { padding: 0 3px; border-radius: 4px; }

.editor-hint {
  padding: 10px 16px;
  font-size: 12.5px;
  color: var(--text-light);
  border-top: 1px solid var(--border);
  background: var(--bg-soft);
}
.editor-actions { display: flex; align-items: center; gap: 14px; margin-top: 20px; }
.save-msg { font-size: 13.5px; color: var(--text-light); }

/* ================= 弹窗 ================= */
.modal-overlay {
  position: fixed;
  inset: 0;
  background: rgba(15, 17, 25, 0.55);
  backdrop-filter: blur(4px);
  display: none;
  place-items: center;
  z-index: 100;
  padding: 20px;
}
.modal-overlay:not([hidden]) { display: grid; }
.modal { width: 100%; max-width: 430px; padding: 26px 26px 22px; border-radius: 18px; }
.modal h3 { margin: 0 0 18px; font-size: 18px; }
.modal .form-item { margin-bottom: 14px; }
.modal-actions { display: flex; justify-content: flex-end; gap: 10px; margin-top: 18px; }
.checkbox-row { display: flex; align-items: center; gap: 8px; font-size: 14px; color: var(--text-light); margin-top: 4px; }

.tabs { display: flex; gap: 6px; margin-bottom: 16px; }
.tab {
  border: none;
  background: var(--bg-soft);
  color: var(--text-light);
  padding: 8px 18px;
  border-radius: 999px;
  font-size: 13.5px;
  cursor: pointer;
  font-family: inherit;
}
.tab.active { background: linear-gradient(135deg, var(--primary), var(--primary-2)); color: #fff; font-weight: 600; }
.tab-pane { display: flex; flex-direction: column; gap: 10px; }

.upload-area {
  display: flex;
  align-items: center;
  justify-content: center;
  text-align: center;
  padding: 30px 18px;
  border: 2px dashed var(--border);
  border-radius: 12px;
  color: var(--text-light);
  font-size: 13.5px;
  cursor: pointer;
  transition: 0.2s;
}
.upload-area:hover { border-color: var(--primary); color: var(--primary); background: var(--primary-soft); }
.upload-status { font-size: 13px; color: var(--primary); min-height: 18px; }

/* ================= 站点设置 ================= */
.settings-block { padding: 24px 26px; margin-bottom: 22px; }
.block-head { display: flex; justify-content: space-between; align-items: center; margin-bottom: 6px; }
.block-tip { color: var(--text-light); font-size: 12.5px; margin: 0 0 14px; }

.row-grid {
  display: grid;
  gap: 10px;
  padding: 12px 14px;
  border: 1px solid var(--border);
  border-radius: 12px;
  margin-bottom: 10px;
  background: var(--bg);
}
.contact-row { grid-template-columns: 130px 110px 1fr 1.2fr 40px; align-items: center; }
.link-row { grid-template-columns: 160px 1.6fr 1fr 40px; align-items: center; }
.sponsor-row { grid-template-columns: 160px 110px 1fr 1fr 40px; align-items: center; }
.sponsor-img-wrap { display: flex; flex-direction: column; align-items: center; gap: 6px; }
.sponsor-preview {
  width: 70px; height: 70px; object-fit: cover; border-radius: 10px;
  border: 1px solid var(--border); background: var(--bg-soft);
}
.sponsor-placeholder {
  width: 70px; height: 70px; border-radius: 10px; background: var(--bg-soft);
  display: grid; place-items: center; font-size: 28px; border: 1px dashed var(--border);
}
.sponsor-upload { white-space: nowrap; }
.row-grid input, .row-grid select {
  border: 1px solid var(--border);
  background: var(--card);
  color: var(--text);
  border-radius: 8px;
  padding: 8px 10px;
  font-size: 13.5px;
  outline: none;
  width: 100%;
}
.row-grid input:focus { border-color: var(--primary); }
.row-del {
  border: none;
  background: none;
  color: #e11d48;
  font-size: 16px;
  cursor: pointer;
  height: 34px;
  border-radius: 8px;
}
.row-del:hover { background: rgba(225, 29, 72, 0.09); }

/* ================= Toast ================= */
#toast {
  position: fixed;
  left: 50%; bottom: 34px;
  transform: translateX(-50%) translateY(20px);
  background: var(--text);
  color: var(--bg);
  padding: 10px 22px;
  border-radius: 999px;
  font-size: 14px;
  opacity: 0;
  pointer-events: none;
  transition: 0.25s;
  z-index: 999;
}
#toast.show { opacity: 1; transform: translateX(-50%) translateY(0); }

/* ================= 响应式 ================= */
@media (max-width: 980px) {
  .stats { grid-template-columns: repeat(2, 1fr); }
  .contact-row { grid-template-columns: 120px 1fr 1fr 40px; }
  .contact-row .c-link { grid-column: span 3; }
}
@media (max-width: 860px) {
  .admin-shell { flex-direction: column; }
  .sidebar { width: 100%; height: auto; position: static; padding: 12px; }
  .side-brand { padding: 6px 10px 10px; }
  .side-nav { flex-direction: row; flex-wrap: wrap; }
  .side-nav hr { display: none; }
  .side-nav a { padding: 8px 12px; font-size: 13.5px; }
  .admin-main { padding: 20px 16px 40px; }
  .form-grid { grid-template-columns: 1fr; }
  .span-2 { grid-column: span 1; }
  .contact-row, .link-row, .sponsor-row { grid-template-columns: 1fr 1fr 40px; }
  .contact-row .c-value, .contact-row .c-link, .link-row .l-url, .link-row .l-desc,
  .sponsor-row .l-url, .sponsor-row .l-desc { grid-column: span 2; }
  .sponsor-img-wrap { grid-column: span 2; flex-direction: row; justify-content: flex-start; }
}

/* 玻璃/拟态主题下后台元素也应用毛玻璃与拟态阴影 */
[data-theme="glass"] .sidebar,
[data-theme="glass"] .login-card,
[data-theme="glass"] .card,
[data-theme="glass"] .modal,
[data-theme="glass"] .tb-btn,
[data-theme="glass"] .tb-select,
[data-theme="glass"] input,
[data-theme="glass"] select,
[data-theme="glass"] textarea {
  backdrop-filter: blur(16px);
  -webkit-backdrop-filter: blur(16px);
  background: var(--card);
  border: 1px solid rgba(255, 255, 255, 0.6);
}
[data-theme="glass"] .rich-editor { background: var(--card); }

[data-theme="neumorph"] .sidebar,
[data-theme="neumorph"] .login-card,
[data-theme="neumorph"] .card,
[data-theme="neumorph"] .modal,
[data-theme="neumorph"] .settings-block,
[data-theme="neumorph"] .editor-wrap {
  box-shadow: var(--shadow);
  border: 1px solid rgba(255, 255, 255, 0.55);
  background: var(--card);
  backdrop-filter: blur(12px);
}
[data-theme="neumorph"] .tb-btn,
[data-theme="neumorph"] .tb-select,
[data-theme="neumorph"] input,
[data-theme="neumorph"] select,
[data-theme="neumorph"] textarea {
  box-shadow: inset 3px 3px 6px #b8b9be, inset -3px -3px 6px #ffffff;
  border: none;
  background: var(--bg);
}
[data-theme="neumorph"] .btn-primary {
  box-shadow: 6px 6px 12px #b8b9be, -6px -6px 12px #ffffff;
}
[data-theme="neumorph"] .btn-ghost:hover,
[data-theme="neumorph"] .tb-btn:hover {
  box-shadow: 4px 4px 8px #b8b9be, -4px -4px 8px #ffffff;
}

[data-theme="tech"] .sidebar,
[data-theme="tech"] .login-card,
[data-theme="tech"] .card,
[data-theme="tech"] .modal,
[data-theme="tech"] .editor-wrap {
  border: 1px solid rgba(0, 240, 255, 0.18);
  box-shadow: 0 0 18px rgba(0, 240, 255, 0.08);
  background: var(--card);
}
[data-theme="tech"] .tb-btn,
[data-theme="tech"] .tb-select,
[data-theme="tech"] input,
[data-theme="tech"] select,
[data-theme="tech"] textarea {
  border: 1px solid rgba(0, 240, 255, 0.22);
  background: var(--bg);
}
[data-theme="tech"] .rich-editor { background: var(--card); }

</style>
</head>
<body class="admin-body">

  <!-- ============ 登录视图 ============ -->
  <div id="loginView" class="login-wrap">
    <form class="login-card" id="loginForm">
      <div class="login-logo"><span>✦</span></div>
      <h2>博客后台登录</h2>
      <p class="login-tip">默认账号 admin，密码 admin123（登录后可修改）</p>
      <label>用户名
        <input id="loginUser" autocomplete="username" placeholder="请输入用户名" required>
      </label>
      <label>密码
        <input id="loginPass" type="password" autocomplete="current-password" placeholder="请输入密码" required>
      </label>
      <button class="btn btn-primary btn-block" id="loginBtn" type="submit">登 录</button>
      <p class="login-err" id="loginErr"></p>
      <a class="login-back" href="/">← 返回博客首页</a>
    </form>
  </div>

  <!-- ============ 管理视图 ============ -->
  <div id="adminView" class="admin-shell" hidden>
    <aside class="sidebar">
      <div class="side-brand"><span class="logo-mark">✦</span><span id="brandName">博客后台</span></div>
      <div class="side-theme" id="adminThemePicker" title="切换主题">
        <span id="adminThemeIcon">🌙</span><span id="adminThemeLabel">深色</span>
      </div>
      <nav class="side-nav">
        <a data-view="dashboard" class="active">📊 仪表盘</a>
        <a data-view="posts">📚 文章管理</a>
        <a data-view="editor" id="navNewPost">✍️ 写文章</a>
        <a data-view="settings">⚙️ 站点设置</a>
        <a data-view="subs">📧 订阅管理</a>
        <hr>
        <a href="/" target="_blank">🏠 查看博客</a>
        <a id="logoutBtn" class="danger">🚪 退出登录</a>
      </nav>
    </aside>

    <div class="admin-main">
      <!-- 仪表盘 -->
      <section id="view-dashboard" class="view">
        <h2 class="page-title">仪表盘</h2>
        <div class="stats">
          <div class="stat-card card"><span class="stat-num" id="statTotal">0</span><span class="stat-label">文章总数</span></div>
          <div class="stat-card card"><span class="stat-num" id="statPublished">0</span><span class="stat-label">已发布</span></div>
          <div class="stat-card card"><span class="stat-num" id="statDraft">0</span><span class="stat-label">草稿箱</span></div>
          <div class="stat-card card"><span class="stat-num" id="statViews">0</span><span class="stat-label">累计阅读</span></div>
        </div>
        <h3 class="sub-title">最近文章</h3>
        <div class="table-wrap card"><table class="data-table" id="recentTable"></table></div>
      </section>

      <!-- 文章管理 -->
      <section id="view-posts" class="view" hidden>
        <div class="page-head">
          <h2 class="page-title">文章管理</h2>
          <button class="btn btn-primary" id="btnNewPost">＋ 新建文章</button>
        </div>
        <div class="table-wrap card"><table class="data-table" id="postsTable"></table></div>
      </section>

      <!-- 编辑器 -->
      <section id="view-editor" class="view" hidden>
        <div class="page-head">
          <h2 class="page-title" id="editorMode">写文章</h2>
          <span class="draft-flag" id="editingFlag" hidden>正在编辑已有文章</span>
        </div>

        <div class="form-grid">
          <div class="form-item span-2">
            <label>标题 *</label>
            <input id="fTitle" placeholder="请输入文章标题">
          </div>
          <div class="form-item span-2">
            <label>摘要</label>
            <input id="fSummary" placeholder="留空将自动截取正文前 120 字">
          </div>
          <div class="form-item">
            <label>封面图</label>
            <div class="inline-row">
              <input id="fCover" placeholder="封面图 URL，可留空">
              <button type="button" class="btn btn-ghost btn-sm" id="btnCoverUpload">上传</button>
              <input type="file" id="fCoverFile" accept="image/*" hidden>
            </div>
          </div>
          <div class="form-item">
            <label>标签</label>
            <input id="fTags" placeholder="多个标签用逗号分隔，如：生活, 摄影">
          </div>
          <div class="form-item">
            <label>发布状态</label>
            <select id="fStatus">
              <option value="published">✅ 立即发布</option>
              <option value="draft">📝 存为草稿</option>
            </select>
          </div>
        </div>

        <!-- 富文本编辑器 -->
        <div class="editor-wrap card">
          <div class="editor-toolbar" id="toolbar">
            <select id="blockType" class="tb-select" title="段落格式">
              <option value="p">正文</option>
              <option value="h1">标题一</option>
              <option value="h2">标题二</option>
              <option value="h3">标题三</option>
              <option value="blockquote">引用</option>
              <option value="pre">代码块</option>
            </select>
            <select id="fontSizeSel" class="tb-select" title="字号大小（先选大小可直接开始打字，或先选中文字再改）">
              <option value="">字号…</option>
              <option value="12">12px 很小</option>
              <option value="14">14px 小</option>
              <option value="16">16px 标准</option>
              <option value="18">18px 中大</option>
              <option value="20">20px 大</option>
              <option value="24">24px 较大</option>
              <option value="28">28px 大号</option>
              <option value="32">32px 特大</option>
              <option value="36">36px 超大</option>
              <option value="clear">清除字号</option>
            </select>
            <span class="tb-sep"></span>
            <button type="button" class="tb-btn" data-cmd="bold" title="加粗"><b>B</b></button>
            <button type="button" class="tb-btn" data-cmd="italic" title="斜体"><i>I</i></button>
            <button type="button" class="tb-btn" data-cmd="underline" title="下划线"><u>U</u></button>
            <button type="button" class="tb-btn" data-cmd="strikeThrough" title="删除线（划线）"><s>S</s></button>
            <span class="tb-sep"></span>
            <label class="tb-btn tb-color" title="文字颜色">
              <span class="color-preview" id="forePreview">A</span>
              <input type="color" id="foreColorInput" value="#e11d48">
            </label>
            <span class="color-dots" id="forePalette">
              <button type="button" class="color-dot" style="background:#e11d48" data-color="#e11d48" title="红"></button>
              <button type="button" class="color-dot" style="background:#2563eb" data-color="#2563eb" title="蓝"></button>
              <button type="button" class="color-dot" style="background:#16a34a" data-color="#16a34a" title="绿"></button>
              <button type="button" class="color-dot" style="background:#9333ea" data-color="#9333ea" title="紫"></button>
              <button type="button" class="color-dot" style="background:#ea580c" data-color="#ea580c" title="橙"></button>
              <button type="button" class="color-dot" style="background:#0f172a" data-color="#0f172a" title="黑"></button>
            </span>
            <label class="tb-btn tb-color" title="荧光笔标记（高亮背景）">
              <span class="color-preview mark-preview" id="hilitePreview">🖍</span>
              <input type="color" id="hiliteColorInput" value="#fde047">
            </label>
            <span class="color-dots" id="hilitePalette">
              <button type="button" class="color-dot" style="background:#fde047" data-color="#fde047" title="黄"></button>
              <button type="button" class="color-dot" style="background:#86efac" data-color="#86efac" title="绿"></button>
              <button type="button" class="color-dot" style="background:#93c5fd" data-color="#93c5fd" title="蓝"></button>
              <button type="button" class="color-dot" style="background:#fca5a5" data-color="#fca5a5" title="红"></button>
              <button type="button" class="color-dot" style="background:#d8b4fe" data-color="#d8b4fe" title="紫"></button>
              <button type="button" class="color-dot" style="background:#fdba74" data-color="#fdba74" title="橙"></button>
            </span>
            <span class="tb-sep"></span>
            <button type="button" class="tb-btn" data-cmd="insertUnorderedList" title="无序列表">• ≡</button>
            <button type="button" class="tb-btn" data-cmd="insertOrderedList" title="有序列表">1. ≡</button>
            <button type="button" class="tb-btn" data-cmd="justifyLeft" title="左对齐">⬅</button>
            <button type="button" class="tb-btn" data-cmd="justifyCenter" title="居中">≡</button>
            <button type="button" class="tb-btn" data-cmd="justifyRight" title="右对齐">➡</button>
            <span class="tb-sep"></span>
            <button type="button" class="tb-btn" id="btnInsertLink" title="插入可点击链接">🔗 链接</button>
            <button type="button" class="tb-btn" id="btnInsertImage" title="插入图片（上传/外链/粘贴）">🖼️ 图片</button>
            <button type="button" class="tb-btn" data-cmd="insertHorizontalRule" title="插入分割线">—</button>
            <button type="button" class="tb-btn" data-cmd="removeFormat" title="清除格式">🧹</button>
            <span class="tb-sep"></span>
            <button type="button" class="tb-btn" data-cmd="undo" title="撤销">↶</button>
            <button type="button" class="tb-btn" data-cmd="redo" title="重做">↷</button>
          </div>
          <div id="editor" class="rich-editor" contenteditable="true"
               data-placeholder="开始写作吧… 选中文字可调整字号 / 加粗 / 高亮标记 / 划线，可插入链接与图片，支持直接粘贴图片"></div>
          <div class="editor-hint">💡 选中文字后点工具栏应用样式；粘贴图片会自动上传；链接在新窗口打开</div>
        </div>

        <div class="editor-actions">
          <button class="btn btn-primary" id="btnSave">💾 保存文章</button>
          <button class="btn btn-ghost" id="btnPreview">👁 保存并预览</button>
          <span class="save-msg" id="saveMsg"></span>
        </div>
      </section>

      <!-- 站点设置 -->
      <section id="view-settings" class="view" hidden>
        <h2 class="page-title">站点设置</h2>

        <div class="settings-block card">
          <h3 class="sub-title">基本信息</h3>
          <div class="form-grid">
            <div class="form-item"><label>站点名称</label><input id="sSiteName"></div>
            <div class="form-item"><label>博主昵称</label><input id="sOwnerName"></div>
            <div class="form-item span-2">
              <label>头像图片</label>
              <div class="inline-row">
                <input id="sAvatar" placeholder="头像图片 URL（留空显示首字母）">
                <button type="button" class="btn btn-ghost btn-sm" id="btnAvatarUpload">上传</button>
                <input type="file" id="sAvatarFile" accept="image/*" hidden>
              </div>
            </div>
            <div class="form-item span-2"><label>个人简介（显示在主页）</label><input id="sBio" placeholder="一句话介绍自己"></div>
          </div>
        </div>

        <div class="settings-block card">
          <div class="block-head">
            <h3 class="sub-title">联系方式（主页侧栏展示）</h3>
            <button class="btn btn-ghost btn-sm" id="btnAddContact">＋ 添加</button>
          </div>
          <p class="block-tip">「跳转链接」填写后点击可跳转（支持 https:// 和 mailto:）；留空则点击复制内容。</p>
          <div id="contactRows"></div>
        </div>

        <div class="settings-block card">
          <div class="block-head">
            <h3 class="sub-title">友情链接（点击跳转到对方网站）</h3>
            <button class="btn btn-ghost btn-sm" id="btnAddLink">＋ 添加</button>
          </div>
          <div id="linkRows"></div>
        </div>

        <div class="settings-block card">
          <div class="block-head">
            <h3 class="sub-title">☕ 赞助支持（点击跳转到赞助页面）</h3>
            <button class="btn btn-ghost btn-sm" id="btnAddSponsor">＋ 添加</button>
          </div>
          <div id="sponsorRows"></div>
        </div>

        <button class="btn btn-primary btn-lg" id="btnSaveSite">💾 保存全部设置</button>

        <div class="settings-block card">
          <h3 class="sub-title">修改后台密码</h3>
          <div class="form-grid">
            <div class="form-item"><label>原密码</label><input type="password" id="pwOld"></div>
            <div class="form-item"><label>新密码（至少 6 位）</label><input type="password" id="pwNew"></div>
            <div class="form-item"><label>确认新密码</label><input type="password" id="pwNew2"></div>
          </div>
          <button class="btn btn-primary" id="btnChangePw">🔒 修改密码</button>
        </div>
      </section>

      <!-- 订阅管理（订阅量仅博主可见，不在前台展示） -->
      <section id="view-subs" class="view" hidden>
        <div class="page-head">
          <h2 class="page-title">📧 订阅管理</h2>
          <button class="btn btn-ghost" id="btnExportSubs">⬇️ 导出 CSV</button>
        </div>
        <div class="subs-summary card">
          <div class="subs-count" id="subsCount">0</div>
          <p class="subs-count-label">当前订阅人数（仅你可见）</p>
        </div>
        <div class="table-wrap card">
          <table class="data-table" id="subsTable">
            <thead><tr><th>邮箱</th><th>订阅时间</th><th>操作</th></tr></thead>
            <tbody><tr><td colspan="3" class="empty">加载中…</td></tr></tbody>
          </table>
        </div>
      </section>
    </div>
  </div>

  <!-- ============ 插入链接弹窗 ============ -->
  <div class="modal-overlay" id="linkModal" hidden>
    <div class="modal card">
      <h3>插入链接</h3>
      <div class="form-item"><label>链接地址 *</label>
        <input id="linkUrl" placeholder="https://example.com 或 mailto:xx@xx.com"></div>
      <div class="form-item"><label>显示文字</label>
        <input id="linkText" placeholder="留空则使用选中文字或链接地址"></div>
      <label class="checkbox-row"><input type="checkbox" id="linkBlank" checked> 在新窗口打开链接</label>
      <div class="modal-actions">
        <button class="btn btn-ghost" data-close>取消</button>
        <button class="btn btn-primary" id="linkConfirm">插入链接</button>
      </div>
    </div>
  </div>

  <!-- ============ 插入图片弹窗 ============ -->
  <div class="modal-overlay" id="imageModal" hidden>
    <div class="modal card">
      <h3>插入图片</h3>
      <div class="tabs">
        <button class="tab active" data-tab="upload">本地上传</button>
        <button class="tab" data-tab="url">图片 URL</button>
      </div>
      <div class="tab-pane" id="tab-upload">
        <label class="upload-area" id="uploadArea">
          📁 点击选择图片（jpg / png / gif / webp，最大 10MB）
          <input type="file" id="imageFile" accept="image/*" hidden>
        </label>
        <div class="upload-status" id="uploadStatus"></div>
      </div>
      <div class="tab-pane" id="tab-url" hidden>
        <div class="form-item"><label>图片地址 *</label>
          <input id="imageUrl" placeholder="https://example.com/photo.jpg"></div>
      </div>
      <div class="modal-actions">
        <button class="btn btn-ghost" data-close>取消</button>
        <button class="btn btn-primary" id="imageConfirm">插入图片</button>
      </div>
    </div>
  </div>

  <div id="toast"></div>
  <script data-admin-inline>
/* ================= 工具与全局状态 ================= */
const $ = s => document.querySelector(s);
const $$ = s => Array.from(document.querySelectorAll(s));

let TOKEN = localStorage.getItem('blogToken') || '';
let editingId = null;      // 当前编辑的文章 id（null = 新建）
let savedRange = null;     // 编辑器最近选区
let adminInited = false;

function authHeader() {
  return TOKEN ? { Authorization: 'Bearer ' + TOKEN } : {};
}
/* 带超时的 fetch，避免某些网络环境下请求永远 pending */
async function fetchWithTimeout(url, opts = {}, ms = 10000) {
  const ctrl = new AbortController();
  const id = setTimeout(() => ctrl.abort(), ms);
  try {
    return await fetch(url, { ...opts, signal: ctrl.signal });
  } catch (err) {
    if (err.name === 'AbortError') throw new Error('请求超时，请检查网络后重试');
    throw new Error('网络请求失败：' + (err.message || '无法连接到服务器'));
  } finally {
    clearTimeout(id);
  }
}

async function api(path, opts = {}) {
  const isForm = opts.body && (typeof FormData !== 'undefined' && opts.body instanceof FormData);
  const headers = { ...(opts.headers || {}), ...authHeader() };
  if (!isForm && opts.body) headers['Content-Type'] = 'application/json';
  const res = await fetchWithTimeout(path, { ...opts, headers });
  const data = await res.json().catch(() => ({}));
  if (res.status === 401) { showLogin(); throw new Error(data.error || '请先登录'); }
  if (!res.ok) throw new Error(data.error || '请求失败');
  return data;
}
/* 安全提示：MIUI/部分内置浏览器可能不显示 err 文本，用 alert 兜底 */
function hardAlert(msg) {
  try { if (window.alert) window.alert(msg); } catch {}
}
function stripHtml(html) {
  const div = document.createElement('div');
  div.innerHTML = html || '';
  return div.textContent.trim();
}

let toastTimer = null;
function toast(msg, ok = true) {
  const t = $('#toast');
  t.textContent = msg;
  t.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => t.classList.remove('show'), 2400);
}
function fmtDate(ts) {
  const d = new Date(ts);
  const p = n => String(n).padStart(2, '0');
  return \`\${d.getFullYear()}-\${p(d.getMonth() + 1)}-\${p(d.getDate())} \${p(d.getHours())}:\${p(d.getMinutes())}\`;
}

/* 主题（与前台一致，支持 light/dark/glass/tech/neumorph） */
const ADMIN_THEMES = [
  { id: 'light', icon: '☀️', label: '浅色' },
  { id: 'dark', icon: '🌙', label: '深色' },
  { id: 'glass', icon: '💎', label: '玻璃' },
  { id: 'tech', icon: '⚡', label: '科技' },
  { id: 'neumorph', icon: '🧊', label: '拟态玻璃' }
];
function applyAdminTheme(id) {
  const t = ADMIN_THEMES.find(x => x.id === id) || ADMIN_THEMES[1];
  document.documentElement.dataset.theme = id;
  try { localStorage.setItem('theme', id); } catch {}
  const icon = $('#adminThemeIcon');
  const label = $('#adminThemeLabel');
  if (icon) icon.textContent = t.icon;
  if (label) label.textContent = t.label;
}
function nextAdminTheme() {
  const cur = document.documentElement.dataset.theme || 'dark';
  const idx = ADMIN_THEMES.findIndex(t => t.id === cur);
  applyAdminTheme(ADMIN_THEMES[(idx + 1) % ADMIN_THEMES.length].id);
}
(function initTheme() {
  applyAdminTheme(
    localStorage.getItem('theme') ||
    (matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light')
  );
  const picker = $('#adminThemePicker');
  if (picker) picker.addEventListener('click', nextAdminTheme);
})();

/* ================= 登录 / 登出 ================= */
function showLogin() {
  TOKEN = '';
  localStorage.removeItem('blogToken');
  $('#adminView').hidden = true;
  $('#loginView').hidden = false;
  $('#linkModal').hidden = true;
  $('#imageModal').hidden = true;
}
function showAdmin() {
  try {
    if (!adminInited) { initAdmin(); adminInited = true; }
    switchView('dashboard');
    $('#loginView').hidden = true;
    $('#adminView').hidden = false;
    window.scrollTo(0, 0);
  } catch (err) {
    console.error('进入后台失败:', err);
    const msg = '进入后台失败: ' + (err && err.message ? err.message : '请刷新页面重试');
    $('#loginErr').textContent = msg;
    hardAlert(msg);
    showLogin();
  }
}

async function doLogin() {
  const btn = $('#loginBtn');
  const err = $('#loginErr');
  err.textContent = '';
  btn.disabled = true;
  btn.textContent = '登录中…';
  try {
    const data = await api('/api/login', {
      method: 'POST',
      body: JSON.stringify({
        username: $('#loginUser').value.trim(),
        password: $('#loginPass').value
      })
    });
    TOKEN = data.token || '';
    if (!TOKEN) throw new Error('登录未返回 token，请重试');
    let saved = false;
    try { localStorage.setItem('blogToken', TOKEN); saved = true; } catch {}
    if (!saved) hardAlert('当前浏览器可能禁用了本地存储，登录状态刷新后可能失效。');
    showAdmin();
  } catch (ex) {
    const msg = ex && ex.message ? ex.message : '登录失败，请检查网络或刷新页面重试';
    err.textContent = msg;
    hardAlert('登录失败：' + msg);
  } finally {
    btn.disabled = false;
    btn.textContent = '登 录';
  }
}
$('#loginForm').addEventListener('submit', e => { e.preventDefault(); doLogin(); });
/* 双保险：某些浏览器/自动填充场景下 submit 事件不触发，click 也能登录 */
$('#loginBtn').addEventListener('click', e => {
  e.preventDefault();
  e.stopPropagation();
  doLogin();
});

$('#logoutBtn').addEventListener('click', async () => {
  try { await api('/api/logout', { method: 'POST' }); } catch {}
  showLogin();
});

/* ================= 视图切换 ================= */
$$('.side-nav a[data-view]').forEach(a => {
  a.addEventListener('click', e => {
    e.preventDefault();
    const view = a.dataset.view;
    if (view === 'editor' && a.id === 'navNewPost') resetEditor(); // 点侧栏「写文章」= 新建
    switchView(view);
  });
});
function switchView(name) {
  $$('.view').forEach(v => { v.hidden = v.id !== 'view-' + name; });
  $$('.side-nav a[data-view]').forEach(a => a.classList.toggle('active', a.dataset.view === name));
  if (name === 'dashboard') renderDashboard();
  if (name === 'posts') loadPostsTable();
  if (name === 'settings') loadSettings();
  if (name === 'subs') loadSubscribers();
}

/* ================= 订阅管理 ================= */
async function loadSubscribers() {
  try {
    const data = await api('/api/subscribers');
    $('#subsCount').textContent = data.count || 0;
    const tbody = $('#subsTable tbody');
    if (!data.list || !data.list.length) {
      tbody.innerHTML = '<tr><td colspan="3" class="empty">还没有人订阅，分享你的博客让更多人订阅吧 ✉️</td></tr>';
      return;
    }
    tbody.innerHTML = data.list.map(s => \`
      <tr>
        <td>\${escapeHtml(s.email)}</td>
        <td>\${fmtDate(s.createdAt)}</td>
        <td class="td-actions"><button class="btn-danger-link js-del-sub" data-email="\${escapeHtml(s.email)}">删除</button></td>
      </tr>\`).join('');
    $$('#subsTable .js-del-sub').forEach(b => b.addEventListener('click', () => deleteSubscriber(b.dataset.email)));
  } catch (e) { toast(e.message); }
}
async function deleteSubscriber(email) {
  if (!confirm('确定删除订阅 ' + email + ' 吗？')) return;
  try {
    await api('/api/subscribers', { method: 'DELETE', body: JSON.stringify({ email }) });
    toast('已删除');
    loadSubscribers();
  } catch (e) { toast(e.message); }
}
$('#btnExportSubs').addEventListener('click', async () => {
  try {
    const data = await api('/api/subscribers');
    if (!data.list || !data.list.length) { toast('还没有订阅数据'); return; }
    const rows = [['邮箱', '订阅时间']].concat(data.list.map(s => [s.email, new Date(s.createdAt).toLocaleString()]));
    const csv = rows.map(r => r.map(c => '"' + String(c).replace(/"/g, '""') + '"').join(',')).join('\\n');
    const blob = new Blob(['﻿' + csv], { type: 'text/csv;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = 'subscribers.csv';
    document.body.appendChild(a); a.click(); a.remove();
    URL.revokeObjectURL(url);
  } catch (e) { toast(e.message); }
});

/* ================= 仪表盘 ================= */
async function renderDashboard() {
  try {
    const list = await api('/api/posts?all=1');
    const published = list.filter(p => p.status === 'published');
    $('#statTotal').textContent = list.length;
    $('#statPublished').textContent = published.length;
    $('#statDraft').textContent = list.length - published.length;
    $('#statViews').textContent = list.reduce((s, p) => s + (p.views || 0), 0);
    const recent = list.slice(0, 5);
    $('#recentTable').innerHTML = recent.length ? \`
      <thead><tr><th>标题</th><th>状态</th><th>阅读</th><th>更新时间</th></tr></thead>
      <tbody>\${recent.map(p => \`
        <tr>
          <td class="td-title"><a href="#" class="js-edit" data-id="\${p.id}">\${escapeHtml(p.title)}</a></td>
          <td><span class="status-pill \${p.status}">\${p.status === 'published' ? '已发布' : '草稿'}</span></td>
          <td>\${p.views || 0}</td>
          <td>\${fmtDate(p.updatedAt)}</td>
        </tr>\`).join('')}
      </tbody>\` : '<tbody><tr><td class="empty">暂无文章</td></tr></tbody>';
    $$('#recentTable .js-edit').forEach(a =>
      a.addEventListener('click', e => { e.preventDefault(); startEdit(a.dataset.id); }));
  } catch (e) { toast(e.message); }
}
function escapeHtml(s) {
  return String(s == null ? '' : s)
    .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
}

/* ================= 文章列表 ================= */
async function loadPostsTable() {
  try {
    const list = await api('/api/posts?all=1');
    $('#postsTable').innerHTML = list.length ? \`
      <thead><tr><th>标题</th><th>置顶</th><th>状态</th><th>标签</th><th>阅读</th><th>更新时间</th><th>操作</th></tr></thead>
      <tbody>\${list.map(p => \`
        <tr class="\${p.pinned ? 'row-pinned' : ''}">
          <td class="td-title"><a href="#" class="js-edit" data-id="\${p.id}">\${p.pinned ? '📌 ' : ''}\${escapeHtml(p.title)}</a></td>
          <td><button class="pin-toggle \${p.pinned ? 'on' : ''}" data-id="\${p.id}" title="切换置顶">\${p.pinned ? '已置顶' : '置顶'}</button></td>
          <td><span class="status-pill \${p.status}">\${p.status === 'published' ? '已发布' : '草稿'}</span></td>
          <td>\${(p.tags || []).map(t => \`<span class="tag">\${escapeHtml(t)}</span>\`).join(' ') || '—'}</td>
          <td>\${p.views || 0}</td>
          <td>\${fmtDate(p.updatedAt)}</td>
          <td class="td-actions">
            <button class="btn-danger-link js-toggle" data-id="\${p.id}" data-next="\${p.status === 'published' ? 'draft' : 'published'}">
              \${p.status === 'published' ? '下架' : '发布'}
            </button>
            <button class="btn-danger-link js-edit" data-id="\${p.id}" style="color:var(--primary)">编辑</button>
            <button class="btn-danger-link js-del" data-id="\${p.id}">删除</button>
          </td>
        </tr>\`).join('')}
      </tbody>\` : '<tbody><tr><td class="empty">还没有文章，点击右上角「新建文章」开始创作 ✍️</td></tr></tbody>';

    $$('#postsTable .js-edit').forEach(b => b.addEventListener('click', () => startEdit(b.dataset.id)));
    $$('#postsTable .js-toggle').forEach(b => b.addEventListener('click', () => togglePost(b.dataset.id, b.dataset.next)));
    $$('#postsTable .js-del').forEach(b => b.addEventListener('click', () => deletePost(b.dataset.id)));
    $$('#postsTable .pin-toggle').forEach(b => b.addEventListener('click', () => togglePin(b.dataset.id)));
  } catch (e) { toast(e.message); }
}

async function togglePost(id, next) {
  try {
    const list = await api('/api/posts?all=1');
    const p = list.find(x => x.id === id);
    if (!p) return;
    await api('/api/posts/' + id, {
      method: 'PUT',
      body: JSON.stringify({ ...p, status: next })
    });
    toast(next === 'published' ? '已发布 🎉' : '已转为草稿');
    loadPostsTable();
  } catch (e) { toast(e.message); }
}

async function togglePin(id) {
  try {
    const list = await api('/api/posts?all=1');
    const p = list.find(x => x.id === id);
    if (!p) return;
    await api('/api/posts/' + id, {
      method: 'PUT',
      body: JSON.stringify({ ...p, pinned: !p.pinned })
    });
    toast(p.pinned ? '已取消置顶' : '已置顶 📌，将排在所有文章最前');
    loadPostsTable();
  } catch (e) { toast(e.message); }
}

async function deletePost(id) {
  const list = await api('/api/posts?all=1').catch(() => []);
  const p = list.find(x => x.id === id);
  if (!confirm(\`确定删除文章《\${p ? p.title : id}》？此操作不可恢复。\`)) return;
  try {
    await api('/api/posts/' + id, { method: 'DELETE' });
    toast('已删除');
    loadPostsTable();
  } catch (e) { toast(e.message); }
}

/* ================= 编辑器：载入 / 重置 / 保存 ================= */
const editor = $('#editor');

function resetEditor() {
  editingId = null;
  $('#fTitle').value = '';
  $('#fSummary').value = '';
  $('#fCover').value = '';
  $('#fTags').value = '';
  $('#fStatus').value = 'published';
  editor.innerHTML = '';
  $('#editorMode').textContent = '写文章';
  $('#editingFlag').hidden = true;
  $('#saveMsg').textContent = '';
}

async function startEdit(id) {
  try {
    const list = await api('/api/posts?all=1');
    const p = list.find(x => x.id === id);
    if (!p) return toast('文章不存在');
    editingId = p.id;
    $('#fTitle').value = p.title;
    $('#fSummary').value = p.summary || '';
    $('#fCover').value = p.cover || '';
    $('#fTags').value = (p.tags || []).join(', ');
    $('#fStatus').value = p.status;
    editor.innerHTML = p.content;
    $('#editorMode').textContent = '编辑文章';
    $('#editingFlag').hidden = false;
    switchView('editor');
  } catch (e) { toast(e.message); }
}

$('#btnNewPost').addEventListener('click', () => { resetEditor(); switchView('editor'); });

function collectPost() {
  const title = $('#fTitle').value.trim();
  const content = editor.innerHTML;
  if (!title) { toast('请填写文章标题'); return null; }
  if (!stripHtml(content) && !/<img\\s/i.test(content)) { toast('正文内容不能为空'); return null; }
  return {
    title,
    summary: $('#fSummary').value.trim(),
    cover: $('#fCover').value.trim(),
    tags: $('#fTags').value,
    status: $('#fStatus').value,
    content
  };
}

async function savePost(openPreview = false) {
  const body = collectPost();
  if (!body) return null;
  const btn = $('#btnSave');
  btn.disabled = true;
  btn.textContent = '保存中…';
  try {
    const p = editingId
      ? await api('/api/posts/' + editingId, { method: 'PUT', body: JSON.stringify(body) })
      : await api('/api/posts', { method: 'POST', body: JSON.stringify(body) });
    editingId = p.id;
    $('#editorMode').textContent = '编辑文章';
    $('#editingFlag').hidden = false;
    $('#saveMsg').textContent = \`已保存 · \${fmtDate(p.updatedAt)}\`;
    toast(openPreview ? '保存成功，正在打开预览…' : '保存成功 ✅');
    if (openPreview) window.open('/post.html?id=' + encodeURIComponent(p.id), '_blank');
    return p;
  } catch (e) {
    toast(e.message);
    return null;
  } finally {
    btn.disabled = false;
    btn.textContent = '💾 保存文章';
  }
}
$('#btnSave').addEventListener('click', () => savePost(false));
$('#btnPreview').addEventListener('click', () => savePost(true));

/* 封面上传 */
$('#btnCoverUpload').addEventListener('click', () => $('#fCoverFile').click());
$('#fCoverFile').addEventListener('change', async e => {
  const file = e.target.files[0];
  if (!file) return;
  try {
    const url = await uploadImage(file, st => toast(st));
    $('#fCover').value = url;
    toast('封面上传成功');
  } catch (err) { toast('上传失败：' + err.message); }
  e.target.value = '';
});

/* ================= 富文本编辑器核心 ================= */
/* 记录选区：工具栏按钮 mousedown 已 preventDefault，双保险再存一份 */
function saveSelection() {
  const sel = window.getSelection();
  if (sel.rangeCount && editor.contains(sel.anchorNode)) {
    savedRange = sel.getRangeAt(0).cloneRange();
  }
}
editor.addEventListener('keyup', saveSelection);
editor.addEventListener('mouseup', saveSelection);
editor.addEventListener('focus', saveSelection);

function restoreSelection() {
  if (savedRange) {
    const sel = window.getSelection();
    sel.removeAllRanges();
    sel.addRange(savedRange);
  }
}

/* 工具栏按钮：mousedown 阻止抢焦点，避免点击后编辑器失焦导致选区/光标丢失。
   覆盖普通命令按钮、自定义按钮（插入链接/图片等），以及取色器；不影响 select 下拉。 */
$$('#toolbar button.tb-btn, #toolbar .color-dot, #toolbar label.tb-btn').forEach(el => {
  el.addEventListener('mousedown', e => e.preventDefault());
});

function exec(cmd, val) {
  editor.focus();
  restoreSelection();
  try { document.execCommand('styleWithCSS', false, true); } catch {}
  document.execCommand(cmd, false, val);
  saveSelection();
  editor.focus();
}

$$('#toolbar .tb-btn[data-cmd]').forEach(btn => {
  btn.addEventListener('click', () => exec(btn.dataset.cmd));
});

/* 段落格式 */
$('#blockType').addEventListener('change', e => {
  const v = e.target.value;
  if (v) exec('formatBlock', '<' + v + '>');
  e.target.selectedIndex = 0;
});

/* 像素级字号：把选中内容包裹进 <span style="font-size: px">，稳定支持各浏览器与移动端。
   支持两种用法：
   1) 先选中文字再选字号 → 直接套用（传统模式）
   2) 光标在空处先选字号 → 进入「预置模式」，之后打字自动套用该字号（无需先全选） */
let pendingFontSize = null;   // 预置字号（光标处打字时自动套用）
let fontSizeBadge = null;     // 工具栏上的「已预置 Npx」提示

function setFontSize(px) {
  editor.focus();
  restoreSelection();
  const sel = window.getSelection();
  if (!sel.rangeCount) { startPendingFontSize(px); return; }
  const range = sel.getRangeAt(0);
  if (!editor.contains(range.commonAncestorContainer)) { startPendingFontSize(px); return; }
  if (range.collapsed) {
    // 光标（无选区）：进入预置模式，而不是报错
    startPendingFontSize(px);
    return;
  }
  try {
    const span = document.createElement('span');
    span.style.fontSize = px + 'px';
    span.appendChild(range.extractContents());
    range.insertNode(span);
    const r = document.createRange();
    r.selectNodeContents(span);
    sel.removeAllRanges();
    sel.addRange(r);
    savedRange = r.cloneRange();
    clearPendingFontSize();
  } catch (e) {
    console.error(e);
    toast('设置字号失败，请重新选择文字');
  }
}

function startPendingFontSize(px) {
  pendingFontSize = px;
  if (!fontSizeBadge) {
    fontSizeBadge = document.createElement('span');
    fontSizeBadge.className = 'font-size-badge';
    $('#toolbar').appendChild(fontSizeBadge);
  }
  fontSizeBadge.textContent = \`✎ 即将输入 \${px}px 字号（直接打字即可）\`;
  fontSizeBadge.hidden = false;
  toast(\`已预置 \${px}px 字号，现在开始打字就会套用\`);
}

function clearPendingFontSize() {
  pendingFontSize = null;
  if (fontSizeBadge) fontSizeBadge.hidden = true;
}

// 预置模式下：捕获下一次可见文字输入，把该文本节点整体包成对应字号的 span
editor.addEventListener('input', e => {
  if (pendingFontSize == null) return;
  const sel = window.getSelection();
  if (!sel.rangeCount) return;
  const range = sel.getRangeAt(0);
  if (!editor.contains(range.commonAncestorContainer)) return;
  // 找到光标所在的文本节点（已输入可见内容）
  let node = range.startContainer;
  if (node.nodeType !== 3) return;
  if (!node.textContent.trim()) return; // 还没真正输入可见内容
  // 如果该文本节点已经在一个 fontSize span 内，跳过（避免重复包裹）
  if (node.parentElement && node.parentElement.style &&
      node.parentElement.style.fontSize) return;
  try {
    const span = document.createElement('span');
    span.style.fontSize = pendingFontSize + 'px';
    node.parentNode.insertBefore(span, node);
    span.appendChild(node);
    // 光标移到 span 内文本末尾
    const r = document.createRange();
    r.setStart(node, node.textContent.length);
    r.collapse(true);
    sel.removeAllRanges();
    sel.addRange(r);
    savedRange = r.cloneRange();
    clearPendingFontSize();
  } catch (err) {
    console.error('预置字号包裹失败', err);
  }
});

$('#fontSizeSel').addEventListener('change', e => {
  const v = e.target.value;
  if (!v) return;
  if (v === 'clear') {
    clearPendingFontSize();
    exec('removeFormat');
  } else {
    setFontSize(Number(v));
  }
  e.target.selectedIndex = 0;
});

/* 文字颜色 / 荧光高亮：execCommand + 后处理，兼容移动端 */
function setForeColor(color) {
  editor.focus();
  restoreSelection();
  const sel = window.getSelection();
  if (!sel.rangeCount) return;
  const range = sel.getRangeAt(0);
  if (range.collapsed) { toast('请先选中要设置颜色的文字'); return; }
  try {
    document.execCommand('styleWithCSS', false, false);
    document.execCommand('foreColor', false, color);
    editor.querySelectorAll('font[color]').forEach(f => {
      const span = document.createElement('span');
      span.style.color = f.getAttribute('color');
      while (f.firstChild) span.appendChild(f.firstChild);
      f.parentNode.replaceChild(span, f);
    });
    $('#forePreview').style.color = color;
    saveSelection();
  } catch (e) { toast('设置颜色失败'); }
}
function setHiliteColor(color) {
  editor.focus();
  restoreSelection();
  const sel = window.getSelection();
  if (!sel.rangeCount) return;
  const range = sel.getRangeAt(0);
  if (range.collapsed) { toast('请先选中要高亮的文字'); return; }
  try {
    document.execCommand('styleWithCSS', false, true);
    document.execCommand('hiliteColor', false, color);
    saveSelection();
  } catch (e) { toast('设置高亮失败'); }
}
$('#foreColorInput').addEventListener('input', e => setForeColor(e.target.value));
$('#hiliteColorInput').addEventListener('input', e => setHiliteColor(e.target.value));
$$('#forePalette .color-dot').forEach(btn => btn.addEventListener('click', () => setForeColor(btn.dataset.color)));
$$('#hilitePalette .color-dot').forEach(btn => btn.addEventListener('click', () => setHiliteColor(btn.dataset.color)));

/* ================= 插入链接 ================= */
const linkModal = $('#linkModal');
$('#btnInsertLink').addEventListener('click', () => {
  saveSelection();
  const sel = window.getSelection();
  const selected = sel.toString();
  $('#linkText').value = selected;
  $('#linkUrl').value = 'https://';
  linkModal.hidden = false;
  $('#linkUrl').focus();
  $('#linkUrl').select();
});
$('#linkConfirm').addEventListener('click', () => {
  let url = $('#linkUrl').value.trim();
  const text = $('#linkText').value.trim();
  if (!url) { toast('请填写链接地址'); return; }
  if (!/^(https?:|mailto:|tel:|\\/|#)/i.test(url)) url = 'https://' + url;

  // 关键：先捕获已保存的选区再聚焦。打开弹窗时编辑器已失焦，
  // editor.focus() 会触发 focus 事件并覆盖 savedRange；若先 focus 再读取选区，
  // 光标会被重置到编辑器开头，链接就插到错误位置（所谓「自动置顶」）。
  let range = null;
  if (savedRange && editor.contains(savedRange.startContainer)) {
    range = savedRange.cloneRange();
  }
  const sel = window.getSelection();
  editor.focus();

  if (!range) {
    toast('请先在编辑器中定位光标');
    linkModal.hidden = true;
    return;
  }

  const blank = $('#linkBlank').checked;
  const a = document.createElement('a');
  a.setAttribute('href', escapeAttr(url));
  if (blank) { a.target = '_blank'; a.rel = 'noopener noreferrer'; }

  if (!range.collapsed) {
    // 有选中文字：优先使用弹窗里的链接文本；没填就用原文
    a.textContent = text || range.toString();
    range.deleteContents();
  } else {
    // 只有光标：在光标处插入链接
    a.textContent = text || url.replace(/^https?:\\/\\//, '');
  }

  // 用 Range.insertNode 精确插入到光标/选区位置
  range.insertNode(a);

  // 把光标移到链接之后，避免后续输入被包进链接
  const after = document.createRange();
  after.setStartAfter(a);
  after.setEndAfter(a);
  sel.removeAllRanges();
  sel.addRange(after);
  savedRange = after.cloneRange();

  linkModal.hidden = true;
});

/* ================= 插入图片 ================= */
const imageModal = $('#imageModal');
let imgTab = 'upload';
$$('.tab').forEach(t => t.addEventListener('click', () => {
  imgTab = t.dataset.tab;
  $$('.tab').forEach(x => x.classList.toggle('active', x === t));
  $('#tab-upload').hidden = imgTab !== 'upload';
  $('#tab-url').hidden = imgTab !== 'url';
}));

$('#btnInsertImage').addEventListener('click', () => {
  saveSelection();
  $('#uploadStatus').textContent = '';
  $('#imageUrl').value = '';
  imageModal.hidden = false;
});

/* 上传图片（后台 API），fn 用于展示进度提示 */
async function uploadImage(file, notify) {
  if (!/^image\\//.test(file.type)) throw new Error('只能上传图片文件');
  if (file.size > 10 * 1024 * 1024) throw new Error('图片不能超过 10MB');
  notify && notify('上传中…');
  const fd = new FormData();
  fd.append('image', file);
  const res = await fetchWithTimeout('/api/upload', { method: 'POST', headers: authHeader(), body: fd }, 60000);
  const data = await res.json().catch(() => ({}));
  if (res.status === 401) { showLogin(); throw new Error('请先登录'); }
  if (!res.ok) throw new Error(data.error || '上传失败');
  return data.url;
}

$('#uploadArea').addEventListener('click', () => $('#imageFile').click());
$('#imageFile').addEventListener('change', async e => {
  const file = e.target.files[0];
  e.target.value = '';
  if (!file) return;
  const st = $('#uploadStatus');
  try {
    st.textContent = '⏳ 上传中…';
    const url = await uploadImage(file);
    st.textContent = '✅ 上传成功';
    insertImageAtSelection(url);
    imageModal.hidden = true;
  } catch (err) {
    st.textContent = '❌ ' + err.message;
  }
});

$('#imageConfirm').addEventListener('click', () => {
  if (imgTab === 'url') {
    let url = $('#imageUrl').value.trim();
    if (!url) { toast('请填写图片地址'); return; }
    if (!/^(https?:|data:image|\\/)/i.test(url)) url = 'https://' + url;
    insertImageAtSelection(url);
    imageModal.hidden = true;
  } else {
    $('#imageFile').click();
  }
});

function insertImageAtSelection(url) {
  // 先捕获选区，避免 editor.focus() 触发 focus 事件覆盖 savedRange，导致图片插错位置
  let range = null;
  if (savedRange && editor.contains(savedRange.startContainer)) {
    range = savedRange.cloneRange();
  }
  const sel = window.getSelection();
  editor.focus();
  if (!range) { toast('请先在编辑器中定位光标'); return; }

  const img = document.createElement('img');
  img.src = url;
  img.alt = '';
  if (!range.collapsed) range.deleteContents();
  range.insertNode(img);

  const after = document.createRange();
  after.setStartAfter(img);
  after.setEndAfter(img);
  sel.removeAllRanges();
  sel.addRange(after);
  savedRange = after.cloneRange();
}

/* 直接粘贴图片 → 自动上传并插入 */
editor.addEventListener('paste', async e => {
  const items = e.clipboardData && e.clipboardData.items;
  if (!items) return;
  for (const item of items) {
    if (item.type && item.type.startsWith('image/')) {
      e.preventDefault();
      const file = item.getAsFile();
      if (!file) return;
      saveSelection();
      try {
        const url = await uploadImage(file);
        insertImageAtSelection(url);
        toast('图片已上传并插入 ✅');
      } catch (err) {
        toast('粘贴上传失败：' + err.message);
      }
      return;
    }
  }
});

/* 弹窗通用关闭 */
$$('.modal [data-close]').forEach(b => b.addEventListener('click', () => {
  linkModal.hidden = true;
  imageModal.hidden = true;
}));
$$('.modal-overlay').forEach(ov => ov.addEventListener('mousedown', e => {
  if (e.target === ov) { ov.hidden = true; }
}));
document.addEventListener('keydown', e => {
  if (e.key === 'Escape') { linkModal.hidden = true; imageModal.hidden = true; }
});

function escapeAttr(s) { return escapeHtml(s); }

/* ================= 站点设置 ================= */
const CONTACT_TYPES = [
  ['email', '✉️ 邮箱'],
  ['phone', '📱 手机/电话'],
  ['wechat', '💬 微信'],
  ['qq', '🐧 QQ'],
  ['weibo', '🔴 微博'],
  ['bilibili', '📺 哔哩哔哩'],
  ['douyin', '🎵 抖音'],
  ['xiaohongshu', '📕 小红书'],
  ['zhihu', '📖 知乎'],
  ['jike', '🌐 即刻'],
  ['github', '🐙 GitHub'],
  ['twitter', '🐦 X/Twitter'],
  ['telegram', '✈️ Telegram'],
  ['youtube', '▶️ YouTube'],
  ['instagram', '📷 Instagram'],
  ['facebook', '📘 Facebook'],
  ['discord', '🟣 Discord'],
  ['tiktok', '🎶 TikTok'],
  ['netease', '☁️ 网易云音乐'],
  ['steam', '🎮 Steam'],
  ['website', '🌐 个人网站'],
  ['link', '🔗 其他链接']
];

function contactRowHtml(c = {}) {
  return \`<div class="row-grid contact-row">
    <select class="c-type">\${CONTACT_TYPES.map(([v, l]) =>
      \`<option value="\${v}" \${c.type === v ? 'selected' : ''}>\${l}</option>\`).join('')}</select>
    <input class="c-label" placeholder="显示名称" value="\${escapeHtml(c.label || '')}">
    <input class="c-value" placeholder="内容（邮箱/账号/号码）" value="\${escapeHtml(c.value || '')}">
    <input class="c-link" placeholder="跳转链接，可空（https://… 或 mailto:…）" value="\${escapeHtml(c.link || '')}">
    <button class="row-del" title="删除此行">✕</button>
  </div>\`;
}
function linkRowHtml(l = {}) {
  return \`<div class="row-grid link-row">
    <input class="l-name" placeholder="网站名称" value="\${escapeHtml(l.name || '')}">
    <input class="l-url" placeholder="https://example.com" value="\${escapeHtml(l.url || '')}">
    <input class="l-desc" placeholder="一句话描述" value="\${escapeHtml(l.desc || '')}">
    <button class="row-del" title="删除此行">✕</button>
  </div>\`;
}
function sponsorRowHtml(l = {}) {
  return \`<div class="row-grid sponsor-row">
    <input class="l-name" placeholder="赞助方式/平台名称" value="\${escapeHtml(l.name || '')}">
    <div class="sponsor-img-wrap">
      <img class="sponsor-preview" src="\${escapeHtml(l.image || '')}" alt="" \${l.image ? '' : 'hidden'}>
      <span class="sponsor-placeholder" \${l.image ? 'hidden' : ''}>🖼️</span>
      <input type="file" accept="image/*" hidden class="sponsor-file">
      <button type="button" class="btn btn-ghost btn-sm sponsor-upload">上传图片</button>
      <input type="hidden" class="l-image" value="\${escapeHtml(l.image || '')}">
    </div>
    <input class="l-url" placeholder="跳转链接（可空，留空则点击复制账号）" value="\${escapeHtml(l.url || '')}">
    <input class="l-desc" placeholder="一句话描述" value="\${escapeHtml(l.desc || '')}">
    <button class="row-del" title="删除此行">✕</button>
  </div>\`;
}

async function loadSettings() {
  try {
    const site = await api('/api/site');
    $('#sSiteName').value = site.siteName || '';
    $('#sOwnerName').value = site.ownerName || '';
    $('#sAvatar').value = site.avatar || '';
    $('#sBio').value = site.bio || '';
    $('#contactRows').innerHTML = (site.contacts || []).map(contactRowHtml).join('') || contactRowHtml();
    $('#linkRows').innerHTML = (site.links || []).map(linkRowHtml).join('') || linkRowHtml();
    $('#sponsorRows').innerHTML = (site.sponsorLinks || []).map(sponsorRowHtml).join('') || sponsorRowHtml();
  } catch (e) { toast(e.message); }
}

$('#btnAddContact').addEventListener('click', () =>
  $('#contactRows').insertAdjacentHTML('beforeend', contactRowHtml()));
$('#btnAddLink').addEventListener('click', () =>
  $('#linkRows').insertAdjacentHTML('beforeend', linkRowHtml()));
$('#btnAddSponsor').addEventListener('click', () =>
  $('#sponsorRows').insertAdjacentHTML('beforeend', sponsorRowHtml()));
document.addEventListener('click', e => {
  if (e.target.classList && e.target.classList.contains('row-del')) {
    e.target.closest('.row-grid').remove();
  }
});

$('#btnSaveSite').addEventListener('click', async () => {
  const contacts = $$('#contactRows .contact-row').map(row => ({
    type: row.querySelector('.c-type').value,
    label: row.querySelector('.c-label').value.trim(),
    value: row.querySelector('.c-value').value.trim(),
    link: row.querySelector('.c-link').value.trim()
  })).filter(c => c.value || c.link);
  const links = $$('#linkRows .link-row').map(row => ({
    name: row.querySelector('.l-name').value.trim(),
    url: row.querySelector('.l-url').value.trim(),
    desc: row.querySelector('.l-desc').value.trim()
  })).filter(l => l.name && l.url);
  const sponsorLinks = $$('#sponsorRows .sponsor-row').map(row => ({
    name: row.querySelector('.l-name').value.trim(),
    url: row.querySelector('.l-url').value.trim(),
    desc: row.querySelector('.l-desc').value.trim(),
    image: row.querySelector('.l-image').value.trim()
  })).filter(l => l.name || l.image); // 修复：赞助可只填名称/只传图片，url 允许为空
  try {
    await api('/api/site', {
      method: 'PUT',
      body: JSON.stringify({
        siteName: $('#sSiteName').value.trim(),
        ownerName: $('#sOwnerName').value.trim(),
        avatar: $('#sAvatar').value.trim(),
        bio: $('#sBio').value.trim(),
        contacts, links, sponsorLinks
      })
    });
    toast('站点设置已保存 ✅（刷新前台首页生效）');
  } catch (e) { toast(e.message); }
});

/* 头像上传 */
$('#btnAvatarUpload').addEventListener('click', () => $('#sAvatarFile').click());
$('#sAvatarFile').addEventListener('change', async e => {
  const file = e.target.files[0];
  if (!file) return;
  try {
    const url = await uploadImage(file, st => toast(st));
    $('#sAvatar').value = url;
    toast('头像上传成功，记得保存设置');
  } catch (err) { toast('上传失败：' + err.message); }
  e.target.value = '';
});

/* 赞助图片上传（事件委托） */
document.addEventListener('click', e => {
  if (e.target.classList.contains('sponsor-upload')) {
    e.preventDefault();
    e.target.closest('.sponsor-row').querySelector('.sponsor-file').click();
  }
});
document.addEventListener('change', e => {
  if (!e.target.classList.contains('sponsor-file')) return;
  const file = e.target.files[0];
  if (!file) return;
  const row = e.target.closest('.sponsor-row');
  const preview = row.querySelector('.sponsor-preview');
  const placeholder = row.querySelector('.sponsor-placeholder');
  const input = row.querySelector('.l-image');
  uploadImage(file, st => toast(st)).then(url => {
    input.value = url;
    preview.src = url;
    preview.hidden = false;
    placeholder.hidden = true;
    toast('赞助图片上传成功');
  }).catch(err => toast('上传失败：' + err.message));
  e.target.value = '';
});

/* 修改密码 */
$('#btnChangePw').addEventListener('click', async () => {
  const pwOld = $('#pwOld').value;
  const pwNew = $('#pwNew').value;
  const pwNew2 = $('#pwNew2').value;
  if (!pwOld || !pwNew) { toast('请填写完整'); return; }
  if (pwNew !== pwNew2) { toast('两次输入的新密码不一致'); return; }
  if (pwNew.length < 6) { toast('新密码至少 6 位'); return; }
  try {
    await api('/api/change-password', {
      method: 'POST',
      body: JSON.stringify({ oldPassword: pwOld, newPassword: pwNew })
    });
    $('#pwOld').value = $('#pwNew').value = $('#pwNew2').value = '';
    toast('密码修改成功 ✅ 下次登录请使用新密码');
  } catch (e) { toast(e.message); }
});

/* ================= 管理初始化 & 启动 ================= */
function initAdmin() {
  // 编辑器初始内容提示
  if (!editor.innerHTML.trim()) {
    editor.innerHTML = '<p><br></p>';
  }
}

/* 启动：有 token 则校验并直接进入后台 */
(async function boot() {
  try {
    if (TOKEN) {
      await api('/api/posts?all=1');
      showAdmin();
    } else {
      showLogin();
    }
  } catch (err) {
    console.error('boot failed:', err);
    showLogin();
    $('#loginErr').textContent = '自动登录失败，请手动登录：' + (err && err.message ? err.message : '会话已过期');
  }
})();

</script>
</body>
</html>
`,
  "/post": `<!DOCTYPE html>
<html lang="zh-CN">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>文章 - 个人博客</title>
  <link rel="icon" href="data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'><text y='0.9em' font-size='90'>✦</text></svg>">
  <link rel="stylesheet" href="/css/style.css?v=11">
</head>
<body>
  <header class="topbar">
    <div class="topbar-inner container">
      <a href="/" class="logo"><span class="logo-mark">✦</span><span id="navSiteName">个人博客</span></a>
      <nav class="nav">
        <a href="/">首页</a>
        <a href="/admin" class="admin-link">后台管理</a>
      </nav>
      <div class="theme-picker" id="themePicker" title="切换主题">
        <span id="themeIcon">🌙</span>
        <span id="themeLabel">深色</span>
      </div>
    </div>
  </header>

  <main class="page-main container">
    <a href="/" class="back-link">← 返回首页</a>
    <article class="post-full">
      <h1 id="postTitle">加载中…</h1>
      <div class="post-meta-row" id="postMeta"></div>
      <div class="post-share" id="postShare" hidden>
        <span>分享给朋友：</span>
        <button class="share-btn" data-action="copy" title="复制短链接">📋 复制短链接</button>
        <button class="share-btn" id="shareSystemBtn" data-action="share" title="系统分享">📤 系统分享</button>
      </div>
      <div class="post-content" id="postContent"></div>
    </article>
    <nav class="post-nav" id="postNav"></nav>
  </main>

  <footer class="footer">
    <p>© <span id="footerYear">2026</span> <span id="footerSiteName">个人博客</span> · 每一次记录都算数 ✦</p>
  </footer>

  <div id="toast"></div>
  <script src="/js/post.js?v=11"></script>
</body>
</html>
`,
  "/post.html": `<!DOCTYPE html>
<html lang="zh-CN">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>文章 - 个人博客</title>
  <link rel="icon" href="data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'><text y='0.9em' font-size='90'>✦</text></svg>">
  <link rel="stylesheet" href="/css/style.css?v=11">
</head>
<body>
  <header class="topbar">
    <div class="topbar-inner container">
      <a href="/" class="logo"><span class="logo-mark">✦</span><span id="navSiteName">个人博客</span></a>
      <nav class="nav">
        <a href="/">首页</a>
        <a href="/admin" class="admin-link">后台管理</a>
      </nav>
      <div class="theme-picker" id="themePicker" title="切换主题">
        <span id="themeIcon">🌙</span>
        <span id="themeLabel">深色</span>
      </div>
    </div>
  </header>

  <main class="page-main container">
    <a href="/" class="back-link">← 返回首页</a>
    <article class="post-full">
      <h1 id="postTitle">加载中…</h1>
      <div class="post-meta-row" id="postMeta"></div>
      <div class="post-share" id="postShare" hidden>
        <span>分享给朋友：</span>
        <button class="share-btn" data-action="copy" title="复制短链接">📋 复制短链接</button>
        <button class="share-btn" id="shareSystemBtn" data-action="share" title="系统分享">📤 系统分享</button>
      </div>
      <div class="post-content" id="postContent"></div>
    </article>
    <nav class="post-nav" id="postNav"></nav>
  </main>

  <footer class="footer">
    <p>© <span id="footerYear">2026</span> <span id="footerSiteName">个人博客</span> · 每一次记录都算数 ✦</p>
  </footer>

  <div id="toast"></div>
  <script src="/js/post.js?v=11"></script>
</body>
</html>
`,
  "/diag": `<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>博客诊断工具</title>
<style>
  body { font-family: -apple-system, sans-serif; max-width: 640px; margin: 20px auto; padding: 0 16px; color: #222; }
  h1 { font-size: 20px; }
  .card { background: #f5f5f7; border-radius: 12px; padding: 16px; margin: 12px 0; white-space: pre-wrap; font-family: monospace; font-size: 13px; line-height: 1.6; }
  button { background: #2563eb; color: #fff; border: 0; padding: 12px 20px; border-radius: 10px; font-size: 15px; }
  .ok { color: #16a34a; } .err { color: #dc2626; }
</style>
</head>
<body>
<h1>博客后台登录诊断</h1>
<p>点击下方按钮，测试登录接口是否正常响应：</p>
<button onclick="runTest()">开始诊断</button>
<div id="out" class="card">点击上方按钮开始...</div>

<script>
const out = document.getElementById('out');
function log(msg, cls) {
  const div = document.createElement('div');
  if (cls) div.className = cls;
  div.textContent = msg;
  out.appendChild(div);
}
async function runTest() {
  out.innerHTML = '';
  log('浏览器信息: ' + navigator.userAgent);
  log('当前页面 URL: ' + location.href);
  log('fetch 支持: ' + (typeof fetch !== 'undefined' ? '是' : '否'));
  log('---');
  log('正在测试 /api/login (POST)...');
  const t0 = Date.now();
  try {
    const ctrl = new AbortController();
    const timer = setTimeout(() => ctrl.abort(), 15000);
    const res = await fetch('/api/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ username: 'admin', password: 'admin123' }),
      signal: ctrl.signal
    });
    clearTimeout(timer);
    const ms = Date.now() - t0;
    const text = await res.text();
    log(\`响应状态: \${res.status} (耗时 \${ms}ms)\`, res.ok ? 'ok' : 'err');
    log('响应内容: ' + text);
    if (res.ok) log('✅ 登录接口正常！问题可能在前端代码或缓存。', 'ok');
    else log('❌ 登录接口返回错误，请截图发给开发者。', 'err');
  } catch (e) {
    const ms = Date.now() - t0;
    log(\`❌ 请求失败 (\${ms}ms): \${e.name} - \${e.message}\`, 'err');
    log('如果是 AbortError 说明网络超时（VPN/弱网问题）', 'err');
    log('如果是 TypeError 说明网络层被拦截', 'err');
  }
}
</script>
</body>
</html>
`,
  "/diag.html": `<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>博客诊断工具</title>
<style>
  body { font-family: -apple-system, sans-serif; max-width: 640px; margin: 20px auto; padding: 0 16px; color: #222; }
  h1 { font-size: 20px; }
  .card { background: #f5f5f7; border-radius: 12px; padding: 16px; margin: 12px 0; white-space: pre-wrap; font-family: monospace; font-size: 13px; line-height: 1.6; }
  button { background: #2563eb; color: #fff; border: 0; padding: 12px 20px; border-radius: 10px; font-size: 15px; }
  .ok { color: #16a34a; } .err { color: #dc2626; }
</style>
</head>
<body>
<h1>博客后台登录诊断</h1>
<p>点击下方按钮，测试登录接口是否正常响应：</p>
<button onclick="runTest()">开始诊断</button>
<div id="out" class="card">点击上方按钮开始...</div>

<script>
const out = document.getElementById('out');
function log(msg, cls) {
  const div = document.createElement('div');
  if (cls) div.className = cls;
  div.textContent = msg;
  out.appendChild(div);
}
async function runTest() {
  out.innerHTML = '';
  log('浏览器信息: ' + navigator.userAgent);
  log('当前页面 URL: ' + location.href);
  log('fetch 支持: ' + (typeof fetch !== 'undefined' ? '是' : '否'));
  log('---');
  log('正在测试 /api/login (POST)...');
  const t0 = Date.now();
  try {
    const ctrl = new AbortController();
    const timer = setTimeout(() => ctrl.abort(), 15000);
    const res = await fetch('/api/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ username: 'admin', password: 'admin123' }),
      signal: ctrl.signal
    });
    clearTimeout(timer);
    const ms = Date.now() - t0;
    const text = await res.text();
    log(\`响应状态: \${res.status} (耗时 \${ms}ms)\`, res.ok ? 'ok' : 'err');
    log('响应内容: ' + text);
    if (res.ok) log('✅ 登录接口正常！问题可能在前端代码或缓存。', 'ok');
    else log('❌ 登录接口返回错误，请截图发给开发者。', 'err');
  } catch (e) {
    const ms = Date.now() - t0;
    log(\`❌ 请求失败 (\${ms}ms): \${e.name} - \${e.message}\`, 'err');
    log('如果是 AbortError 说明网络超时（VPN/弱网问题）', 'err');
    log('如果是 TypeError 说明网络层被拦截', 'err');
  }
}
</script>
</body>
</html>
`
};
