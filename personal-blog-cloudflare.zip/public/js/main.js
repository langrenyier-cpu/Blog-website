/* ================= 工具 ================= */
const $ = s => document.querySelector(s);
const $$ = s => Array.from(document.querySelectorAll(s));

function esc(s) {
  return String(s == null ? '' : s)
    .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
}

let toastTimer = null;
function toast(msg) {
  const t = $('#toast');
  t.textContent = msg;
  t.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => t.classList.remove('show'), 2200);
}

function fmtDate(ts) {
  const d = new Date(ts);
  const p = n => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}`;
}

/* ================= 一键换肤（默认 / 深色 / 玻璃 / 科技 / 拟态玻璃） ================= */
const THEMES = [
  { id: 'light', icon: '☀️', label: '浅色' },
  { id: 'dark', icon: '🌙', label: '深色' },
  { id: 'glass', icon: '💎', label: '玻璃' },
  { id: 'tech', icon: '⚡', label: '科技' },
  { id: 'neumorph', icon: '🧊', label: '拟态玻璃' }
];
const WALLPAPER_THEMES = ['glass', 'neumorph']; // 这些主题下自动显示动漫壁纸
const themePicker = $('#themePicker');
const themeIcon = $('#themeIcon');
const themeLabel = $('#themeLabel');
function setAnimeWallpaper(show) {
  const bg = $('#animeBg');
  if (!bg) return;
  if (!show) { bg.classList.remove('show'); return; }
  // 已有壁纸则直接显示，没有则异步加载
  if (bg.style.backgroundImage) {
    bg.classList.add('show');
    return;
  }
  loadAnimeWallpaper();
}
async function loadAnimeWallpaper() {
  const bg = $('#animeBg');
  if (!bg) return;
  const img = new Image();
  img.onload = () => {
    bg.style.backgroundImage = `url('/api/wallpaper')`;
    bg.classList.add('show');
  };
  img.onerror = () => { bg.classList.remove('show'); };
  img.src = '/api/wallpaper';
}
function applyTheme(id) {
  const t = THEMES.find(x => x.id === id) || THEMES[0];
  document.documentElement.dataset.theme = id;
  themeIcon.textContent = t.icon;
  themeLabel.textContent = t.label;
  try { localStorage.setItem('theme', id); } catch {}
  setAnimeWallpaper(WALLPAPER_THEMES.includes(id));
}
function nextTheme() {
  const cur = document.documentElement.dataset.theme || 'light';
  const idx = THEMES.findIndex(t => t.id === cur);
  const next = THEMES[(idx + 1) % THEMES.length];
  applyTheme(next.id);
}
themePicker.addEventListener('click', nextTheme);
applyTheme(
  (localStorage.getItem('theme')) ||
  (matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light')
);

/* ================= 实时时钟与问候 ================= */
const WEEK = ['日', '一', '二', '三', '四', '五', '六'];
function greetingOf(h) {
  if (h < 5) return '夜深了，注意休息';
  if (h < 9) return '早上好';
  if (h < 12) return '上午好';
  if (h < 14) return '中午好';
  if (h < 18) return '下午好';
  if (h < 23) return '晚上好';
  return '夜深了';
}
function tick() {
  const now = new Date();
  $('#clockTime').textContent = now.toLocaleTimeString('zh-CN', { hour12: false });
  $('#clockDate').textContent =
    `${now.getFullYear()} 年 ${now.getMonth() + 1} 月 ${now.getDate()} 日 · 星期${WEEK[now.getDay()]}`;
  $('#greeting').textContent = greetingOf(now.getHours());
}
tick();
setInterval(tick, 1000);
$('#footerYear').textContent = new Date().getFullYear();

/* ================= 天气 + 地点 ================= */
/* WMO 天气代码 → [图标, 描述] */
const WMO = {
  0: ['☀️', '晴'], 1: ['🌤️', '基本晴'], 2: ['⛅', '多云'], 3: ['☁️', '阴'],
  45: ['🌫️', '雾'], 48: ['🌫️', '冻雾'],
  51: ['🌦️', '小毛毛雨'], 53: ['🌦️', '毛毛雨'], 55: ['🌧️', '浓毛毛雨'],
  56: ['🌧️', '冻毛毛雨'], 57: ['🌧️', '强冻毛毛雨'],
  61: ['🌦️', '小雨'], 63: ['🌧️', '中雨'], 65: ['🌧️', '大雨'],
  66: ['🌧️', '冻雨'], 67: ['🌧️', '强冻雨'],
  71: ['🌨️', '小雪'], 73: ['🌨️', '中雪'], 75: ['❄️', '大雪'], 77: ['🌨️', '雪粒'],
  80: ['🌦️', '小阵雨'], 81: ['🌧️', '阵雨'], 82: ['⛈️', '强阵雨'],
  85: ['🌨️', '小阵雪'], 86: ['❄️', '阵雪'],
  95: ['⛈️', '雷暴'], 96: ['⛈️', '雷暴伴冰雹'], 99: ['⛈️', '强雷暴伴冰雹']
};

async function getPosition() {
  // 1) 优先浏览器精确定位（localhost 下可用，需授权）
  try {
    const coords = await new Promise((resolve, reject) => {
      if (!navigator.geolocation) return reject(new Error('no geolocation'));
      navigator.geolocation.getCurrentPosition(
        p => resolve(p.coords),
        reject,
        { timeout: 4000, maximumAge: 10 * 60 * 1000 }
      );
    });
    if (coords) return { lat: coords.latitude, lon: coords.longitude, precise: true };
  } catch {}
  // 2) 退化：IP 粗略定位
  try {
    const r = await fetch('https://ipwho.is/');
    const d = await r.json();
    if (d && d.success) return { lat: d.latitude, lon: d.longitude, precise: false, city: d.city, region: d.region, country: d.country };
  } catch {}
  return null;
}

async function reverseGeocode(lat, lon) {
  try {
    const r = await fetch(`https://geocoding-api.open-meteo.com/v1/search?latitude=${lat}&longitude=${lon}&count=1&language=zh`);
    const d = await r.json();
    const it = d.results && d.results[0];
    if (it) {
      const parts = [it.name];
      if (it.admin1 && it.admin1 !== it.name) parts.push(it.admin1);
      return parts.join(' · ');
    }
  } catch {}
  return '';
}

async function loadWeather() {
  const set = (icon, temp, desc, loc) => {
    $('#weatherIcon').textContent = icon;
    $('#weatherTemp').textContent = temp;
    $('#weatherDesc').textContent = desc;
    $('#weatherLoc').textContent = loc;
  };
  try {
    const pos = await getPosition();
    if (!pos) throw new Error('无法定位');
    let city = '';
    if (pos.precise) {
      city = await reverseGeocode(pos.lat, pos.lon);
    } else {
      city = [pos.city, pos.region].filter(Boolean).join(' · ');
    }
    if (!city) city = `${pos.lat.toFixed(1)}, ${pos.lon.toFixed(1)}`;

    const r = await fetch(
      `https://api.open-meteo.com/v1/forecast?latitude=${pos.lat}&longitude=${pos.lon}` +
      `&current_weather=true&daily=temperature_2m_max,temperature_2m_min&timezone=auto`
    );
    const d = await r.json();
    const cw = d.current_weather;
    if (!cw) throw new Error('天气数据异常');
    const [icon, desc] = WMO[cw.weathercode] || ['🌡️', '未知天气'];
    const hi = d.daily && d.daily.temperature_2m_max && d.daily.temperature_2m_max[0];
    const lo = d.daily && d.daily.temperature_2m_min && d.daily.temperature_2m_min[0];
    let extra = [];
    if (hi != null && lo != null) extra.push(`今日 ${Math.round(lo)}° ~ ${Math.round(hi)}°`);
    if (cw.windspeed != null) extra.push(`风速 ${Math.round(cw.windspeed)} km/h`);
    set(icon, `${Math.round(cw.temperature)}°C`, `${desc}${extra.length ? ' · ' + extra.join(' · ') : ''}`, city);
  } catch {
    set('🌍', '--°C', '天气获取失败（网络受限）', '位置未知');
  }
}
loadWeather();

/* ================= 站点信息（联系方式 / 友链） ================= */
const CONTACT_ICONS = {
  email: '✉️', phone: '📱', wechat: '💬', qq: '🐧', weibo: '🔴',
  bilibili: '📺', douyin: '🎵', xiaohongshu: '📕', zhihu: '📖', jike: '🌐',
  github: '🐙', twitter: '🐦', telegram: '✈️', youtube: '▶️', instagram: '📷',
  facebook: '📘', discord: '🟣', tiktok: '🎶', netease: '☁️', steam: '🎮',
  website: '🌐', link: '🔗'
};

function renderContacts(contacts) {
  const box = $('#contactList');
  if (!contacts || !contacts.length) {
    box.innerHTML = '<p class="empty">暂未设置联系方式</p>';
    return;
  }
  box.innerHTML = contacts.map(c => {
    const icon = CONTACT_ICONS[c.type] || '🔗';
    const link = String(c.link || '');
    const canJump = /^(https?:|mailto:|tel:)/i.test(link);
    if (canJump) {
      return `<a class="contact-item" href="${esc(link)}" target="_blank" rel="noopener noreferrer" title="点击跳转">
        <span class="contact-icon">${icon}</span>
        <span class="contact-text">
          <span class="contact-label">${esc(c.label || c.type)}</span>
          <span class="contact-value">${esc(c.value || link)}</span>
        </span>
        <span class="contact-arrow">↗</span>
      </a>`;
    }
    return `<div class="contact-item" data-copy="${esc(c.value || '')}" title="点击复制">
      <span class="contact-icon">${icon}</span>
      <span class="contact-text">
        <span class="contact-label">${esc(c.label || c.type)}</span>
        <span class="contact-value">${esc(c.value || '')}</span>
      </span>
      <span class="contact-copy">复制</span>
    </div>`;
  }).join('');
  // 无链接的联系方式：点击复制（兼容无 clipboard API 的浏览器/WebView）
  box.querySelectorAll('[data-copy]').forEach(el => {
    el.addEventListener('click', () => {
      const v = el.dataset.copy;
      if (!v) return;
      const doCopy = async () => {
        if (navigator.clipboard && navigator.clipboard.writeText) {
          await navigator.clipboard.writeText(v);
        } else {
          const ta = document.createElement('textarea');
          ta.value = v;
          ta.style.position = 'fixed';
          ta.style.opacity = '0';
          document.body.appendChild(ta);
          ta.select();
          const ok = document.execCommand('copy');
          document.body.removeChild(ta);
          if (!ok) throw new Error('execCommand copy failed');
        }
      };
      doCopy().then(() => toast('已复制：' + v)).catch(() => toast('复制失败，请手动选择'));
    });
  });
}

function renderFriendLinks(links) {
  const box = $('#linkList');
  if (!links || !links.length) {
    box.innerHTML = '<p class="empty">暂未设置友情链接</p>';
    return;
  }
  box.innerHTML = links.map(l =>
    `<li><a class="friend-link" href="${esc(l.url)}" target="_blank" rel="noopener noreferrer" title="访问 ${esc(l.name)}">
      <span class="friend-icon">${esc(String(l.name || '?').slice(0, 1).toUpperCase())}</span>
      <span class="friend-text">
        <span class="friend-name">${esc(l.name)}</span>
        <span class="friend-desc">${esc(l.desc || l.url)}</span>
      </span>
      <span class="friend-arrow">↗</span>
    </a></li>`
  ).join('');
}

function copyText(text) {
  if (navigator.clipboard && navigator.clipboard.writeText) {
    navigator.clipboard.writeText(text).catch(() => fallbackCopy(text));
  } else {
    fallbackCopy(text);
  }
}
function fallbackCopy(text) {
  const ta = document.createElement('textarea');
  ta.value = text;
  ta.style.position = 'fixed';
  ta.style.opacity = '0';
  document.body.appendChild(ta);
  ta.select();
  try { document.execCommand('copy'); } catch {}
  document.body.removeChild(ta);
}
function openImagePreview(url, name) {
  const modal = $('#imgPreviewModal');
  if (!modal) return;
  const img = $('#imgPreviewSrc');
  img.src = url || '';
  img.alt = name || '';
  modal.hidden = false;
  modal.onclick = e => {
    if (e.target === modal || e.target.id === 'imgPreviewClose') modal.hidden = true;
  };
}
function renderSponsorLinks(links) {
  const box = $('#sponsorList');
  if (!links || !links.length) {
    box.innerHTML = '<p class="empty">暂未设置赞助链接</p>';
    return;
  }
  box.innerHTML = links.map(l => {
    const thumb = l.image
      ? `<div class="sponsor-thumb"><img src="${esc(l.image)}" alt="${esc(l.name)}" loading="lazy" onerror="this.parentElement.style.display='none'"></div>`
      : '<span class="sponsor-icon">☕</span>';
    return `<li class="sponsor-item">
      ${thumb}
      <span class="sponsor-text">
        <span class="sponsor-name">${esc(l.name)}</span>
        <span class="sponsor-desc">${esc(l.desc || l.url)}</span>
      </span>
      <span class="sponsor-arrow">↗</span>
    </li>`;
  }).join('');
  box.querySelectorAll('.sponsor-item').forEach((li, i) => {
    const l = links[i];
    const validUrl = /^https?:\/\//i.test(l.url || '');
    const thumb = li.querySelector('.sponsor-thumb');
    if (thumb && l.image) {
      thumb.addEventListener('click', e => { e.stopPropagation(); openImagePreview(l.image, l.name); });
    }
    li.addEventListener('click', () => {
      if (validUrl) {
        window.open(l.url, '_blank', 'noopener');
      } else {
        copyText((l.name || '') + (l.desc ? '\n' + l.desc : '') + (l.url && l.url !== l.desc ? '\n' + l.url : ''));
        toast('已复制：' + (l.name || '赞助账号'));
      }
    });
  });
}

/* ================= 文章列表 ================= */
function postCardHtml(p) {
  const cover = p.cover
    ? `<div class="post-cover"><img src="${esc(p.cover)}" alt="${esc(p.title)} 封面" loading="lazy"
         onerror="this.parentElement.classList.add('post-cover--ph');this.remove()"></div>`
    : `<div class="post-cover post-cover--ph"><span>${esc(String(p.title).slice(0, 1))}</span></div>`;
  const tags = (p.tags || []).map(t => `<span class="tag">${esc(t)}</span>`).join('');
  const pinBadge = p.pinned ? `<span class="post-pin">📌 置顶</span>` : '';
  return `<a class="post-card card${p.pinned ? ' is-pinned' : ''}" href="/post.html?id=${encodeURIComponent(p.id)}">
    ${cover}
    <div class="post-info">
      <div class="post-tags">${pinBadge}${tags}</div>
      <h3>${esc(p.title)}</h3>
      <p class="post-summary">${esc(p.summary)}</p>
      <div class="post-meta">
        <span>📅 ${fmtDate(p.createdAt)}</span>
        <span>👁 ${p.views || 0} 次阅读</span>
      </div>
    </div>
  </a>`;
}

/* ================= 文章列表：分页 + 搜索 ================= */
let postsPage = 1;
let postsQuery = '';
let postsHasMore = true;
let postsLoading = false;

async function loadPosts(append = false) {
  if (postsLoading) return;
  postsLoading = true;
  if (!append) {
    postsPage = 1;
    $('#postList').innerHTML = '<p class="empty">正在加载文章…</p>';
  }

  try {
    const limit = 5;
    const params = new URLSearchParams();
    params.set('page', postsPage);
    params.set('limit', limit);
    if (postsQuery) params.set('q', postsQuery);

    const res = await fetch('/api/posts?' + params.toString());
    const data = await res.json();
    const list = data.posts || [];
    postsHasMore = !!data.hasMore;

    if (!append && !list.length) {
      $('#postList').innerHTML = `<p class="empty">${postsQuery ? '没有找到匹配的文章' : '还没有文章，去后台写第一篇吧 ✍️'}</p>`;
      $('#loadMoreWrap').hidden = false;
      $('#loadMoreBtn').hidden = true;
      $('#loadMoreTip').hidden = false;
      $('#loadMoreTip').textContent = postsQuery ? '没有更多结果' : '已经到底啦';
      postsLoading = false;
      return;
    }

    const html = list.map(postCardHtml).join('');
    if (append) {
      $('#postList').insertAdjacentHTML('beforeend', html);
    } else {
      $('#postList').innerHTML = html;
    }

    $('#loadMoreWrap').hidden = false;
    $('#loadMoreBtn').hidden = !postsHasMore;
    $('#loadMoreTip').hidden = postsHasMore;
    $('#loadMoreTip').textContent = '已经到底啦';
  } catch {
    if (!append) {
      $('#postList').innerHTML = '<p class="empty">文章加载失败，请刷新重试</p>';
      $('#loadMoreWrap').hidden = true;
    } else {
      toast('加载失败，请重试');
    }
  } finally {
    postsLoading = false;
  }
}

function searchPosts() {
  const v = $('#searchInput').value.trim();
  if (v === postsQuery) return;
  postsQuery = v;
  loadPosts(false);
}

function nextPage() {
  if (!postsHasMore || postsLoading) return;
  postsPage += 1;
  loadPosts(true);
}

$('#searchBtn').addEventListener('click', searchPosts);
$('#searchInput').addEventListener('keydown', e => {
  if (e.key === 'Enter') searchPosts();
});
$('#loadMoreBtn').addEventListener('click', nextPage);

// 滚动到底部自动加载下一页
const loadMoreObserver = new IntersectionObserver(entries => {
  if (entries[0].isIntersecting && postsHasMore && !postsLoading) {
    nextPage();
  }
}, { rootMargin: '120px' });
if ($('#loadMoreBtn')) {
  loadMoreObserver.observe($('#loadMoreBtn'));
}

async function loadSite() {
  try {
    const site = await (await fetch('/api/site')).json();
    document.title = site.siteName;
    $('#navSiteName').textContent = site.siteName;
    $('#heroSiteName').textContent = site.siteName;
    $('#heroBio').textContent = site.bio || '';
    $('#footerSiteName').textContent = site.siteName;
    // 头像：保存了自定义头像就显示，否则隐藏
    const avatarImg = $('#heroAvatar');
    if (site.avatar) {
      avatarImg.src = site.avatar;
      avatarImg.style.display = '';
    } else {
      avatarImg.style.display = 'none';
    }
    renderContacts(site.contacts);
    renderSponsorLinks(site.sponsorLinks);
    renderFriendLinks(site.links);
  } catch {
    $('#heroBio').textContent = '站点信息加载失败';
  }
}

loadSite();
loadPosts();

/* ================= 邮件订阅（仅收集邮箱，不在前台暴露订阅量） ================= */
function setupSubscribe() {
  const form = $('#subscribeForm');
  if (!form) return;
  const emailInput = $('#subscribeEmail');
  const btn = $('#subscribeBtn');
  const hint = $('#subscribeHint');
  form.addEventListener('submit', async e => {
    e.preventDefault();
    const email = emailInput.value.trim();
    if (!email) { hint.textContent = '请先输入邮箱'; hint.className = 'subscribe-hint err'; return; }
    btn.disabled = true;
    btn.textContent = '提交中…';
    try {
      const r = await fetch('/api/subscribe', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email })
      });
      const data = await r.json();
      if (r.ok && data.ok) {
        if (data.subscribed === false) {
          hint.textContent = data.message || '你已订阅过啦';
          hint.className = 'subscribe-hint ok';
        } else {
          hint.textContent = '订阅成功，感谢支持！🎉';
          hint.className = 'subscribe-hint ok';
        }
        emailInput.value = '';
      } else {
        hint.textContent = data.error || '订阅失败，请稍后再试';
        hint.className = 'subscribe-hint err';
      }
    } catch {
      hint.textContent = '网络异常，请稍后再试';
      hint.className = 'subscribe-hint err';
    } finally {
      btn.disabled = false;
      btn.textContent = '订阅';
    }
  });
}
setupSubscribe();

/* ================= 顶部导航锚点平滑滚动（兼容 sticky 导航栏遮挡） ================= */
function scrollToCard(selector, highlight = true) {
  const target = document.querySelector(selector);
  if (!target) return false;
  const topbar = document.querySelector('.topbar');
  const offset = (topbar ? topbar.offsetHeight : 62) + 14;
  const y = Math.max(0, target.getBoundingClientRect().top + window.scrollY - offset);
  try {
    window.scrollTo({ top: y, behavior: 'smooth' });
  } catch {
    window.scrollTo(0, y);
  }
  if (highlight) {
    target.classList.add('anchor-pulse');
    setTimeout(() => target.classList.remove('anchor-pulse'), 1800);
  }
  return true;
}

document.querySelectorAll('.nav a[href^="#"]').forEach(a => {
  a.addEventListener('click', e => {
    const href = a.getAttribute('href');
    if (!href || !href.startsWith('#')) return;
    if (scrollToCard(href)) e.preventDefault();
  });
});

// 从文章页带 hash 回到首页时，自动滚动到对应侧栏卡片
if (location.hash) {
  setTimeout(() => scrollToCard(location.hash), 120);
}
