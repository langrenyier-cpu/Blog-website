/* 文章详情页逻辑 */
const $ = s => document.querySelector(s);
const params = new URLSearchParams(location.search);
const postId = params.get('id');

function esc(s) {
  return String(s == null ? '' : s)
    .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
}
function fmtDate(ts) {
  const d = new Date(ts);
  const p = n => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}`;
}
let toastTimer = null;
function toast(msg) {
  const t = $('#toast');
  t.textContent = msg;
  t.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => t.classList.remove('show'), 2200);
}

/* 一键换肤（与首页保持一致） */
const THEMES = [
  { id: 'light', icon: '☀️', label: '浅色' },
  { id: 'dark', icon: '🌙', label: '深色' },
  { id: 'glass', icon: '💎', label: '玻璃' },
  { id: 'tech', icon: '⚡', label: '科技' },
  { id: 'neumorph', icon: '🧊', label: '拟态玻璃' }
];
const WALLPAPER_THEMES = ['glass', 'neumorph'];
const themePicker = $('#themePicker');
const themeIcon = $('#themeIcon');
const themeLabel = $('#themeLabel');
function applyTheme(id) {
  const t = THEMES.find(x => x.id === id) || THEMES[0];
  document.documentElement.dataset.theme = id;
  themeIcon.textContent = t.icon;
  themeLabel.textContent = t.label;
  try { localStorage.setItem('theme', id); } catch {}
  setAnimeWallpaper(WALLPAPER_THEMES.includes(id));
}
function setAnimeWallpaper(show) {
  let bg = document.getElementById('animeBg');
  if (!bg) {
    bg = document.createElement('div');
    bg.id = 'animeBg';
    bg.className = 'anime-bg';
    document.body.insertBefore(bg, document.body.firstChild);
  }
  if (!show) { bg.classList.remove('show'); return; }
  if (bg.style.backgroundImage) { bg.classList.add('show'); return; }
  loadAnimeWallpaper();
}
async function loadAnimeWallpaper() {
  const bg = document.getElementById('animeBg');
  if (!bg) return;
  const img = new Image();
  img.onload = () => {
    bg.style.backgroundImage = `url('/api/wallpaper')`;
    bg.classList.add('show');
  };
  img.onerror = () => { bg.classList.remove('show'); };
  img.src = '/api/wallpaper';
}
function nextTheme() {
  const cur = document.documentElement.dataset.theme || 'light';
  const idx = THEMES.findIndex(t => t.id === cur);
  const next = THEMES[(idx + 1) % THEMES.length];
  applyTheme(next.id);
}
themePicker.addEventListener('click', nextTheme);

/* 文章页顶部导航：/#contacts、/#links 跳转回首页并锚定到侧栏卡片 */
document.querySelectorAll('.nav a[href^="/#"]').forEach(a => {
  a.addEventListener('click', e => {
    const href = a.getAttribute('href');
    if (!href || !href.startsWith('/#')) return;
    e.preventDefault();
    location.href = href;
  });
});

applyTheme(
  localStorage.getItem('theme') ||
  (matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light')
);

function renderPost(p) {
  document.title = `${p.title} - 站点`;
  $('#postTitle').textContent = p.title;
  const tags = (p.tags || []).map(t => `<span class="tag">${esc(t)}</span>`).join('');
  $('#postMeta').innerHTML =
    `<span>📅 ${fmtDate(p.createdAt)}</span><span>👁 ${p.views || 0} 次阅读</span><span>${tags}</span>`;

  const share = $('#postShare');
  if (share) share.hidden = false;

  const content = $('#postContent');
  content.innerHTML = p.content;
  // 文内链接一律新窗口打开，保证可点击跳转
  content.querySelectorAll('a').forEach(a => {
    a.target = '_blank';
    a.rel = 'noopener noreferrer';
  });
  // 图片加载失败时优雅降级
  content.querySelectorAll('img').forEach(img => {
    img.addEventListener('error', () => { img.style.display = 'none'; });
  });
}

function setupShare(p) {
  const longUrl = new URL(`/post.html?id=${encodeURIComponent(p.id)}`, location.origin).href;

  // 当前环境不支持 Web Share API 时，隐藏系统分享按钮
  const sysBtn = $('#shareSystemBtn');
  if (sysBtn && !navigator.share) sysBtn.hidden = true;

  let shortUrlCache = null;
  let shortUrlPromise = null;
  async function getShareUrl() {
    if (shortUrlCache) return shortUrlCache;
    if (!shortUrlPromise) {
      shortUrlPromise = fetch('/api/shorten', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ url: longUrl })
      })
        .then(r => r.json())
        .then(d => {
          if (d.ok && d.url) shortUrlCache = d.url;
          return shortUrlCache || longUrl;
        })
        .catch(() => longUrl);
    }
    return shortUrlPromise;
  }

  $('#postShare').addEventListener('click', async e => {
    const btn = e.target.closest('[data-action]');
    if (!btn) return;
    const action = btn.dataset.action;
    if (action === 'copy') {
      try {
        const url = await getShareUrl();
        await navigator.clipboard.writeText(url);
        toast('已复制短链接');
      } catch {
        const url = await getShareUrl();
        const ta = document.createElement('textarea');
        ta.value = url;
        document.body.appendChild(ta);
        ta.select();
        document.execCommand('copy');
        document.body.removeChild(ta);
        toast('已复制短链接');
      }
    } else if (action === 'share') {
      if (!navigator.share) {
        toast('当前环境不支持系统分享');
        return;
      }
      try {
        const url = await getShareUrl();
        await navigator.share({ title: p.title, text: p.summary || '', url });
      } catch {
        // 用户取消分享不提示
      }
    }
  });
}

function renderNav(list) {
  const idx = list.findIndex(p => p.id === postId);
  if (idx < 0) return;
  const prev = list[idx + 1];
  const next = list[idx - 1];
  let html = '';
  if (prev) html += `<a href="/post.html?id=${encodeURIComponent(prev.id)}">
    <span class="nav-label">← 上一篇</span><span class="nav-title">${esc(prev.title)}</span></a>`;
  else html += '<a class="placeholder"></a>';
  if (next) html += `<a class="next" href="/post.html?id=${encodeURIComponent(next.id)}">
    <span class="nav-label">下一篇 →</span><span class="nav-title">${esc(next.title)}</span></a>`;
  else html += '<a class="placeholder next"></a>';
  $('#postNav').innerHTML = html;
}

async function init() {
  $('#footerYear').textContent = new Date().getFullYear();
  try {
    const site = await (await fetch('/api/site')).json();
    $('#navSiteName').textContent = site.siteName;
    $('#footerSiteName').textContent = site.siteName;
  } catch {}

  if (!postId) {
    $('#postTitle').textContent = '缺少文章参数';
    $('#postContent').innerHTML = '<p>未指定要查看的文章，请从 <a href="/">首页</a> 进入。</p>';
    return;
  }
  try {
    const [post, data] = await Promise.all([
      fetch('/api/posts/' + encodeURIComponent(postId)).then(r => {
        if (!r.ok) throw new Error();
        return r.json();
      }),
      fetch('/api/posts?limit=999').then(r => r.json())
    ]);
    renderPost(post);
    document.title = `${post.title} - ${$('#navSiteName').textContent}`;
    renderNav(data.posts || []);
    setupShare(post);
  } catch {
    $('#postTitle').textContent = '文章不存在或未发布';
    $('#postContent').innerHTML = '<p>可能已被删除，回 <a href="/">首页</a> 看看其他文章吧。</p>';
  }
}
init();
