/* ================= 工具与全局状态 ================= */
const $ = s => document.querySelector(s);
const $$ = s => Array.from(document.querySelectorAll(s));

let TOKEN = localStorage.getItem('blogToken') || '';
let editingId = null;      // 当前编辑的文章 id（null = 新建）
let savedRange = null;     // 编辑器最近选区
let adminInited = false;

function authHeader() {
  return TOKEN ? { Authorization: 'Bearer ' + TOKEN } : {};
}
async function api(path, opts = {}) {
  const res = await fetch(path, {
    ...opts,
    headers: { 'Content-Type': 'application/json', ...(opts.headers || {}), ...authHeader() }
  });
  const data = await res.json().catch(() => ({}));
  if (res.status === 401) { showLogin(); throw new Error(data.error || '请先登录'); }
  if (!res.ok) throw new Error(data.error || '请求失败');
  return data;
}
function stripHtml(html) {
  const div = document.createElement('div');
  div.innerHTML = html || '';
  return div.textContent.trim();
}

let toastTimer = null;
function toast(msg, ok = true) {
  const t = $('#toast');
  t.textContent = msg;
  t.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => t.classList.remove('show'), 2400);
}
function fmtDate(ts) {
  const d = new Date(ts);
  const p = n => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())} ${p(d.getHours())}:${p(d.getMinutes())}`;
}

/* 主题（与前台一致） */
(function initTheme() {
  const btn = $('#themeToggle') || document.createElement('button');
  const apply = t => { document.documentElement.dataset.theme = t; };
  apply(localStorage.getItem('theme') || (matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light'));
  if ($('#themeToggle')) {
    $('#themeToggle').addEventListener('click', () => {
      const next = document.documentElement.dataset.theme === 'dark' ? 'light' : 'dark';
      localStorage.setItem('theme', next);
      apply(next);
    });
  }
})();

/* ================= 登录 / 登出 ================= */
function showLogin() {
  TOKEN = '';
  localStorage.removeItem('blogToken');
  $('#adminView').hidden = true;
  $('#loginView').hidden = false;
}
function showAdmin() {
  $('#loginView').hidden = true;
  $('#adminView').hidden = false;
  if (!adminInited) { initAdmin(); adminInited = true; }
  switchView('dashboard');
}

$('#loginForm').addEventListener('submit', async e => {
  e.preventDefault();
  const btn = $('#loginBtn');
  const err = $('#loginErr');
  err.textContent = '';
  btn.disabled = true;
  btn.textContent = '登录中…';
  try {
    const data = await api('/api/login', {
      method: 'POST',
      body: JSON.stringify({
        username: $('#loginUser').value.trim(),
        password: $('#loginPass').value
      })
    });
    TOKEN = data.token;
    localStorage.setItem('blogToken', TOKEN);
    showAdmin();
  } catch (ex) {
    err.textContent = ex.message;
  } finally {
    btn.disabled = false;
    btn.textContent = '登 录';
  }
});

$('#logoutBtn').addEventListener('click', async () => {
  try { await api('/api/logout', { method: 'POST' }); } catch {}
  showLogin();
});

/* ================= 视图切换 ================= */
$$('.side-nav a[data-view]').forEach(a => {
  a.addEventListener('click', e => {
    e.preventDefault();
    const view = a.dataset.view;
    if (view === 'editor' && a.id === 'navNewPost') resetEditor(); // 点侧栏「写文章」= 新建
    switchView(view);
  });
});
function switchView(name) {
  $$('.view').forEach(v => { v.hidden = v.id !== 'view-' + name; });
  $$('.side-nav a[data-view]').forEach(a => a.classList.toggle('active', a.dataset.view === name));
  if (name === 'dashboard') renderDashboard();
  if (name === 'posts') loadPostsTable();
  if (name === 'settings') loadSettings();
}

/* ================= 仪表盘 ================= */
async function renderDashboard() {
  try {
    const list = await api('/api/posts?all=1');
    const published = list.filter(p => p.status === 'published');
    $('#statTotal').textContent = list.length;
    $('#statPublished').textContent = published.length;
    $('#statDraft').textContent = list.length - published.length;
    $('#statViews').textContent = list.reduce((s, p) => s + (p.views || 0), 0);
    const recent = list.slice(0, 5);
    $('#recentTable').innerHTML = recent.length ? `
      <thead><tr><th>标题</th><th>状态</th><th>阅读</th><th>更新时间</th></tr></thead>
      <tbody>${recent.map(p => `
        <tr>
          <td class="td-title"><a href="#" class="js-edit" data-id="${p.id}">${escapeHtml(p.title)}</a></td>
          <td><span class="status-pill ${p.status}">${p.status === 'published' ? '已发布' : '草稿'}</span></td>
          <td>${p.views || 0}</td>
          <td>${fmtDate(p.updatedAt)}</td>
        </tr>`).join('')}
      </tbody>` : '<tbody><tr><td class="empty">暂无文章</td></tr></tbody>';
    $$('#recentTable .js-edit').forEach(a =>
      a.addEventListener('click', e => { e.preventDefault(); startEdit(a.dataset.id); }));
  } catch (e) { toast(e.message); }
}
function escapeHtml(s) {
  return String(s == null ? '' : s)
    .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
}

/* ================= 文章列表 ================= */
async function loadPostsTable() {
  try {
    const list = await api('/api/posts?all=1');
    $('#postsTable').innerHTML = list.length ? `
      <thead><tr><th>标题</th><th>状态</th><th>标签</th><th>阅读</th><th>更新时间</th><th>操作</th></tr></thead>
      <tbody>${list.map(p => `
        <tr>
          <td class="td-title"><a href="#" class="js-edit" data-id="${p.id}">${escapeHtml(p.title)}</a></td>
          <td><span class="status-pill ${p.status}">${p.status === 'published' ? '已发布' : '草稿'}</span></td>
          <td>${(p.tags || []).map(t => `<span class="tag">${escapeHtml(t)}</span>`).join(' ') || '—'}</td>
          <td>${p.views || 0}</td>
          <td>${fmtDate(p.updatedAt)}</td>
          <td class="td-actions">
            <button class="btn-danger-link js-toggle" data-id="${p.id}" data-next="${p.status === 'published' ? 'draft' : 'published'}">
              ${p.status === 'published' ? '下架' : '发布'}
            </button>
            <button class="btn-danger-link js-edit" data-id="${p.id}" style="color:var(--primary)">编辑</button>
            <button class="btn-danger-link js-del" data-id="${p.id}">删除</button>
          </td>
        </tr>`).join('')}
      </tbody>` : '<tbody><tr><td class="empty">还没有文章，点击右上角「新建文章」开始创作 ✍️</td></tr></tbody>';

    $$('#postsTable .js-edit').forEach(b => b.addEventListener('click', () => startEdit(b.dataset.id)));
    $$('#postsTable .js-toggle').forEach(b => b.addEventListener('click', () => togglePost(b.dataset.id, b.dataset.next)));
    $$('#postsTable .js-del').forEach(b => b.addEventListener('click', () => deletePost(b.dataset.id)));
  } catch (e) { toast(e.message); }
}

async function togglePost(id, next) {
  try {
    const list = await api('/api/posts?all=1');
    const p = list.find(x => x.id === id);
    if (!p) return;
    await api('/api/posts/' + id, {
      method: 'PUT',
      body: JSON.stringify({ ...p, status: next })
    });
    toast(next === 'published' ? '已发布 🎉' : '已转为草稿');
    loadPostsTable();
  } catch (e) { toast(e.message); }
}

async function deletePost(id) {
  const list = await api('/api/posts?all=1').catch(() => []);
  const p = list.find(x => x.id === id);
  if (!confirm(`确定删除文章《${p ? p.title : id}》？此操作不可恢复。`)) return;
  try {
    await api('/api/posts/' + id, { method: 'DELETE' });
    toast('已删除');
    loadPostsTable();
  } catch (e) { toast(e.message); }
}

/* ================= 编辑器：载入 / 重置 / 保存 ================= */
const editor = $('#editor');

function resetEditor() {
  editingId = null;
  $('#fTitle').value = '';
  $('#fSummary').value = '';
  $('#fCover').value = '';
  $('#fTags').value = '';
  $('#fStatus').value = 'published';
  editor.innerHTML = '';
  $('#editorMode').textContent = '写文章';
  $('#editingFlag').hidden = true;
  $('#saveMsg').textContent = '';
}

async function startEdit(id) {
  try {
    const list = await api('/api/posts?all=1');
    const p = list.find(x => x.id === id);
    if (!p) return toast('文章不存在');
    editingId = p.id;
    $('#fTitle').value = p.title;
    $('#fSummary').value = p.summary || '';
    $('#fCover').value = p.cover || '';
    $('#fTags').value = (p.tags || []).join(', ');
    $('#fStatus').value = p.status;
    editor.innerHTML = p.content;
    $('#editorMode').textContent = '编辑文章';
    $('#editingFlag').hidden = false;
    switchView('editor');
  } catch (e) { toast(e.message); }
}

$('#btnNewPost').addEventListener('click', () => { resetEditor(); switchView('editor'); });

function collectPost() {
  const title = $('#fTitle').value.trim();
  const content = editor.innerHTML;
  if (!title) { toast('请填写文章标题'); return null; }
  if (!stripHtml(content) && !/<img\s/i.test(content)) { toast('正文内容不能为空'); return null; }
  return {
    title,
    summary: $('#fSummary').value.trim(),
    cover: $('#fCover').value.trim(),
    tags: $('#fTags').value,
    status: $('#fStatus').value,
    content
  };
}

async function savePost(openPreview = false) {
  const body = collectPost();
  if (!body) return null;
  const btn = $('#btnSave');
  btn.disabled = true;
  btn.textContent = '保存中…';
  try {
    const p = editingId
      ? await api('/api/posts/' + editingId, { method: 'PUT', body: JSON.stringify(body) })
      : await api('/api/posts', { method: 'POST', body: JSON.stringify(body) });
    editingId = p.id;
    $('#editorMode').textContent = '编辑文章';
    $('#editingFlag').hidden = false;
    $('#saveMsg').textContent = `已保存 · ${fmtDate(p.updatedAt)}`;
    toast(openPreview ? '保存成功，正在打开预览…' : '保存成功 ✅');
    if (openPreview) window.open('/post.html?id=' + encodeURIComponent(p.id), '_blank');
    return p;
  } catch (e) {
    toast(e.message);
    return null;
  } finally {
    btn.disabled = false;
    btn.textContent = '💾 保存文章';
  }
}
$('#btnSave').addEventListener('click', () => savePost(false));
$('#btnPreview').addEventListener('click', () => savePost(true));

/* 封面上传 */
$('#btnCoverUpload').addEventListener('click', () => $('#fCoverFile').click());
$('#fCoverFile').addEventListener('change', async e => {
  const file = e.target.files[0];
  if (!file) return;
  try {
    const url = await uploadImage(file, st => toast(st));
    $('#fCover').value = url;
    toast('封面上传成功');
  } catch (err) { toast('上传失败：' + err.message); }
  e.target.value = '';
});

/* ================= 富文本编辑器核心 ================= */
/* 记录选区：工具栏按钮 mousedown 已 preventDefault，双保险再存一份 */
function saveSelection() {
  const sel = window.getSelection();
  if (sel.rangeCount && editor.contains(sel.anchorNode)) {
    savedRange = sel.getRangeAt(0).cloneRange();
  }
}
editor.addEventListener('keyup', saveSelection);
editor.addEventListener('mouseup', saveSelection);
editor.addEventListener('focus', saveSelection);

function restoreSelection() {
  if (savedRange) {
    const sel = window.getSelection();
    sel.removeAllRanges();
    sel.addRange(savedRange);
  }
}

/* 工具栏按钮：mousedown 阻止抢焦点 */
$$('#toolbar .tb-btn, #toolbar .tb-select').forEach(el => {
  el.addEventListener('mousedown', e => e.preventDefault());
});

function exec(cmd, val) {
  editor.focus();
  restoreSelection();
  try { document.execCommand('styleWithCSS', false, true); } catch {}
  document.execCommand(cmd, false, val);
  saveSelection();
  editor.focus();
}

$$('#toolbar .tb-btn[data-cmd]').forEach(btn => {
  btn.addEventListener('click', () => exec(btn.dataset.cmd));
});

/* 段落格式 */
$('#blockType').addEventListener('change', e => {
  const v = e.target.value;
  if (v) exec('formatBlock', '<' + v + '>');
  e.target.selectedIndex = 0;
});

/* 像素级字号：选区包裹 span（自定义实现，支持 12~36px） */
function setFontSize(px) {
  editor.focus();
  restoreSelection();
  const sel = window.getSelection();
  if (!sel.rangeCount) return;
  const range = sel.getRangeAt(0);
  if (range.collapsed) { toast('请先选中要调整的文字'); return; }
  if (!editor.contains(range.commonAncestorContainer)) { toast('请先在编辑器中选中文字'); return; }
  try {
    const span = document.createElement('span');
    span.style.fontSize = px + 'px';
    span.appendChild(range.extractContents());
    range.insertNode(span);
    const r = document.createRange();
    r.selectNodeContents(span);
    sel.removeAllRanges();
    sel.addRange(r);
    savedRange = r.cloneRange();
  } catch (e) {
    console.error(e);
    toast('设置字号失败，请重新选择文字');
  }
}
$('#fontSizeSel').addEventListener('change', e => {
  const v = e.target.value;
  if (!v) return;
  if (v === 'clear') { exec('removeFormat'); }
  else setFontSize(Number(v));
  e.target.selectedIndex = 0;
});

/* 文字颜色 / 荧光高亮 */
$('#foreColorInput').addEventListener('input', e => exec('foreColor', e.target.value));
$('#hiliteColorInput').addEventListener('input', e => exec('hiliteColor', e.target.value));

/* ================= 插入链接 ================= */
const linkModal = $('#linkModal');
$('#btnInsertLink').addEventListener('click', () => {
  saveSelection();
  const sel = window.getSelection();
  const selected = sel.toString();
  $('#linkText').value = selected;
  $('#linkUrl').value = 'https://';
  linkModal.hidden = false;
  $('#linkUrl').focus();
  $('#linkUrl').select();
});
$('#linkConfirm').addEventListener('click', () => {
  let url = $('#linkUrl').value.trim();
  const text = $('#linkText').value.trim();
  if (!url) { toast('请填写链接地址'); return; }
  if (!/^(https?:|mailto:|tel:|\/|#)/i.test(url)) url = 'https://' + url;
  editor.focus();
  restoreSelection();
  const sel = window.getSelection();
  const hasSelection = sel.toString().length > 0 && editor.contains(sel.anchorNode);
  const blank = $('#linkBlank').checked ? ' target="_blank" rel="noopener noreferrer"' : '';
  if (hasSelection && !text) {
    exec('createLink', url);
    // createLink 无法带 target，补上
    editor.querySelectorAll('a').forEach(a => {
      if (a.href === url || a.getAttribute('href') === url) {
        if ($('#linkBlank').checked) { a.target = '_blank'; a.rel = 'noopener noreferrer'; }
      }
    });
  } else {
    const label = text || url.replace(/^https?:\/\//, '');
    document.execCommand('insertHTML', false,
      `<a href="${escapeAttr(url)}"${blank}>${escapeHtml(label)}</a>`);
  }
  linkModal.hidden = true;
  saveSelection();
});

/* ================= 插入图片 ================= */
const imageModal = $('#imageModal');
let imgTab = 'upload';
$$('.tab').forEach(t => t.addEventListener('click', () => {
  imgTab = t.dataset.tab;
  $$('.tab').forEach(x => x.classList.toggle('active', x === t));
  $('#tab-upload').hidden = imgTab !== 'upload';
  $('#tab-url').hidden = imgTab !== 'url';
}));

$('#btnInsertImage').addEventListener('click', () => {
  saveSelection();
  $('#uploadStatus').textContent = '';
  $('#imageUrl').value = '';
  imageModal.hidden = false;
});

/* 上传图片（后台 API），fn 用于展示进度提示 */
async function uploadImage(file, notify) {
  if (!/^image\//.test(file.type)) throw new Error('只能上传图片文件');
  if (file.size > 10 * 1024 * 1024) throw new Error('图片不能超过 10MB');
  notify && notify('上传中…');
  const fd = new FormData();
  fd.append('image', file);
  const res = await fetch('/api/upload', { method: 'POST', headers: authHeader(), body: fd });
  const data = await res.json().catch(() => ({}));
  if (res.status === 401) { showLogin(); throw new Error('请先登录'); }
  if (!res.ok) throw new Error(data.error || '上传失败');
  return data.url;
}

$('#uploadArea').addEventListener('click', () => $('#imageFile').click());
$('#imageFile').addEventListener('change', async e => {
  const file = e.target.files[0];
  e.target.value = '';
  if (!file) return;
  const st = $('#uploadStatus');
  try {
    st.textContent = '⏳ 上传中…';
    const url = await uploadImage(file);
    st.textContent = '✅ 上传成功';
    insertImageAtSelection(url);
    imageModal.hidden = true;
  } catch (err) {
    st.textContent = '❌ ' + err.message;
  }
});

$('#imageConfirm').addEventListener('click', () => {
  if (imgTab === 'url') {
    let url = $('#imageUrl').value.trim();
    if (!url) { toast('请填写图片地址'); return; }
    if (!/^(https?:|data:image|\/)/i.test(url)) url = 'https://' + url;
    insertImageAtSelection(url);
    imageModal.hidden = true;
  } else {
    $('#imageFile').click();
  }
});

function insertImageAtSelection(url) {
  editor.focus();
  restoreSelection();
  document.execCommand('insertImage', false, url);
  saveSelection();
}

/* 直接粘贴图片 → 自动上传并插入 */
editor.addEventListener('paste', async e => {
  const items = e.clipboardData && e.clipboardData.items;
  if (!items) return;
  for (const item of items) {
    if (item.type && item.type.startsWith('image/')) {
      e.preventDefault();
      const file = item.getAsFile();
      if (!file) return;
      saveSelection();
      try {
        const url = await uploadImage(file);
        insertImageAtSelection(url);
        toast('图片已上传并插入 ✅');
      } catch (err) {
        toast('粘贴上传失败：' + err.message);
      }
      return;
    }
  }
});

/* 弹窗通用关闭 */
$$('.modal [data-close]').forEach(b => b.addEventListener('click', () => {
  linkModal.hidden = true;
  imageModal.hidden = true;
}));
$$('.modal-overlay').forEach(ov => ov.addEventListener('mousedown', e => {
  if (e.target === ov) { ov.hidden = true; }
}));
document.addEventListener('keydown', e => {
  if (e.key === 'Escape') { linkModal.hidden = true; imageModal.hidden = true; }
});

function escapeAttr(s) { return escapeHtml(s); }

/* ================= 站点设置 ================= */
const CONTACT_TYPES = [
  ['email', '✉️ 邮箱'],
  ['phone', '📱 手机/电话'],
  ['wechat', '💬 微信'],
  ['qq', '🐧 QQ'],
  ['weibo', '🔴 微博'],
  ['bilibili', '📺 哔哩哔哩'],
  ['douyin', '🎵 抖音'],
  ['xiaohongshu', '📕 小红书'],
  ['zhihu', '📖 知乎'],
  ['jike', '🌐 即刻'],
  ['github', '🐙 GitHub'],
  ['twitter', '🐦 X/Twitter'],
  ['telegram', '✈️ Telegram'],
  ['youtube', '▶️ YouTube'],
  ['instagram', '📷 Instagram'],
  ['facebook', '📘 Facebook'],
  ['discord', '🟣 Discord'],
  ['tiktok', '🎶 TikTok'],
  ['netease', '☁️ 网易云音乐'],
  ['steam', '🎮 Steam'],
  ['website', '🌐 个人网站'],
  ['link', '🔗 其他链接']
];

function contactRowHtml(c = {}) {
  return `<div class="row-grid contact-row">
    <select class="c-type">${CONTACT_TYPES.map(([v, l]) =>
      `<option value="${v}" ${c.type === v ? 'selected' : ''}>${l}</option>`).join('')}</select>
    <input class="c-label" placeholder="显示名称" value="${escapeHtml(c.label || '')}">
    <input class="c-value" placeholder="内容（邮箱/账号/号码）" value="${escapeHtml(c.value || '')}">
    <input class="c-link" placeholder="跳转链接，可空（https://… 或 mailto:…）" value="${escapeHtml(c.link || '')}">
    <button class="row-del" title="删除此行">✕</button>
  </div>`;
}
function linkRowHtml(l = {}) {
  return `<div class="row-grid link-row">
    <input class="l-name" placeholder="网站名称" value="${escapeHtml(l.name || '')}">
    <input class="l-url" placeholder="https://example.com" value="${escapeHtml(l.url || '')}">
    <input class="l-desc" placeholder="一句话描述" value="${escapeHtml(l.desc || '')}">
    <button class="row-del" title="删除此行">✕</button>
  </div>`;
}

async function loadSettings() {
  try {
    const site = await api('/api/site');
    $('#sSiteName').value = site.siteName || '';
    $('#sOwnerName').value = site.ownerName || '';
    $('#sAvatar').value = site.avatar || '';
    $('#sBio').value = site.bio || '';
    $('#contactRows').innerHTML = (site.contacts || []).map(contactRowHtml).join('') || contactRowHtml();
    $('#linkRows').innerHTML = (site.links || []).map(linkRowHtml).join('') || linkRowHtml();
  } catch (e) { toast(e.message); }
}

$('#btnAddContact').addEventListener('click', () =>
  $('#contactRows').insertAdjacentHTML('beforeend', contactRowHtml()));
$('#btnAddLink').addEventListener('click', () =>
  $('#linkRows').insertAdjacentHTML('beforeend', linkRowHtml()));
document.addEventListener('click', e => {
  if (e.target.classList && e.target.classList.contains('row-del')) {
    e.target.closest('.row-grid').remove();
  }
});

$('#btnSaveSite').addEventListener('click', async () => {
  const contacts = $$('#contactRows .contact-row').map(row => ({
    type: row.querySelector('.c-type').value,
    label: row.querySelector('.c-label').value.trim(),
    value: row.querySelector('.c-value').value.trim(),
    link: row.querySelector('.c-link').value.trim()
  })).filter(c => c.value || c.link);
  const links = $$('#linkRows .link-row').map(row => ({
    name: row.querySelector('.l-name').value.trim(),
    url: row.querySelector('.l-url').value.trim(),
    desc: row.querySelector('.l-desc').value.trim()
  })).filter(l => l.name && l.url);
  try {
    await api('/api/site', {
      method: 'PUT',
      body: JSON.stringify({
        siteName: $('#sSiteName').value.trim(),
        ownerName: $('#sOwnerName').value.trim(),
        avatar: $('#sAvatar').value.trim(),
        bio: $('#sBio').value.trim(),
        contacts, links
      })
    });
    toast('站点设置已保存 ✅（刷新前台首页生效）');
  } catch (e) { toast(e.message); }
});

/* 头像上传 */
$('#btnAvatarUpload').addEventListener('click', () => $('#sAvatarFile').click());
$('#sAvatarFile').addEventListener('change', async e => {
  const file = e.target.files[0];
  if (!file) return;
  try {
    const url = await uploadImage(file, st => toast(st));
    $('#sAvatar').value = url;
    toast('头像上传成功，记得保存设置');
  } catch (err) { toast('上传失败：' + err.message); }
  e.target.value = '';
});

/* 修改密码 */
$('#btnChangePw').addEventListener('click', async () => {
  const pwOld = $('#pwOld').value;
  const pwNew = $('#pwNew').value;
  const pwNew2 = $('#pwNew2').value;
  if (!pwOld || !pwNew) { toast('请填写完整'); return; }
  if (pwNew !== pwNew2) { toast('两次输入的新密码不一致'); return; }
  if (pwNew.length < 6) { toast('新密码至少 6 位'); return; }
  try {
    await api('/api/change-password', {
      method: 'POST',
      body: JSON.stringify({ oldPassword: pwOld, newPassword: pwNew })
    });
    $('#pwOld').value = $('#pwNew').value = $('#pwNew2').value = '';
    toast('密码修改成功 ✅ 下次登录请使用新密码');
  } catch (e) { toast(e.message); }
});

/* ================= 管理初始化 & 启动 ================= */
function initAdmin() {
  // 编辑器初始内容提示
  if (!editor.innerHTML.trim()) {
    editor.innerHTML = '<p><br></p>';
  }
}

/* 启动：有 token 则校验并直接进入后台 */
(async function boot() {
  if (TOKEN) {
    try {
      await api('/api/posts?all=1');
      showAdmin();
    } catch {
      // token 失效则回到登录页（api 内部已处理）
    }
  } else {
    showLogin();
  }
})();
