# 个人博客 · Cloudflare Workers 免费版

一个开箱即用的个人博客，部署在 Cloudflare 免费套餐上，无需服务器、无需数据库、无需付费。

## 功能一览

- **前台**：实时时钟、天气与所在地（浏览器定位 / IP 自动定位）、文章列表与详情、联系方式（点击复制 / 点击跳转）、友情链接（新窗口跳转）
- **文章**：支持图片、可点击链接、富文本排版 —— 字号（12~36px 像素级）、粗体 / 斜体 / 下划线、**删除线（划线）**、**荧光笔高亮标记**、彩色文字、对齐、列表、引用、代码块
- **后台**（`/admin.html`）：登录、文章增删改查、草稿 / 发布、图片上传（本地上传 / 外链 / 直接粘贴）、站点信息与联系方式配置、修改密码
- **安全**：XSS 过滤、Bearer Token 认证（7 天有效）、改密码后所有旧登录自动失效

## 技术架构

| 组件 | 用途 | 免费额度 |
|---|---|---|
| Workers（Hono） | API 后端 + 路由 | 每天 10 万次请求 |
| Workers Static Assets | 前端静态页面（public/） | 无限流量 |
| KV | 文章、站点配置、登录凭证 | 每天 10 万读 / 1000 写 |
| R2 | 上传的图片 | 10GB 存储 |

> KV 写入次数说明：保存文章、登录、每次文章浏览计数各消耗 1 次写。个人博客日常使用远低于 1000 次/天。

---

## 一、本地预览（可选）

```bash
npm install
npm run dev
```

打开 http://localhost:8787 即可预览（本地由 miniflare 模拟 KV / R2，无需 Cloudflare 账号）。

默认后台账号：**admin / admin123**

## 二、部署到 Cloudflare（约 5 分钟）

### 前置条件

- 注册一个免费 Cloudflare 账号：<https://dash.cloudflare.com/sign-up>
- 本机安装 Node.js 18+

### 步骤 1：登录 Cloudflare

```bash
npx wrangler login
```

会打开浏览器授权，完成后终端显示成功。

### 步骤 2：创建 KV 命名空间

```bash
npx wrangler kv namespace create BLOG_KV
```

输出中复制 `id` 的值，填入 `wrangler.jsonc`：

```jsonc
"kv_namespaces": [
  { "binding": "BLOG_KV", "id": "粘贴到这里" }
]
```

### 步骤 3：创建 R2 存储桶

```bash
npx wrangler r2 bucket create blog-images
```

桶名任意（`blog-images` 或自定义），把桶名填入 `wrangler.jsonc`：

```jsonc
"r2_buckets": [
  { "binding": "BLOG_R2", "bucket_name": "blog-images" }
]
```

### 步骤 4：部署

```bash
npm run deploy
```

完成后会输出访问地址，形如：

```
https://personal-blog.<你的子域>.workers.dev
```

博客与后台（`https://xxx.workers.dev/admin.html`）即刻可用，示例文章和图片会在第一次访问时自动初始化。

### 步骤 5：立即修改默认密码 ⚠️

登录后台 → 右上角「修改密码」，把 **admin / admin123** 改成你自己的密码（至少 6 位）。

---

## 三、进阶

### 绑定自己的域名（可选）

前提：域名已托管在同一 Cloudflare 账号。在 `wrangler.jsonc` 顶层加：

```jsonc
"routes": [
  { "pattern": "blog.example.com", "custom_domain": true }
]
```

再执行 `npm run deploy`，Cloudflare 会自动签发 HTTPS 证书。

### （可选）部署时自定义初始密码

```bash
npx wrangler secret put ADMIN_PASSWORD
```

输入你想要的初始密码。注意：secret 在 Worker 首次初始化时生效；若已用默认密码初始化过，需先清除旧数据（见下方重置方法，删除 `seeded` 和 `auth` 两个键）。

### 忘记密码了怎么办

用一条命令生成新的凭证并写回 KV（把 `<KV_ID>` 换成你的命名空间 id，`新密码` 换成你的新密码）：

```bash
node -e "const c=require('crypto');const salt=c.randomBytes(16).toString('hex');const pw='新密码';require('fs').writeFileSync('new-auth.json',JSON.stringify({username:'admin',salt,hash:c.createHash('sha256').update(salt+pw).digest('hex'),version:Date.now()}))"
npx wrangler kv key put auth --namespace-id=<KV_ID> --path=new-auth.json
rm new-auth.json
```

旧登录会全部失效，用新密码重新登录即可（文章数据不受影响）。

### 常用运维命令

```bash
npx wrangler kv key list --namespace-id=<KV_ID>   # 查看 KV 中的数据键
npx wrangler r2 object list blog-images           # 查看已上传的图片
npx wrangler tail                                 # 实时查看线上日志
```

## 四、目录结构

```
personal-blog-cloudflare/
├── wrangler.jsonc        # Cloudflare 配置（KV/R2 绑定在这里填写）
├── package.json
├── src/worker.js         # 后端：Hono 路由 + KV + R2
└── public/               # 前端静态文件（自动部署为 Workers Assets）
    ├── index.html        # 博客主页
    ├── post.html         # 文章详情页
    ├── admin.html        # 后台管理
    ├── css / js
    └── uploads/          # 内置示例图片（avatar.jpg、demo-*.jpg）
```

> 上传的新图片存在 R2 中；示例图片走静态资产，互不冲突。
