import fs from 'fs';

// 路径别名 -> public 下的源文件
const map = {
  '/': 'index.html',
  '/index.html': 'index.html',
  '/admin': 'admin.html',
  '/admin.html': 'admin.html',
  '/post': 'post.html',
  '/post.html': 'post.html',
  '/diag': 'diag.html',
  '/diag.html': 'diag.html',
};

const assets = {};
for (const [k, f] of Object.entries(map)) {
  assets[k] = fs.readFileSync(new URL('./public/' + f, import.meta.url), 'utf8');
}

// 转义会破坏 JS 模板字符串的字符
const esc = s => s
  .replace(/\\/g, '\\\\')
  .replace(/`/g, '\\`')
  .replace(/\$\{/g, '\\${');

let out = 'export const HTML_ASSETS = {\n';
out += Object.entries(assets)
  .map(([k, v]) => `  ${JSON.stringify(k)}: \`${esc(v)}\``)
  .join(',\n');
out += '\n};\n';

fs.writeFileSync(new URL('./src/html-assets.js', import.meta.url), out);
console.log('✅ 已重新生内联 HTML，键:', Object.keys(assets).join(', '));
